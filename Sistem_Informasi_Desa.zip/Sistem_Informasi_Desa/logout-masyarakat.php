<?php
session_start();

// HAPUS SESSION MASYARAKAT SAJA
if (isset($_SESSION['user'])) {
    unset($_SESSION['user']);
}

session_destroy();
header("Location: index.php");
exit;
