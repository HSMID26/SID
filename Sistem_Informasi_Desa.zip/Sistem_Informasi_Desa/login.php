<?php
session_start();
include 'koneksi.php';

// JIKA SUDAH LOGIN ADMIN
if (isset($_SESSION['admin'])) {
    header("Location: admin/dashboard.php");
    exit;
}

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    $stmt = mysqli_prepare($conn, "
        SELECT * FROM users 
        WHERE username = ? AND role = 'admin'
    ");
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) === 1) {
        $admin = mysqli_fetch_assoc($result);

        if (password_verify($password, $admin['password'])) {

            $_SESSION['admin'] = [
                'id'           => $admin['id'],
                'nama_lengkap' => $admin['nama_lengkap'],
                'username'     => $admin['username'],
                'jabatan'      => $admin['jabatan']
            ];

            header("Location: admin/dashboard.php");
            exit;
        } else {
            $error = "Password salah!";
        }
    } else {
        $error = "Akun admin tidak ditemukan!";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Admin - Sistem Masyarakat</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #0c3f2d 0%, #0a7a4f 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            position: relative;
            overflow: hidden;
        }

        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: 
                radial-gradient(circle at 20% 80%, rgba(255, 255, 255, 0.05) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, rgba(255, 255, 255, 0.05) 0%, transparent 50%);
            z-index: 0;
        }

        .login-container {
            display: flex;
            max-width: 1000px;
            width: 100%;
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.25);
            position: relative;
            z-index: 1;
        }

        /* Panel Kiri - Branding & Info */
        .brand-panel {
            flex: 1;
            background: linear-gradient(to bottom right, #0c3f2d, #0a7a4f);
            color: white;
            padding: 50px 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }

        .brand-panel::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -20%;
            width: 300px;
            height: 300px;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 50%;
        }

        .brand-panel::after {
            content: '';
            position: absolute;
            bottom: -30%;
            left: -10%;
            width: 200px;
            height: 200px;
            background: rgba(255, 255, 255, 0.03);
            border-radius: 50%;
        }

        .logo {
            display: flex;
            align-items: center;
            margin-bottom: 30px;
            position: relative;
            z-index: 2;
        }

        .logo-icon {
            width: 50px;
            height: 50px;
            background: rgba(255, 255, 255, 0.15);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 22px;
        }

        .logo-text h1 {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 3px;
        }

        .logo-text p {
            font-size: 13px;
            opacity: 0.8;
        }

        .panel-content {
            position: relative;
            z-index: 2;
        }

        .panel-content h2 {
            font-size: 28px;
            margin-bottom: 15px;
            font-weight: 700;
            line-height: 1.3;
        }

        .panel-content p {
            font-size: 15px;
            line-height: 1.6;
            opacity: 0.9;
            margin-bottom: 30px;
        }

        .features {
            list-style: none;
            margin-top: 30px;
        }

        .features li {
            display: flex;
            align-items: center;
            margin-bottom: 18px;
            font-size: 15px;
        }

        .features i {
            width: 28px;
            height: 28px;
            background: rgba(255, 255, 255, 0.15);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 12px;
            font-size: 13px;
        }

        /* Panel Kanan - Form Login */
        .form-panel {
            flex: 1;
            padding: 60px 50px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .form-header {
            margin-bottom: 40px;
            text-align: center;
        }

        .form-header h3 {
            color: #0c3f2d;
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 8px;
        }

        .form-header p {
            color: #666;
            font-size: 15px;
        }

        /* Error Message */
        .error-notification {
            background: linear-gradient(to right, #ffeaea, #ffdbdb);
            border-left: 4px solid #d32f2f;
            color: #d32f2f;
            padding: 16px 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            animation: shake 0.5s ease-in-out;
        }

        .error-notification i {
            margin-right: 12px;
            font-size: 18px;
        }

        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-5px); }
            75% { transform: translateX(5px); }
        }

        /* Form Styles */
        .form-group {
            margin-bottom: 25px;
            position: relative;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
            font-size: 15px;
            display: flex;
            align-items: center;
        }

        .form-label i {
            margin-right: 8px;
            color: #0a7a4f;
            font-size: 16px;
        }

        .input-group {
            position: relative;
        }

        .input-group i {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: #0a7a4f;
            font-size: 18px;
            z-index: 2;
        }

        .form-control {
            width: 100%;
            padding: 16px 20px 16px 55px;
            border: 2px solid #e8e8e8;
            border-radius: 12px;
            font-size: 16px;
            transition: all 0.3s;
            background-color: #fafafa;
            color: #333;
        }

        .form-control:focus {
            border-color: #0a7a4f;
            background-color: #fff;
            outline: none;
            box-shadow: 0 0 0 4px rgba(10, 122, 79, 0.15);
        }

        .form-control::placeholder {
            color: #999;
        }

        .password-toggle {
            position: absolute;
            right: 18px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #777;
            cursor: pointer;
            font-size: 18px;
            z-index: 3;
        }

        .password-toggle:hover {
            color: #0a7a4f;
        }

        /* Submit Button */
        .btn-login {
            width: 100%;
            padding: 18px;
            background: linear-gradient(to right, #0c3f2d, #0a7a4f);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 17px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            letter-spacing: 0.5px;
            box-shadow: 0 5px 15px rgba(10, 122, 79, 0.2);
        }

        .btn-login:hover {
            background: linear-gradient(to right, #0a3526, #096946);
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(10, 122, 79, 0.3);
        }

        .btn-login:active {
            transform: translateY(-1px);
        }

        .btn-login i {
            margin-right: 10px;
            font-size: 18px;
        }

        /* Register Link */
        .register-link {
            text-align: center;
            margin-top: 30px;
            padding-top: 25px;
            border-top: 1px solid #eee;
            color: #666;
            font-size: 15px;
        }

        .register-link a {
            color: #0a7a4f;
            font-weight: 600;
            text-decoration: none;
            transition: color 0.3s;
            display: inline-flex;
            align-items: center;
        }

        .register-link a:hover {
            color: #0c3f2d;
            text-decoration: underline;
        }

        .register-link i {
            margin-left: 8px;
            font-size: 14px;
        }

        /* Responsive */
        @media (max-width: 900px) {
            .login-container {
                flex-direction: column;
                max-width: 500px;
            }
            
            .brand-panel, .form-panel {
                padding: 40px 30px;
            }
            
            .brand-panel {
                padding-bottom: 30px;
            }
        }

        @media (max-width: 480px) {
            .login-container {
                border-radius: 15px;
            }
            
            .brand-panel, .form-panel {
                padding: 35px 25px;
            }
            
            .form-header h3 {
                font-size: 24px;
            }
            
            .form-control {
                padding: 14px 20px 14px 50px;
            }
            
            .btn-login {
                padding: 16px;
            }
        }

        /* Loading Animation */
        .loading {
            display: none;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: white;
            animation: spin 1s ease-in-out infinite;
            margin-right: 10px;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }
    </style>
</head>
<body>

<div class="login-container">
    <!-- Panel Kiri: Branding & Info -->
    <div class="brand-panel">
        <div class="logo">
            <div class="logo-icon">
                <i class="fas fa-user-shield"></i>
            </div>
            <div class="logo-text">
                <h1>Sistem Masyarakat</h1>
                <p>Administrator Portal</p>
            </div>
        </div>

        <div class="panel-content">
            <h2>Selamat Datang Kembali</h2>
            <p>Masuk ke dashboard administrator untuk mengelola data masyarakat, laporan, dan pengaturan sistem.</p>
            
            <ul class="features">
                <li><i class="fas fa-shield-alt"></i> Keamanan tingkat tinggi</li>
                <li><i class="fas fa-chart-line"></i> Dashboard analitik lengkap</li>
                <li><i class="fas fa-database"></i> Manajemen data terpusat</li>
                <li><i class="fas fa-history"></i> Log aktivitas pengguna</li>
            </ul>
        </div>
    </div>

    <!-- Panel Kanan: Form Login -->
    <div class="form-panel">
        <div class="form-header">
            <h3>Login Administrator</h3>
            <p>Gunakan kredensial Anda untuk masuk</p>
        </div>

        <?php if($error): ?>
        <div class="error-notification">
            <i class="fas fa-exclamation-circle"></i>
            <span><?= $error ?></span>
        </div>
        <?php endif; ?>

        <form method="post" id="loginForm">
            <div class="form-group">
                <label class="form-label" for="username">
                    <i class="fas fa-user-tie"></i> Username
                </label>
                <div class="input-group">
                    <i class="fas fa-user"></i>
                    <input type="text" id="username" name="username" class="form-control" 
                           placeholder="Masukkan username admin" required autofocus>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="password">
                    <i class="fas fa-key"></i> Password
                </label>
                <div class="input-group">
                    <i class="fas fa-lock"></i>
                    <input type="password" id="password" name="password" class="form-control" 
                           placeholder="Masukkan password" required>
                    <button type="button" class="password-toggle" id="togglePassword">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
            </div>

            <button type="submit" class="btn-login" id="loginButton">
                <div class="loading" id="loadingSpinner"></div>
                <i class="fas fa-sign-in-alt"></i>
                <span id="buttonText">Masuk ke Dashboard</span>
            </button>
        </form>

        <div class="register-link">
            <a href="register.php">
                <i class="fas fa-user-plus"></i> Daftar Admin Baru
            </a>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Toggle visibility password
        const togglePassword = document.getElementById('togglePassword');
        const passwordInput = document.getElementById('password');
        const eyeIcon = togglePassword.querySelector('i');
        
        togglePassword.addEventListener('click', function() {
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            eyeIcon.classList.toggle('fa-eye');
            eyeIcon.classList.toggle('fa-eye-slash');
        });

        // Form submission animation
        const loginForm = document.getElementById('loginForm');
        const loginButton = document.getElementById('loginButton');
        const buttonText = document.getElementById('buttonText');
        const loadingSpinner = document.getElementById('loadingSpinner');
        
        loginForm.addEventListener('submit', function() {
            // Show loading animation
            loadingSpinner.style.display = 'block';
            buttonText.textContent = 'Memproses...';
            loginButton.disabled = true;
            
            // Prevent double submission
            setTimeout(() => {
                loginButton.disabled = false;
            }, 3000);
        });

        // Auto-focus pada input username jika ada error
        <?php if($error): ?>
            document.getElementById('username').focus();
        <?php endif; ?>

        // Add animation to form inputs on focus
        const inputs = document.querySelectorAll('.form-control');
        inputs.forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.parentElement.classList.add('focused');
            });
            
            input.addEventListener('blur', function() {
                if (this.value === '') {
                    this.parentElement.parentElement.classList.remove('focused');
                }
            });
        });
    });
</script>

</body>
</html>