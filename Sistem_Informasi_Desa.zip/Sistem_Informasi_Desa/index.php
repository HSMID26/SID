<?php
include 'koneksi.php';

/* ======================
   DATA ANGGARAN UNTUK CHART
====================== */
$tahun_chart  = [];
$jumlah_chart = [];

$q_anggaran = mysqli_query($conn, "SELECT * FROM anggaran ORDER BY tahun ASC");
if ($q_anggaran) {
    while ($a = mysqli_fetch_assoc($q_anggaran)) {
        $tahun_chart[]  = $a['tahun'];
        $jumlah_chart[] = $a['jumlah'];
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Desa Sampora - Sistem Informasi Desa</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <style>
        /* ===== RESET & BASE ===== */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary-color: #2e8b57;
            --primary-dark: #26734d;
            --primary-light: #3cb371;
            --secondary-color: #f8f9fa;
            --text-dark: #333333;
            --text-light: #666666;
            --text-white: #ffffff;
            --border-color: #e9ecef;
            --card-shadow: 0 8px 30px rgba(0, 0, 0, 0.08);
            --hover-shadow: 0 15px 40px rgba(0, 0, 0, 0.12);
            --transition: all 0.3s ease;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            color: var(--text-dark);
            line-height: 1.6;
            min-height: 100vh;
        }

        /* ===== NAVBAR ===== */
        .navbar {
            position: fixed;
            top: 0;
            width: 100%;
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
            padding: 0;
            z-index: 1000;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
        }

        .nav-container {
            max-width: 1300px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 70px;
        }

        .nav-brand {
            display: flex;
            align-items: center;
            gap: 12px;
            color: var(--text-white);
            font-size: 24px;
            font-weight: 700;
            text-decoration: none;
        }

        .nav-brand i {
            font-size: 26px;
            background: rgba(255, 255, 255, 0.2);
            padding: 10px;
            border-radius: 10px;
        }

        .nav-menu {
            display: flex;
            gap: 5px;
            list-style: none;
        }

        .nav-menu a {
            color: var(--text-white);
            text-decoration: none;
            padding: 12px 20px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 15px;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 8px;
            position: relative;
        }

        .nav-menu a:hover {
            background: rgba(255, 255, 255, 0.15);
            transform: translateY(-2px);
        }

        .nav-menu a.active::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 20px;
            right: 20px;
            height: 3px;
            background: var(--text-white);
            border-radius: 2px;
        }

        .nav-actions {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .btn-login {
            color: var(--text-white);
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            transition: var(--transition);
            border: 2px solid rgba(255, 255, 255, 0.3);
        }

        .btn-login:hover {
            background: rgba(255, 255, 255, 0.1);
            transform: translateY(-2px);
        }

        .btn-register {
            background: var(--text-white);
            color: var(--primary-color);
            text-decoration: none;
            padding: 10px 22px;
            border-radius: 8px;
            font-weight: 700;
            transition: var(--transition);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .btn-register:hover {
            background: #f8f9fa;
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.15);
        }

        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: var(--text-white);
            font-size: 24px;
            cursor: pointer;
            padding: 10px;
        }

        /* ===== HERO SECTION ===== */
        .hero {
            height: 85vh;
            background: linear-gradient(rgba(46, 139, 87, 0.85), rgba(46, 139, 87, 0.92)), 
                        url('assets/bg.jpg') center/cover no-repeat;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            margin-top: 70px;
            padding: 0 20px;
        }

        .hero-content {
            max-width: 800px;
            padding: 50px;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .hero h1 {
            font-size: 48px;
            font-weight: 800;
            color: var(--text-white);
            margin-bottom: 20px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2);
        }

        .hero p {
            font-size: 20px;
            color: rgba(255, 255, 255, 0.9);
            margin-bottom: 30px;
            line-height: 1.8;
        }

        /* ===== MAIN CONTAINER ===== */
        .container {
            max-width: 1200px;
            margin: 60px auto;
            padding: 0 20px;
        }

        /* ===== SECTIONS ===== */
        .section {
            background: var(--text-white);
            padding: 50px;
            margin-bottom: 50px;
            border-radius: 20px;
            box-shadow: var(--card-shadow);
            transition: var(--transition);
        }

        .section:hover {
            transform: translateY(-5px);
            box-shadow: var(--hover-shadow);
        }

        .section-header {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 40px;
            padding-bottom: 20px;
            border-bottom: 3px solid var(--border-color);
        }

        .section-header h2 {
            color: var(--primary-color);
            font-size: 32px;
            font-weight: 700;
            margin: 0;
        }

        .section-header i {
            background: linear-gradient(135deg, var(--primary-color), var(--primary-light));
            padding: 15px;
            border-radius: 12px;
            color: var(--text-white);
            font-size: 24px;
            width: 60px;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        /* ===== CARDS GRID ===== */
        .cards-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 30px;
        }

        .card {
            background: var(--text-white);
            padding: 30px;
            border-radius: 16px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.08);
            transition: var(--transition);
            position: relative;
            overflow: hidden;
            border: 1px solid var(--border-color);
        }

        .card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 6px;
            height: 100%;
            background: linear-gradient(to bottom, var(--primary-color), var(--primary-light));
        }

        .card:hover {
            transform: translateY(-8px);
            box-shadow: var(--hover-shadow);
        }

        .card-header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 15px;
        }

        .card-icon {
            background: linear-gradient(135deg, var(--primary-color), var(--primary-light));
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--text-white);
            font-size: 22px;
        }

        .card-title {
            color: var(--primary-color);
            font-size: 20px;
            font-weight: 700;
            margin: 0;
            flex: 1;
        }

        .card-date {
            color: var(--text-light);
            font-size: 14px;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .card-content {
            color: var(--text-dark);
            line-height: 1.7;
            font-size: 15px;
        }

        /* ===== PROFILE SECTION ===== */
        .profile-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 40px;
            align-items: start;
        }

        .profile-info {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .profile-item {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .profile-label {
            color: var(--primary-color);
            font-weight: 600;
            font-size: 16px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .profile-value {
            color: var(--text-dark);
            font-size: 18px;
            line-height: 1.6;
        }

        /* ===== PETA DESA ===== */
        .map-container {
            margin-top: 20px;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .map-preview {
            width: 100%;
            height: 300px;
            object-fit: cover;
        }

        /* ===== CHART SECTION ===== */
        .chart-container {
            background: var(--text-white);
            padding: 30px;
            border-radius: 16px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
            margin-top: 30px;
        }

        /* ===== PENGADUAN SECTION ===== */
        .pengaduan-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 20px;
        }

        .btn-create {
            background: linear-gradient(135deg, var(--primary-color), var(--primary-light));
            color: var(--text-white);
            text-decoration: none;
            padding: 14px 32px;
            border-radius: 10px;
            font-weight: 700;
            font-size: 16px;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            transition: var(--transition);
            box-shadow: 0 6px 20px rgba(46, 139, 87, 0.2);
        }

        .btn-create:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(46, 139, 87, 0.3);
        }

        .pengaduan-card {
            background: var(--text-white);
            padding: 30px;
            border-radius: 16px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
            margin-bottom: 25px;
            transition: var(--transition);
            border-left: 4px solid var(--primary-color);
        }

        .pengaduan-card:hover {
            transform: translateX(5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.12);
        }

        .pengaduan-meta {
            display: flex;
            gap: 20px;
            color: var(--text-light);
            font-size: 14px;
            margin: 15px 0;
            flex-wrap: wrap;
        }

        .pengaduan-meta span {
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .status-badge {
            display: inline-block;
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 600;
            margin-top: 15px;
        }

        .status-terkirim { background: #fff3cd; color: #856404; }
        .status-diproses { background: #cce5ff; color: #004085; }
        .status-selesai { background: #d4edda; color: #155724; }

        /* ===== FOOTER ===== */
        .footer {
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            color: var(--text-white);
            padding: 60px 0 30px;
            margin-top: 80px;
        }

        .footer-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 40px;
            margin-bottom: 40px;
        }

        .footer-section h3 {
            font-size: 22px;
            margin-bottom: 25px;
            color: var(--text-white);
            position: relative;
            padding-bottom: 10px;
        }

        .footer-section h3::after {
            content: '';
            position: absolute;
            left: 0;
            bottom: 0;
            width: 50px;
            height: 3px;
            background: var(--primary-color);
        }

        .footer-bottom {
            text-align: center;
            padding-top: 30px;
            margin-top: 40px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            color: rgba(255, 255, 255, 0.7);
            font-size: 14px;
        }

        /* ===== RESPONSIVE DESIGN ===== */
        @media (max-width: 992px) {
            .hero h1 { font-size: 40px; }
            .hero p { font-size: 18px; }
            .cards-grid { grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); }
            .profile-grid { grid-template-columns: 1fr; }
        }

        @media (max-width: 768px) {
            .mobile-menu-btn { display: block; }
            
            .nav-menu {
                display: none;
                position: absolute;
                top: 100%;
                left: 0;
                width: 100%;
                background: var(--primary-color);
                flex-direction: column;
                padding: 20px;
                box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
            }
            
            .nav-menu.active { display: flex; }
            
            .nav-actions {
                display: none;
                position: absolute;
                top: 100%;
                left: 0;
                width: 100%;
                background: var(--primary-color);
                padding: 20px;
                flex-direction: column;
                gap: 10px;
            }
            
            .nav-actions.active { display: flex; }
            
            .hero { height: 70vh; margin-top: 70px; }
            .hero h1 { font-size: 32px; }
            .hero p { font-size: 16px; }
            .hero-content { padding: 30px 20px; }
            
            .section { padding: 30px 20px; }
            .section-header h2 { font-size: 26px; }
            .section-header i { width: 50px; height: 50px; padding: 12px; }
        }

        @media (max-width: 480px) {
            .hero { height: 60vh; }
            .cards-grid { grid-template-columns: 1fr; }
            .container { padding: 0 15px; }
            .pengaduan-header { flex-direction: column; align-items: flex-start; }
            .btn-create { width: 100%; justify-content: center; }
        }

        /* ===== ANIMATIONS ===== */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .animate-fade-in {
            animation: fadeInUp 0.6s ease-out forwards;
        }

        /* ===== SCROLL TO TOP ===== */
        .scroll-top {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 50px;
            height: 50px;
            background: var(--primary-color);
            color: var(--text-white);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            font-size: 20px;
            box-shadow: 0 4px 15px rgba(46, 139, 87, 0.3);
            transition: var(--transition);
            opacity: 0;
            visibility: hidden;
            z-index: 999;
        }

        .scroll-top.active {
            opacity: 1;
            visibility: visible;
        }

        .scroll-top:hover {
            background: var(--primary-dark);
            transform: translateY(-5px);
        }

        /* ===== IMAGE STYLING ===== */
        img {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
        }

        .berita-img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 12px;
            margin-bottom: 15px;
        }

        /* ===== UTILITY CLASSES ===== */
        .mt-20 { margin-top: 20px; }
        .mt-30 { margin-top: 30px; }
        .mb-20 { margin-bottom: 20px; }
        .mb-30 { margin-bottom: 30px; }
        .text-center { text-align: center; }
        .text-muted { color: var(--text-light); }
        .d-flex { display: flex; }
        .align-center { align-items: center; }
        .justify-between { justify-content: space-between; }
        .gap-10 { gap: 10px; }
        .gap-20 { gap: 20px; }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <a href="#" class="nav-brand">
                <i class="fas fa-tree"></i>
                Desa Sampora
            </a>
            
            <ul class="nav-menu">
                <li><a href="#tentang" class="active"><i class="fas fa-home"></i> Profil Desa</a></li>
                <li><a href="#persyaratan"><i class="fas fa-file-alt"></i> Persyaratan</a></li>
                <li><a href="#berita"><i class="fas fa-newspaper"></i> Berita</a></li>
                <li><a href="#timeline"><i class="fas fa-history"></i> Timeline</a></li>
                <li><a href="#anggaran"><i class="fas fa-chart-pie"></i> Anggaran</a></li>
                <li><a href="#pengaduan"><i class="fas fa-comments"></i> Pengaduan</a></li>
            </ul>
            
            <div class="nav-actions">
                <a href="login.php" class="btn-login"><i class="fas fa-sign-in-alt"></i> Masuk</a>
                <a href="register.php" class="btn-register"><i class="fas fa-user-plus"></i> Daftar Admin</a>
            </div>
            
            <button class="mobile-menu-btn" id="mobileMenuBtn">
                <i class="fas fa-bars"></i>
            </button>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-content animate-fade-in">
            <h1>Desa Sampora</h1>
            <p>Sistem Informasi Desa - Membangun masyarakat yang sejahtera melalui pelayanan transparan dan akuntabel</p>
        </div>
    </section>

    <!-- Main Content -->
    <div class="container">
        <!-- Profil Desa -->
        <section id="tentang" class="section animate-fade-in">
            <div class="section-header">
                <i class="fas fa-home"></i>
                <h2>Profil Desa</h2>
            </div>

            <?php
            $profil = mysqli_query($conn, "SELECT * FROM profil_desa ORDER BY id DESC LIMIT 1");
            $data = mysqli_fetch_assoc($profil);

            if ($data):
            ?>
            <div class="profile-grid">
                <div class="profile-info">
                    <div class="profile-item">
                        <span class="profile-label"><i class="fas fa-map-marker-alt"></i> Nama Desa</span>
                        <p class="profile-value"><?= htmlspecialchars($data['nama_desa']) ?></p>
                    </div>
                    
                    <div class="profile-item">
                        <span class="profile-label"><i class="fas fa-map"></i> Alamat</span>
                        <p class="profile-value"><?= nl2br(htmlspecialchars($data['alamat'])) ?></p>
                    </div>
                    
                    <?php if (!empty($data['sejarah'])): ?>
                    <div class="profile-item">
                        <span class="profile-label"><i class="fas fa-book"></i> Sejarah Singkat</span>
                        <p class="profile-value"><?= nl2br(htmlspecialchars($data['sejarah'])) ?></p>
                    </div>
                    <?php endif; ?>
                </div>
                
                <?php if (!empty($data['peta_desa'])): ?>
                <div class="map-container">
                    <h3 class="mb-20"><i class="fas fa-map-marked-alt"></i> Peta Desa</h3>
                    <?php
                    $ext = pathinfo($data['peta_desa'], PATHINFO_EXTENSION);
                    if ($ext === 'pdf'):
                    ?>
                        <a href="uploads/<?= $data['peta_desa'] ?>" target="_blank" class="btn-create">
                            <i class="fas fa-file-pdf"></i> Lihat Peta Desa (PDF)
                        </a>
                    <?php else: ?>
                        <img src="uploads/<?= $data['peta_desa'] ?>" 
                             alt="Peta Desa" 
                             class="map-preview">
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
            <?php else: ?>
                <div class="card">
                    <p class="text-center text-muted">Profil desa belum tersedia.</p>
                </div>
            <?php endif; ?>
        </section>

        <!-- Persyaratan -->
        <section id="persyaratan" class="section animate-fade-in">
            <div class="section-header">
                <i class="fas fa-file-alt"></i>
                <h2>Persyaratan Administrasi</h2>
            </div>
            
            <div class="cards-grid">
            <?php
            $syarat = mysqli_query($conn, "SELECT * FROM persyaratan");
            
            if ($syarat && mysqli_num_rows($syarat) > 0) {
                while($s = mysqli_fetch_assoc($syarat)) {
                    $judul = $s['judul'] ?? ($s['Judul'] ?? ($s['JUDUL'] ?? 'Persyaratan Administrasi'));
                    $deskripsi = $s['deskripsi'] ?? ($s['Deskripsi'] ?? ($s['DESKRIPSI'] ?? ''));
            ?>
                <div class="card">
                    <div class="card-header">
                        <div class="card-icon">
                            <i class="fas fa-clipboard-list"></i>
                        </div>
                        <h3 class="card-title"><?= htmlspecialchars($judul) ?></h3>
                    </div>
                    <?php if (!empty(trim($deskripsi))): ?>
                    <div class="card-content">
                        <?= nl2br(htmlspecialchars($deskripsi)) ?>
                    </div>
                    <?php endif; ?>
                </div>
            <?php 
                }
                mysqli_free_result($syarat);
            } else { 
            ?>
                <div class="card" style="grid-column: 1 / -1; text-align: center;">
                    <div class="card-icon">
                        <i class="fas fa-info-circle"></i>
                    </div>
                    <h3 class="card-title">Belum Ada Persyaratan</h3>
                    <p class="card-content text-muted">Silakan hubungi administrator untuk menambahkan persyaratan administrasi.</p>
                </div>
            <?php } ?>
            </div>
        </section>

        <!-- Berita -->
        <section id="berita" class="section animate-fade-in">
            <div class="section-header">
                <i class="fas fa-newspaper"></i>
                <h2>Berita Terbaru</h2>
            </div>

            <div class="cards-grid">
            <?php
            $berita = mysqli_query($conn, "SELECT * FROM berita ORDER BY tanggal DESC LIMIT 6");

            if ($berita && mysqli_num_rows($berita) > 0) {
                while ($b = mysqli_fetch_assoc($berita)) {
            ?>
                <div class="card">
                    <?php if (!empty($b['gambar'])): ?>
                    <img src="uploads/berita/<?= htmlspecialchars($b['gambar']) ?>" 
                         alt="<?= htmlspecialchars($b['judul']) ?>"
                         class="berita-img">
                    <?php endif; ?>
                    
                    <div class="card-header">
                        <h3 class="card-title"><?= htmlspecialchars($b['judul']) ?></h3>
                    </div>
                    
                    <div class="card-date">
                        <i class="far fa-calendar"></i>
                        <?= date("d M Y", strtotime($b['tanggal'])) ?>
                    </div>
                    
                    <div class="card-content">
                        <?= nl2br(htmlspecialchars(substr($b['isi'], 0, 150))) ?>...
                    </div>
                </div>
            <?php
                }
                mysqli_free_result($berita);
            } else {
            ?>
                <div class="card" style="grid-column: 1 / -1; text-align: center;">
                    <div class="card-icon">
                        <i class="fas fa-newspaper"></i>
                    </div>
                    <h3 class="card-title">Belum Ada Berita</h3>
                    <p class="card-content text-muted">Tidak ada berita terbaru saat ini.</p>
                </div>
            <?php } ?>
            </div>
        </section>

        <!-- Timeline -->
        <section id="timeline" class="section animate-fade-in">
            <div class="section-header">
                <i class="fas fa-history"></i>
                <h2>Timeline Kegiatan Desa</h2>
            </div>
            
            <div class="cards-grid">
            <?php
            $timeline = mysqli_query($conn, "SELECT * FROM timeline ORDER BY tanggal_kegiatan DESC LIMIT 4");
            if($timeline && mysqli_num_rows($timeline) > 0){
                while($t = mysqli_fetch_assoc($timeline)){
            ?>
                <div class="card">
                    <div class="card-header">
                        <div class="card-icon">
                            <i class="fas fa-calendar-check"></i>
                        </div>
                        <h3 class="card-title"><?= htmlspecialchars($t['judul']) ?></h3>
                    </div>
                    
                    <div class="card-date">
                        <i class="far fa-calendar-alt"></i>
                        <?= date("d M Y", strtotime($t['tanggal_kegiatan'])) ?>
                    </div>
                    
                    <div class="card-content">
                        <?= nl2br(htmlspecialchars($t['deskripsi'])) ?>
                    </div>
                </div>
            <?php 
                }
            } else { 
            ?>
                <div class="card" style="grid-column: 1 / -1; text-align: center;">
                    <div class="card-icon">
                        <i class="fas fa-timeline"></i>
                    </div>
                    <h3 class="card-title">Belum Ada Kegiatan</h3>
                    <p class="card-content text-muted">Tidak ada timeline kegiatan saat ini.</p>
                </div>
            <?php } ?>
            </div>
        </section>

        <!-- Anggaran -->
        <section id="anggaran" class="section animate-fade-in">
            <div class="section-header">
                <i class="fas fa-chart-pie"></i>
                <h2>Anggaran Desa</h2>
            </div>

            <div class="cards-grid">
            <?php
            $anggaran = mysqli_query($conn, "SELECT * FROM anggaran ORDER BY tahun DESC LIMIT 4");
            while($row = mysqli_fetch_assoc($anggaran)):
            ?>
                <div class="card">
                    <div class="card-header">
                        <div class="card-icon">
                            <i class="fas fa-money-bill-wave"></i>
                        </div>
                        <h3 class="card-title">Tahun <?= $row['tahun'] ?></h3>
                    </div>
                    
                    <div class="card-content">
                        <div style="font-size: 24px; color: var(--primary-color); font-weight: bold; margin: 10px 0;">
                            Rp <?= number_format($row['jumlah'], 0, ',', '.') ?>
                        </div>
                        <p class="text-muted"><?= htmlspecialchars($row['keterangan']) ?></p>
                    </div>
                </div>
            <?php endwhile; ?>
            </div>

            <div class="chart-container mt-30">
                <canvas id="chartAnggaran" height="100"></canvas>
            </div>
        </section>

        <!-- Pengaduan -->
        <section id="pengaduan" class="section animate-fade-in">
            <div class="section-header">
                <i class="fas fa-comments"></i>
                <h2>Pengaduan Warga</h2>
            </div>

            <div class="pengaduan-header">
                <p>Sampaikan keluhan, saran, atau aspirasi Anda untuk kemajuan desa</p>
                <a href="<?= isset($_SESSION['user']) ? 'pengaduan-baru.php' : 'login-masyarakat.php' ?>" class="btn-create">
                    <i class="fas fa-edit"></i> Buat Pengaduan Baru
                </a>
            </div>

            <?php
            $pengaduan = mysqli_query($conn, "
                SELECT p.*, u.nama_lengkap
                FROM pengaduan p
                JOIN users u ON p.user_id = u.id
                ORDER BY p.created_at DESC
                LIMIT 5
            ");

            if ($pengaduan && mysqli_num_rows($pengaduan) > 0) {
                while ($p = mysqli_fetch_assoc($pengaduan)) {
                    $statusClass = 'status-' . $p['status'];
            ?>
            <div class="pengaduan-card">
                <h3 style="color: var(--primary-color); margin-bottom: 10px;">
                    <?= htmlspecialchars($p['kategori']) ?>
                </h3>
                
                <div class="pengaduan-meta">
                    <span><i class="fas fa-user"></i> <?= htmlspecialchars($p['nama_lengkap']) ?></span>
                    <span><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($p['lokasi']) ?></span>
                    <span><i class="far fa-calendar"></i> <?= date('d M Y', strtotime($p['tanggal'])) ?></span>
                </div>
                
                <div class="card-content">
                    <?= nl2br(htmlspecialchars($p['pesan'])) ?>
                </div>
                
                <?php if (!empty($p['bukti'])): ?>
                <div class="mt-20">
                    <img src="uploads/pengaduan/<?= htmlspecialchars($p['bukti']) ?>"
                         style="max-width: 300px; border-radius: 8px; border: 1px solid var(--border-color);">
                </div>
                <?php endif; ?>
                
                <div class="status-badge <?= $statusClass ?> mt-20">
                    <i class="fas fa-circle" style="font-size: 10px;"></i>
                    <?= ucfirst($p['status']) ?>
                </div>
            </div>
            <?php
                }
            } else {
            ?>
            <div class="card" style="text-align: center;">
                <div class="card-icon">
                    <i class="fas fa-comment-slash"></i>
                </div>
                <h3 class="card-title">Belum Ada Pengaduan</h3>
                <p class="card-content text-muted">Jadilah yang pertama mengajukan pengaduan untuk perbaikan desa.</p>
                <a href="login-masyarakat.php" class="btn-create mt-20">
                    <i class="fas fa-plus"></i> Ajukan Pengaduan Pertama
                </a>
            </div>
            <?php } ?>
        </section>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="footer-container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>Desa Sampora</h3>
                    <p>Sistem Informasi Desa yang transparan dan akuntabel untuk membangun masyarakat yang sejahtera dan mandiri.</p>
                </div>
                
                <div class="footer-section">
                    <h3>Kontak</h3>
                    <p><i class="fas fa-phone"></i> (021) 1234-5678</p>
                    <p><i class="fas fa-envelope"></i> info@desasampora.id</p>
                    <p><i class="fas fa-map-marker-alt"></i> Desa Sampora, Kec. Cibiru, Kota Bandung</p>
                </div>
                
                <div class="footer-section">
                    <h3>Tautan Cepat</h3>
                    <ul style="list-style: none; padding: 0;">
                        <li><a href="#tentang" style="color: #bdc3c7; text-decoration: none;">Profil Desa</a></li>
                        <li><a href="#persyaratan" style="color: #bdc3c7; text-decoration: none;">Persyaratan</a></li>
                        <li><a href="#berita" style="color: #bdc3c7; text-decoration: none;">Berita</a></li>
                        <li><a href="#pengaduan" style="color: #bdc3c7; text-decoration: none;">Pengaduan</a></li>
                    </ul>
                </div>
            </div>
            
            <div class="footer-bottom">
                &copy; <?= date('Y') ?> Desa Sampora - Sistem Informasi Desa. Hak Cipta Dilindungi.
            </div>
        </div>
    </footer>

    <!-- Scroll to Top Button -->
    <a href="#" class="scroll-top" id="scrollTop">
        <i class="fas fa-chevron-up"></i>
    </a>

    <script>
        // Mobile Menu Toggle
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const navMenu = document.querySelector('.nav-menu');
        const navActions = document.querySelector('.nav-actions');
        
        mobileMenuBtn.addEventListener('click', () => {
            navMenu.classList.toggle('active');
            navActions.classList.toggle('active');
        });
        
        // Close mobile menu when clicking outside
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.nav-container')) {
                navMenu.classList.remove('active');
                navActions.classList.remove('active');
            }
        });
        
        // Scroll to Top
        const scrollTop = document.getElementById('scrollTop');
        
        window.addEventListener('scroll', () => {
            if (window.pageYOffset > 300) {
                scrollTop.classList.add('active');
            } else {
                scrollTop.classList.remove('active');
            }
        });
        
        scrollTop.addEventListener('click', (e) => {
            e.preventDefault();
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
        
        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                if (targetId === '#') return;
                
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - 80,
                        behavior: 'smooth'
                    });
                    
                    // Close mobile menu if open
                    navMenu.classList.remove('active');
                    navActions.classList.remove('active');
                }
            });
        });
        
        // Chart Initialization
        const ctx = document.getElementById('chartAnggaran').getContext('2d');
        const chart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: <?= json_encode($tahun_chart) ?>,
                datasets: [{
                    label: 'Anggaran Desa (Rp)',
                    data: <?= json_encode($jumlah_chart) ?>,
                    backgroundColor: [
                        'rgba(46, 139, 87, 0.7)',
                        'rgba(60, 179, 113, 0.7)',
                        'rgba(46, 139, 87, 0.5)',
                        'rgba(60, 179, 113, 0.5)',
                        'rgba(46, 139, 87, 0.3)'
                    ],
                    borderColor: [
                        'rgba(46, 139, 87, 1)',
                        'rgba(60, 179, 113, 1)',
                        'rgba(46, 139, 87, 0.8)',
                        'rgba(60, 179, 113, 0.8)',
                        'rgba(46, 139, 87, 0.6)'
                    ],
                    borderWidth: 1,
                    borderRadius: 6
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top',
                        labels: {
                            font: {
                                size: 14
                            },
                            padding: 20
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return 'Rp ' + context.parsed.y.toLocaleString('id-ID');
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'Rp ' + value.toLocaleString('id-ID');
                            }
                        },
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
        
        // Add animation to cards on scroll
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-fade-in');
                }
            });
        }, observerOptions);
        
        // Observe all sections
        document.querySelectorAll('.section').forEach(section => {
            observer.observe(section);
        });
    </script>
</body>
</html>