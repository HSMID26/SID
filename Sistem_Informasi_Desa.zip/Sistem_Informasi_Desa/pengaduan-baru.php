<?php
session_start();
include 'koneksi.php';

/* ===============================
   CEK LOGIN MASYARAKAT
================================ */
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'masyarakat') {
    header("Location: login-masyarakat.php");
    exit;
}

$user = $_SESSION['user'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Form Pengaduan Warga</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: #f5f7fa;
    line-height: 1.6;
}
.top-header {
    background: linear-gradient(135deg, #0b4d3a, #0b8f5a);
    color: #fff;
    padding: 15px 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 4px 12px rgba(11, 77, 58, 0.3);
}
.user-info {
    display: flex;
    gap: 15px;
    align-items: center;
}
.avatar {
    width: 40px;
    height: 40px;
    background: rgba(255, 255, 255, 0.2);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    font-size: 16px;
    border: 2px solid rgba(255, 255, 255, 0.3);
}
.logout {
    background: #dc3545;
    color: #fff;
    padding: 8px 18px;
    border-radius: 6px;
    text-decoration: none;
    font-size: 14px;
    transition: background 0.3s;
}
.logout:hover {
    background: #c82333;
}
.container {
    max-width: 800px;
    margin: 40px auto;
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 6px 20px rgba(0,0,0,.1);
    overflow: hidden;
}
.header {
    background: linear-gradient(135deg, #0b4d3a, #0b8f5a);
    color: #fff;
    padding: 25px;
    text-align: center;
}
.header h2 {
    margin: 0;
    font-size: 28px;
}
.form-container {
    padding: 30px;
}
.form-group {
    margin-bottom: 25px;
}
.form-group label {
    font-weight: 600;
    margin-bottom: 8px;
    display: block;
    color: #333;
    font-size: 15px;
}
.form-group input[readonly] {
    background: #f8f9fa;
    color: #666;
    cursor: not-allowed;
}
.form-control {
    width: 100%;
    padding: 14px;
    border-radius: 8px;
    border: 1px solid #ddd;
    font-size: 15px;
    transition: all 0.3s;
}
.form-control:focus {
    outline: none;
    border-color: #0b8f5a;
    box-shadow: 0 0 0 3px rgba(11, 143, 90, 0.1);
}
select.form-control {
    appearance: none;
    background: white url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='%230b4d3a' viewBox='0 0 16 16'%3E%3Cpath d='M7.247 11.14L2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z'/%3E%3C/svg%3E") no-repeat right 15px center;
    background-size: 16px;
    padding-right: 40px;
}
textarea.form-control {
    min-height: 120px;
    resize: vertical;
}
.btn-submit {
    background: linear-gradient(135deg, #0b8f5a, #0da768);
    color: #fff;
    padding: 16px;
    width: 100%;
    border: none;
    border-radius: 8px;
    font-size: 17px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
    margin-top: 10px;
}
.btn-submit:hover {
    background: linear-gradient(135deg, #0a7c4f, #0b8f5a);
    transform: translateY(-2px);
    box-shadow: 0 6px 15px rgba(11, 143, 90, 0.3);
}
.back-link {
    display: block;
    text-align: center;
    margin-top: 20px;
    color: #0b4d3a;
    font-weight: 600;
    text-decoration: none;
    padding: 10px;
    transition: color 0.3s;
}
.back-link:hover {
    color: #0a7c4f;
    text-decoration: underline;
}
.file-info {
    font-size: 13px;
    color: #666;
    margin-top: 5px;
}
.required {
    color: #dc3545;
}
.error-message {
    background: #ffe6e6;
    color: #c0392b;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    border-left: 4px solid #c0392b;
    text-align: center;
}
.error-message i {
    margin-right: 8px;
}
.success-message {
    background: #e8f6ef;
    color: #27ae60;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    border-left: 4px solid #27ae60;
    text-align: center;
}
@media (max-width: 768px) {
    .container {
        margin: 20px;
    }
    .form-container {
        padding: 20px;
    }
    .top-header {
        flex-direction: column;
        gap: 15px;
        text-align: center;
        padding: 15px;
    }
    .user-info {
        flex-wrap: wrap;
        justify-content: center;
    }
}
</style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

<!-- HEADER -->
<div class="top-header">
    <div style="font-size: 20px; font-weight: bold;">SISTEM PENGADUAN WARGA</div>
    <div class="user-info">
        <div class="avatar">
            <?= strtoupper(substr($user['nama_lengkap'], 0, 2)) ?>
        </div>
        <span style="font-weight: 500;"><?= htmlspecialchars($user['nama_lengkap']) ?></span>
        <a href="logout-masyarakat.php" class="logout">
            <i class="fas fa-sign-out-alt"></i> Logout
        </a>
    </div>
</div>

<!-- FORM -->
<div class="container">
    <div class="header">
        <h2>Form Pengaduan Warga</h2>
        <p style="margin-top: 10px; opacity: 0.9;">Sampaikan pengaduan Anda kepada pemerintah desa</p>
    </div>

    <div class="form-container">
        <?php if (isset($_GET['success'])): ?>
        <div class="success-message">
            <i class="fas fa-check-circle"></i>
            Pengaduan berhasil dikirim! Terima kasih telah melapor.
        </div>
        <?php endif; ?>
        
        <?php if (isset($_GET['error'])): ?>
        <div class="error-message">
            <i class="fas fa-exclamation-triangle"></i>
            Terjadi kesalahan saat menyimpan pengaduan. Silakan coba lagi.
        </div>
        <?php endif; ?>
        
        <form action="simpan-pengaduan.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
            
            <div class="form-group">
                <label>Nama Pelapor <span class="required">*</span></label>
                <input type="text" class="form-control" value="<?= htmlspecialchars($user['nama_lengkap']) ?>" readonly>
                <small style="color: #666; font-size: 13px;">Nama Anda (diambil dari data profil)</small>
            </div>

            <div class="form-group">
                <label>Kategori Pengaduan <span class="required">*</span></label>
                <select name="kategori" class="form-control" required>
                    <option value="">-- Pilih Kategori --</option>
                    <option value="Infrastruktur">Infrastruktur (Jalan, Jembatan, Drainase)</option>
                    <option value="Lingkungan">Lingkungan (Sampah, Kebersihan, Polusi)</option>
                    <option value="Kesehatan">Kesehatan (Fasilitas, Pelayanan Kesehatan)</option>
                    <option value="Keamanan">Keamanan (Pencurian, Konflik, Gangguan)</option>
                    <option value="Administrasi">Administrasi (Surat, Dokumen, Pelayanan)</option>
                    <option value="Lainnya">Lainnya</option>
                </select>
            </div>

            <div class="form-group">
                <label>Isi Pengaduan <span class="required">*</span></label>
                <textarea name="pesan" class="form-control" rows="5" 
                          placeholder="Tuliskan pengaduan secara lengkap dan jelas..." required></textarea>
            </div>

            <div class="form-group">
                <label>Lokasi Kejadian <span class="required">*</span></label>
                <input type="text" name="lokasi" class="form-control" 
                       placeholder="Contoh: Jl. Melati No. 10, RT 03/RW 01, Desa Contoh" required>
            </div>

            <div class="form-group">
                <label>Bukti Pendukung (Opsional)</label>
                <input type="file" name="bukti" class="form-control" 
                       accept="image/*,.pdf,.doc,.docx">
                <p class="file-info">Format: JPG, PNG, PDF, DOC (Maks. 5MB per file)</p>
            </div>

            <button type="submit" class="btn-submit">
                <i class="fas fa-paper-plane"></i> Kirim Pengaduan
            </button>

            <a href="index.php" class="back-link">← Kembali ke Beranda</a>
        </form>
    </div>
</div>

</body>
</html>