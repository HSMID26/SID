<?php
session_start();

/* HAPUS SEMUA SESSION */
session_unset();
session_destroy();

/* REDIRECT KE LOGIN */
header("Location: index.php");
exit;
