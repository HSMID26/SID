<?php
$host = "127.0.0.1"; // GANTI INI
$user = "root";
$pass = "";
$db   = "desa_sampora";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
