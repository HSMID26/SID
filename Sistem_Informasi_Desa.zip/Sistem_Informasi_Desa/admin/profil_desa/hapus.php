<?php
session_start();
include '../../koneksi.php';

/* ===============================
   CEK LOGIN ADMIN
================================ */
if (!isset($_SESSION['admin'])) {
    header("Location: ../../login.php");
    exit;
}

/* ===============================
   VALIDASI ID
================================ */
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$id = intval($_GET['id']);

/* ===============================
   AMBIL DATA PETA (JIKA ADA)
================================ */
$get = mysqli_prepare($conn, "SELECT peta_desa FROM profil_desa WHERE id = ?");
mysqli_stmt_bind_param($get, "i", $id);
mysqli_stmt_execute($get);
$result = mysqli_stmt_get_result($get);
$data = mysqli_fetch_assoc($result);

/* ===============================
   HAPUS FILE PETA
================================ */
if ($data && !empty($data['peta_desa'])) {
    $file = "../../uploads/" . $data['peta_desa'];
    if (file_exists($file)) {
        unlink($file);
    }
}

/* ===============================
   HAPUS DATA DATABASE
================================ */
$hapus = mysqli_prepare($conn, "DELETE FROM profil_desa WHERE id = ?");
mysqli_stmt_bind_param($hapus, "i", $id);
mysqli_stmt_execute($hapus);

/* ===============================
   KEMBALI KE INDEX
================================ */
header("Location: index.php?hapus=berhasil");
exit;
