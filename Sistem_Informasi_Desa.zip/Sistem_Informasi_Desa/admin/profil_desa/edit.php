<?php
session_start();
include '../../koneksi.php';

if (!isset($_SESSION['admin'])) {
    header("Location: ../../login.php");
    exit;
}

$id = $_GET['id'] ?? null;
if (!$id) {
    header("Location: index.php");
    exit;
}

$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM profil_desa WHERE id='$id'"));

if (!$data) {
    header("Location: index.php");
    exit;
}

$success = "";
$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_desa = mysqli_real_escape_string($conn, trim($_POST['nama_desa']));
    $alamat    = mysqli_real_escape_string($conn, trim($_POST['alamat']));
    
    if (empty($nama_desa) || empty($alamat)) {
        $error = "Nama desa dan alamat tidak boleh kosong!";
    } else {
        // Handle file upload
        if (!empty($_FILES['peta_desa']['name'])) {
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'svg'];
            $ext = strtolower(pathinfo($_FILES['peta_desa']['name'], PATHINFO_EXTENSION));
            
            if (!in_array($ext, $allowed)) {
                $error = "Format file harus JPG, PNG, GIF, atau SVG!";
            } else if ($_FILES['peta_desa']['size'] > 5 * 1024 * 1024) {
                $error = "Ukuran file maksimal 5MB!";
            } else {
                $peta = time() . '_' . basename($_FILES['peta_desa']['name']);
                $upload_path = "../../uploads/" . $peta;
                
                if (move_uploaded_file($_FILES['peta_desa']['tmp_name'], $upload_path)) {
                    // Hapus file lama jika ada dan bukan default
                    if (!empty($data['peta_desa']) && $data['peta_desa'] != 'default_map.png') {
                        @unlink("../../uploads/" . $data['peta_desa']);
                    }
                    
                    mysqli_query($conn, "UPDATE profil_desa SET peta_desa='$peta' WHERE id='$id'");
                } else {
                    $error = "Gagal mengupload peta desa!";
                }
            }
        }
        
        if (empty($error)) {
            $update_query = "UPDATE profil_desa 
                            SET nama_desa='$nama_desa', alamat='$alamat'
                            WHERE id='$id'";
            
            if (mysqli_query($conn, $update_query)) {
                $success = "Profil desa berhasil diperbarui!";
                $data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM profil_desa WHERE id='$id'"));
            } else {
                $error = "Gagal memperbarui profil desa!";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profil Desa - Admin Desa</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            padding: 20px;
            color: #333;
        }

        .container {
            max-width: 900px;
            margin: 40px auto;
            background: white;
            border-radius: 16px;
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.12);
            overflow: hidden;
        }

        .header {
            background: linear-gradient(to right, #2e8b57, #3cb371);
            color: white;
            padding: 30px;
            position: relative;
        }

        .header h1 {
            font-size: 28px;
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 8px;
        }

        .header h1 i {
            background: rgba(255, 255, 255, 0.2);
            padding: 12px;
            border-radius: 10px;
            font-size: 22px;
        }

        .header p {
            opacity: 0.9;
            font-size: 15px;
            margin-left: 57px;
        }

        .back-link {
            position: absolute;
            right: 30px;
            top: 35px;
            color: white;
            text-decoration: none;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 8px;
            background: rgba(255, 255, 255, 0.15);
            padding: 10px 18px;
            border-radius: 30px;
            transition: all 0.3s;
        }

        .back-link:hover {
            background: rgba(255, 255, 255, 0.25);
            transform: translateX(-5px);
        }

        .content {
            padding: 40px;
        }

        .alert {
            padding: 16px 20px;
            margin-bottom: 25px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: fadeIn 0.3s ease;
        }

        .alert-success {
            background: #d4edda;
            border-left: 4px solid #28a745;
            color: #155724;
        }

        .alert-error {
            background: #ffeaea;
            border-left: 4px solid #ff5252;
            color: #d32f2f;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            margin-bottom: 10px;
            font-weight: 600;
            color: #444;
            font-size: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .form-group label i {
            color: #2e8b57;
            width: 20px;
        }

        .form-group input[type="text"],
        .form-group textarea {
            width: 100%;
            padding: 16px 18px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 15px;
            transition: all 0.3s;
            background: #fafafa;
        }

        .form-group input[type="text"]:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #2e8b57;
            background: white;
            box-shadow: 0 0 0 4px rgba(46, 139, 87, 0.1);
        }

        .form-group textarea {
            resize: vertical;
            min-height: 120px;
            line-height: 1.6;
        }

        .char-count {
            text-align: right;
            font-size: 13px;
            color: #777;
            margin-top: 8px;
        }

        .current-image {
            margin-top: 15px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 8px;
            border: 1px solid #eee;
        }

        .current-image h4 {
            color: #2e8b57;
            margin-bottom: 10px;
            font-size: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .image-preview {
            max-width: 200px;
            max-height: 150px;
            border-radius: 6px;
            border: 2px solid #ddd;
            margin-top: 10px;
        }

        .file-upload {
            position: relative;
            margin-top: 10px;
        }

        .file-upload input[type="file"] {
            position: absolute;
            width: 100%;
            height: 100%;
            opacity: 0;
            cursor: pointer;
            z-index: 2;
        }

        .file-upload-label {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            padding: 18px;
            border: 2px dashed #ddd;
            border-radius: 10px;
            background: #f9f9f9;
            color: #666;
            font-weight: 500;
            transition: all 0.3s;
            cursor: pointer;
        }

        .file-upload-label:hover {
            border-color: #2e8b57;
            background: #f0f9f4;
            color: #2e8b57;
        }

        .file-upload-label i {
            font-size: 20px;
        }

        .file-info {
            font-size: 13px;
            color: #777;
            margin-top: 8px;
            margin-left: 5px;
        }

        .preview-box {
            margin-top: 15px;
            text-align: center;
            display: none;
        }

        .preview-img {
            max-width: 200px;
            max-height: 150px;
            border-radius: 8px;
            border: 2px solid #eee;
            margin-bottom: 10px;
        }

        .info-box {
            background: #f0f9ff;
            border-left: 4px solid #17a2b8;
            padding: 15px 20px;
            margin-bottom: 25px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .info-box i {
            color: #17a2b8;
            font-size: 18px;
        }

        .button-group {
            display: flex;
            gap: 15px;
            margin-top: 35px;
            padding-top: 25px;
            border-top: 1px solid #eee;
        }

        .btn {
            padding: 16px 30px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            border: none;
            text-decoration: none;
            flex: 1;
        }

        .btn-primary {
            background: linear-gradient(to right, #2e8b57, #3cb371);
            color: white;
            box-shadow: 0 4px 15px rgba(46, 139, 87, 0.3);
        }

        .btn-primary:hover {
            background: linear-gradient(to right, #26734d, #2e8b57);
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(46, 139, 87, 0.4);
        }

        .btn-secondary {
            background: #f5f5f5;
            color: #666;
            border: 1px solid #ddd;
        }

        .btn-secondary:hover {
            background: #e9e9e9;
            transform: translateY(-3px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 768px) {
            .container {
                margin: 20px auto;
                border-radius: 12px;
            }
            
            .content {
                padding: 25px;
            }
            
            .header {
                padding: 25px 20px;
            }
            
            .header h1 {
                font-size: 24px;
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
            
            .header p {
                margin-left: 0;
                margin-top: 5px;
            }
            
            .back-link {
                position: relative;
                right: auto;
                top: auto;
                display: inline-flex;
                margin-top: 15px;
                width: 100%;
                justify-content: center;
            }
            
            .button-group {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <h1>
            <i class="fas fa-edit"></i>
            Edit Profil Desa
        </h1>
        <p>Perbarui informasi dan peta wilayah desa</p>
        <a href="index.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Kembali ke Profil
        </a>
    </div>
    
    <div class="content">
        <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <span><?= htmlspecialchars($success) ?></span>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i>
                <span><?= htmlspecialchars($error) ?></span>
            </div>
        <?php endif; ?>

        <form method="post" enctype="multipart/form-data" id="profilForm">
            <div class="form-group">
                <label for="nama_desa">
                    <i class="fas fa-home"></i>
                    Nama Desa
                </label>
                <input type="text" id="nama_desa" name="nama_desa" 
                       value="<?= htmlspecialchars($data['nama_desa']) ?>"
                       placeholder="Masukkan nama desa lengkap"
                       maxlength="100"
                       required>
                <div class="char-count" id="namaCount"><?= strlen($data['nama_desa']) ?>/100 karakter</div>
            </div>
            
            <div class="form-group">
                <label for="alamat">
                    <i class="fas fa-map-marker-alt"></i>
                    Alamat Lengkap Desa
                </label>
                <textarea id="alamat" name="alamat" 
                          placeholder="Masukkan alamat lengkap desa termasuk kecamatan dan kabupaten"
                          rows="4"
                          required><?= htmlspecialchars($data['alamat']) ?></textarea>
                <div class="char-count" id="alamatCount"><?= strlen($data['alamat']) ?> karakter</div>
            </div>
            
            <div class="form-group">
                <label for="peta_desa">
                    <i class="fas fa-map"></i>
                    Peta Desa (Opsional untuk diganti)
                </label>
                
                <?php if (!empty($data['peta_desa'])): ?>
                <div class="current-image">
                    <h4>
                        <i class="fas fa-image"></i>
                        Peta Desa Saat Ini
                    </h4>
                    <p style="font-size: 14px; color: #666; margin-bottom: 8px;">
                        File: <?= htmlspecialchars($data['peta_desa']) ?>
                    </p>
                    <?php if (file_exists("../../uploads/" . $data['peta_desa'])): ?>
                    <img src="../../uploads/<?= htmlspecialchars($data['peta_desa']) ?>" 
                         class="image-preview" 
                         alt="Peta Desa Saat Ini">
                    <?php else: ?>
                    <p style="color: #ff9800; font-size: 14px;">
                        <i class="fas fa-exclamation-triangle"></i>
                        File peta tidak ditemukan di server
                    </p>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
                
                <div class="file-upload">
                    <input type="file" id="peta_desa" name="peta_desa" 
                           accept=".jpg,.jpeg,.png,.gif,.svg"
                           onchange="previewImage(this)">
                    <div class="file-upload-label">
                        <i class="fas fa-cloud-upload-alt"></i>
                        <span>Klik untuk memilih file peta baru</span>
                    </div>
                </div>
                <div class="file-info">
                    <i class="fas fa-info-circle"></i>
                    Format: JPG, PNG, GIF, SVG | Maksimal: 5MB
                </div>
                <div class="preview-box" id="previewBox">
                    <img id="previewImg" class="preview-img" src="" alt="Preview Peta">
                    <div style="font-size: 14px; color: #666;">Preview Peta Baru</div>
                </div>
            </div>

            <div class="info-box">
                <i class="fas fa-lightbulb"></i>
                <span><strong>Catatan:</strong> Kosongkan jika tidak ingin mengganti peta desa saat ini.</span>
            </div>
            
            <div class="button-group">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i>
                    Simpan Perubahan
                </button>
                <a href="index.php" class="btn btn-secondary">
                    <i class="fas fa-times"></i>
                    Batal
                </a>
            </div>
        </form>
    </div>
</div>

<script>
    // Fungsi untuk menghitung karakter
    function updateCharCount(element, counterId, maxLength = null) {
        const count = element.value.length;
        const counter = document.getElementById(counterId);
        
        if (maxLength) {
            counter.textContent = `${count}/${maxLength} karakter`;
            if (count > maxLength * 0.9) {
                counter.style.color = '#ff5252';
                counter.innerHTML += ' <i class="fas fa-exclamation-triangle"></i>';
            } else if (count > maxLength * 0.7) {
                counter.style.color = '#ff9800';
            } else {
                counter.style.color = '#777';
            }
        } else {
            counter.textContent = `${count} karakter`;
        }
    }
    
    // Fungsi preview gambar
    function previewImage(input) {
        const previewBox = document.getElementById('previewBox');
        const previewImg = document.getElementById('previewImg');
        
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            
            reader.onload = function(e) {
                previewImg.src = e.target.result;
                previewBox.style.display = 'block';
            }
            
            reader.readAsDataURL(input.files[0]);
            
            // Update label
            const fileName = input.files[0].name;
            document.querySelector('.file-upload-label span').innerHTML = 
                `<i class="fas fa-check-circle" style="color:#2e8b57"></i> ${fileName}`;
        } else {
            previewBox.style.display = 'none';
            document.querySelector('.file-upload-label span').innerHTML = 
                '<i class="fas fa-cloud-upload-alt"></i> Klik untuk memilih file peta baru';
        }
    }
    
    // Inisialisasi event listeners
    document.addEventListener('DOMContentLoaded', function() {
        const namaInput = document.getElementById('nama_desa');
        const alamatTextarea = document.getElementById('alamat');
        
        namaInput.addEventListener('input', function() {
            updateCharCount(this, 'namaCount', 100);
        });
        
        alamatTextarea.addEventListener('input', function() {
            updateCharCount(this, 'alamatCount');
        });
        
        // Validasi form
        document.getElementById('profilForm').addEventListener('submit', function(e) {
            const nama = namaInput.value.trim();
            const alamat = alamatTextarea.value.trim();
            
            if (nama === '' || alamat === '') {
                e.preventDefault();
                alert('Nama desa dan alamat tidak boleh kosong!');
                return false;
            }
            
            if (nama.length > 100) {
                e.preventDefault();
                alert('Nama desa tidak boleh lebih dari 100 karakter!');
                return false;
            }
            
            // Validasi file jika ada
            const fileInput = document.getElementById('peta_desa');
            if (fileInput.files.length > 0) {
                const fileSize = fileInput.files[0].size / 1024 / 1024; // MB
                if (fileSize > 5) {
                    e.preventDefault();
                    alert('Ukuran file maksimal 5MB!');
                    return false;
                }
                
                const allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'svg'];
                const fileName = fileInput.files[0].name;
                const extension = fileName.split('.').pop().toLowerCase();
                
                if (!allowedExtensions.includes(extension)) {
                    e.preventDefault();
                    alert('Format file harus JPG, PNG, GIF, atau SVG!');
                    return false;
                }
            }
        });
    });
</script>

</body>
</html>