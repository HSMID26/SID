<?php
session_start();
include '../../koneksi.php';

if (!isset($_SESSION['admin'])) {
    header("Location: ../../login.php");
    exit;
}

// Ambil data profil desa
$query = mysqli_query($conn, "SELECT * FROM profil_desa ORDER BY id DESC");
$total_profil = mysqli_num_rows($query);
mysqli_data_seek($query, 0); // Reset pointer untuk loop
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Profil Desa - Admin Desa</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            color: #333;
        }

        .admin-container {
            max-width: 1300px;
            margin: 0 auto;
            padding: 30px;
        }

        .header-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 20px;
        }

        .page-title {
            font-size: 28px;
            font-weight: 700;
            color: #2e8b57;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .page-title i {
            background: linear-gradient(135deg, #2e8b57, #3cb371);
            padding: 12px;
            border-radius: 10px;
            color: white;
            font-size: 22px;
        }

        .action-buttons {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 12px 24px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 15px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }

        .btn-primary {
            background: linear-gradient(to right, #2e8b57, #3cb371);
            color: white;
            box-shadow: 0 4px 12px rgba(46, 139, 87, 0.2);
        }

        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 18px rgba(46, 139, 87, 0.3);
            background: linear-gradient(to right, #26734d, #2e8b57);
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background: #5a6268;
            transform: translateY(-3px);
        }

        .btn-view {
            background: #17a2b8;
            color: white;
            padding: 6px 12px;
            font-size: 13px;
            border-radius: 5px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: all 0.2s;
        }

        .btn-view:hover {
            background: #138496;
            transform: translateY(-2px);
        }

        .btn-edit {
            background: #28a745;
            color: white;
            padding: 6px 12px;
            font-size: 13px;
            border-radius: 5px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: all 0.2s;
        }

        .btn-edit:hover {
            background: #218838;
            transform: translateY(-2px);
        }

        .btn-delete {
            background: #dc3545;
            color: white;
            padding: 6px 12px;
            font-size: 13px;
            border-radius: 5px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: all 0.2s;
        }

        .btn-delete:hover {
            background: #c82333;
            transform: translateY(-2px);
        }

        .stats-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .stats-icon {
            background: linear-gradient(135deg, #2e8b57, #3cb371);
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 22px;
        }

        .stats-info h3 {
            font-size: 28px;
            color: #2e8b57;
            margin-bottom: 5px;
        }

        .stats-info p {
            color: #6c757d;
            font-size: 14px;
        }

        .table-container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
            overflow: hidden;
            margin-bottom: 30px;
        }

        .table-responsive {
            overflow-x: auto;
        }

        .profile-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1000px;
        }

        .profile-table thead {
            background: linear-gradient(to right, #2e8b57, #3cb371);
        }

        .profile-table th {
            padding: 18px 20px;
            color: white;
            font-weight: 600;
            text-align: left;
            font-size: 15px;
            white-space: nowrap;
        }

        .profile-table th:first-child {
            width: 60px;
            text-align: center;
        }

        .profile-table th:nth-child(2) {
            width: 200px;
        }

        .profile-table th:nth-child(3) {
            min-width: 300px;
        }

        .profile-table th:nth-child(4) {
            width: 150px;
            text-align: center;
        }

        .profile-table th:last-child {
            width: 180px;
            text-align: center;
        }

        .profile-table tbody tr {
            border-bottom: 1px solid #f0f0f0;
            transition: all 0.2s;
        }

        .profile-table tbody tr:hover {
            background: #f8f9fa;
            transform: translateX(3px);
        }

        .profile-table td {
            padding: 16px 20px;
            vertical-align: middle;
        }

        .profile-table td:first-child {
            text-align: center;
            font-weight: 600;
            color: #2e8b57;
        }

        .desa-name {
            font-weight: 600;
            color: #333;
            font-size: 15px;
            line-height: 1.4;
        }

        .desa-address {
            font-size: 14px;
            color: #666;
            margin-top: 5px;
            line-height: 1.4;
            max-width: 400px;
        }

        .map-cell {
            text-align: center;
        }

        .no-map {
            color: #999;
            font-style: italic;
            font-size: 14px;
        }

        .map-badge {
            background: #e3f2fd;
            color: #1976d2;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
        }

        .action-buttons-cell {
            display: flex;
            gap: 8px;
            justify-content: center;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #6c757d;
        }

        .empty-state i {
            font-size: 48px;
            color: #ddd;
            margin-bottom: 15px;
        }

        .empty-state p {
            font-size: 16px;
            margin-bottom: 20px;
        }

        .back-dashboard {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: #2e8b57;
            text-decoration: none;
            font-weight: 600;
            padding: 12px 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);
            transition: all 0.3s;
        }

        .back-dashboard:hover {
            background: #f8f9fa;
            transform: translateX(-5px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .badge-id {
            display: inline-block;
            padding: 2px 6px;
            background: #f8f9fa;
            color: #6c757d;
            border-radius: 4px;
            font-size: 11px;
            margin-left: 5px;
        }

        @media (max-width: 992px) {
            .admin-container {
                padding: 20px;
            }
            
            .header-section {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .action-buttons {
                width: 100%;
            }
            
            .btn {
                flex: 1;
                justify-content: center;
            }
            
            .profile-table td, .profile-table th {
                padding: 12px 15px;
            }
            
            .action-buttons-cell {
                flex-direction: column;
                gap: 6px;
            }
            
            .btn-view, .btn-edit, .btn-delete {
                width: 100%;
                justify-content: center;
                padding: 8px 12px;
            }
        }
    </style>
</head>
<body>

<div class="admin-container">
    <!-- Header Section -->
    <div class="header-section">
        <div>
            <h1 class="page-title">
                <i class="fas fa-home"></i>
                Kelola Profil Desa
            </h1>
            <p style="color: #6c757d; margin-top: 5px;">Kelola informasi dan peta wilayah desa</p>
        </div>
        
        <div class="action-buttons">
            <a href="tambah.php" class="btn btn-primary">
                <i class="fas fa-plus-circle"></i>
                Tambah Profil Desa
            </a>
            <a href="../dashboard.php" class="btn btn-secondary">
                <i class="fas fa-tachometer-alt"></i>
                Dashboard
            </a>
        </div>
    </div>

    <!-- Stats Card -->
    <div class="stats-card">
        <div class="stats-icon">
            <i class="fas fa-city"></i>
        </div>
        <div class="stats-info">
            <h3><?= $total_profil ?></h3>
            <p>Total Data Profil Desa</p>
        </div>
    </div>

    <!-- Profile Table -->
    <div class="table-container">
        <div class="table-responsive">
            <table class="profile-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Desa</th>
                        <th>Alamat</th>
                        <th>Peta Desa</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($query && mysqli_num_rows($query) > 0): 
                        $no = 1;
                        while ($row = mysqli_fetch_assoc($query)): 
                            $truncated_address = strlen($row['alamat']) > 100 ? 
                                substr($row['alamat'], 0, 97) . '...' : 
                                $row['alamat'];
                    ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td>
                            <div class="desa-name">
                                <?= htmlspecialchars($row['nama_desa']) ?>
                                <span class="badge-id">#<?= $row['id'] ?></span>
                            </div>
                        </td>
                        <td>
                            <div class="desa-address">
                                <?= htmlspecialchars($truncated_address) ?>
                            </div>
                        </td>
                        <td class="map-cell">
                            <?php if (!empty($row['peta_desa']) && file_exists("../../uploads/" . $row['peta_desa'])): ?>
                                <a href="../../uploads/<?= htmlspecialchars($row['peta_desa']) ?>" 
                                   class="btn-view" target="_blank">
                                    <i class="fas fa-external-link-alt"></i>
                                    Lihat Peta
                                </a>
                                <div class="map-badge" style="margin-top: 5px; font-size: 11px;">
                                    <?= htmlspecialchars($row['peta_desa']) ?>
                                </div>
                            <?php else: ?>
                                <span class="no-map">
                                    <i class="fas fa-map-marker-alt"></i>
                                    Tidak ada peta
                                </span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="action-buttons-cell">
                                <a href="edit.php?id=<?= $row['id']; ?>" class="btn-edit">
                                    <i class="fas fa-edit"></i> Edit
                                </a>
                                <a href="hapus.php?id=<?= $row['id']; ?>" 
                                   class="btn-delete"
                                   onclick="return confirm('Apakah Anda yakin ingin menghapus profil desa ini?\n\nDesa: <?= addslashes(htmlspecialchars($row['nama_desa'])) ?>')">
                                    <i class="fas fa-trash-alt"></i> Hapus
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                    
                    <?php else: ?>
                    <tr>
                        <td colspan="5">
                            <div class="empty-state">
                                <i class="far fa-building"></i>
                                <p>Belum ada profil desa yang ditambahkan</p>
                                <a href="tambah.php" class="btn btn-primary">
                                    <i class="fas fa-plus-circle"></i>
                                    Tambah Profil Desa Pertama
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Back to Dashboard -->
    <a href="../dashboard.php" class="back-dashboard">
        <i class="fas fa-arrow-left"></i>
        Kembali ke Dashboard Admin
    </a>
</div>

<script>
    // Efek hover untuk baris tabel
    document.querySelectorAll('.profile-table tbody tr').forEach(row => {
        row.addEventListener('mouseenter', function() {
            this.style.boxShadow = '0 3px 10px rgba(0,0,0,0.05)';
        });
        
        row.addEventListener('mouseleave', function() {
            this.style.boxShadow = 'none';
        });
    });

    // Konfirmasi penghapusan yang lebih baik
    document.querySelectorAll('.btn-delete').forEach(button => {
        button.addEventListener('click', function(e) {
            const desaName = this.closest('tr').querySelector('.desa-name').textContent.trim();
            if (!confirm(`Yakin ingin menghapus profil desa:\n"${desaName}"?`)) {
                e.preventDefault();
            }
        });
    });

    // Efek hover untuk semua tombol
    document.querySelectorAll('.btn').forEach(btn => {
        btn.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-3px)';
        });
        
        btn.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });

    // Preview peta dalam modal
    document.querySelectorAll('.btn-view').forEach(button => {
        button.addEventListener('click', function(e) {
            // Buka di tab baru (default behavior)
            // Bisa juga ditambahkan modal preview jika diperlukan
            console.log('Membuka peta desa...');
        });
    });
</script>

</body>
</html>