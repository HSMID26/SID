<?php
session_start();
include '../../koneksi.php';

/* ===============================
   CEK LOGIN ADMIN
================================ */
if (!isset($_SESSION['admin'])) {
    header("Location: ../../login.php");
    exit;
}

$error = "";
$success = "";

/* ===============================
   PROSES SIMPAN DATA
================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_desa = trim($_POST['nama_desa']);
    $alamat    = trim($_POST['alamat']);
    $peta      = null;

    if (empty($nama_desa) || empty($alamat)) {
        $error = "Nama desa dan alamat tidak boleh kosong!";
    } else {
        /* ===============================
           UPLOAD PETA DESA
        ================================ */
        if (!empty($_FILES['peta_desa']['name'])) {
            $allowed = ['jpg', 'jpeg', 'png', 'pdf', 'gif', 'svg'];
            $ext = strtolower(pathinfo($_FILES['peta_desa']['name'], PATHINFO_EXTENSION));

            if (!in_array($ext, $allowed)) {
                $error = "Format file tidak diizinkan! Hanya JPG, PNG, PDF, GIF, SVG yang diperbolehkan.";
            } else if ($_FILES['peta_desa']['size'] > 5 * 1024 * 1024) {
                $error = "Ukuran file maksimal 5MB!";
            } else {
                // Pastikan folder uploads ada
                $uploadDir = "../../uploads/";
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0777, true);
                }

                $peta = time() . '_' . basename($_FILES['peta_desa']['name']);
                if (!move_uploaded_file($_FILES['peta_desa']['tmp_name'], $uploadDir . $peta)) {
                    $error = "Gagal mengupload file!";
                }
            }
        }

        if (empty($error)) {
            /* ===============================
               SIMPAN KE DATABASE (AMAN)
            ================================ */
            $stmt = mysqli_prepare($conn, "
                INSERT INTO profil_desa (nama_desa, alamat, peta_desa)
                VALUES (?, ?, ?)
            ");
            mysqli_stmt_bind_param($stmt, "sss", $nama_desa, $alamat, $peta);
            
            if (mysqli_stmt_execute($stmt)) {
                $success = "Profil desa berhasil ditambahkan!";
                // Reset form values
                $_POST['nama_desa'] = '';
                $_POST['alamat'] = '';
            } else {
                $error = "Gagal menyimpan profil desa!";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Profil Desa - Admin Desa</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            padding: 20px;
            color: #333;
        }

        .container {
            max-width: 800px;
            margin: 40px auto;
            background: white;
            border-radius: 16px;
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.12);
            overflow: hidden;
        }

        .header {
            background: linear-gradient(to right, #2e8b57, #3cb371);
            color: white;
            padding: 30px;
            position: relative;
        }

        .header h1 {
            font-size: 28px;
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 8px;
        }

        .header h1 i {
            background: rgba(255, 255, 255, 0.2);
            padding: 12px;
            border-radius: 10px;
            font-size: 22px;
        }

        .header p {
            opacity: 0.9;
            font-size: 15px;
            margin-left: 57px;
        }

        .back-link {
            position: absolute;
            right: 30px;
            top: 35px;
            color: white;
            text-decoration: none;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 8px;
            background: rgba(255, 255, 255, 0.15);
            padding: 10px 18px;
            border-radius: 30px;
            transition: all 0.3s;
        }

        .back-link:hover {
            background: rgba(255, 255, 255, 0.25);
            transform: translateX(-5px);
        }

        .content {
            padding: 40px;
        }

        .alert {
            padding: 16px 20px;
            margin-bottom: 25px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: fadeIn 0.3s ease;
        }

        .alert-success {
            background: #d4edda;
            border-left: 4px solid #28a745;
            color: #155724;
        }

        .alert-error {
            background: #ffeaea;
            border-left: 4px solid #ff5252;
            color: #d32f2f;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            margin-bottom: 10px;
            font-weight: 600;
            color: #444;
            font-size: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .form-group label i {
            color: #2e8b57;
            width: 20px;
        }

        .form-group input[type="text"],
        .form-group textarea {
            width: 100%;
            padding: 16px 18px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 15px;
            transition: all 0.3s;
            background: #fafafa;
        }

        .form-group input[type="text"]:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #2e8b57;
            background: white;
            box-shadow: 0 0 0 4px rgba(46, 139, 87, 0.1);
        }

        .form-group textarea {
            resize: vertical;
            min-height: 120px;
            line-height: 1.6;
        }

        .char-count {
            text-align: right;
            font-size: 13px;
            color: #777;
            margin-top: 8px;
        }

        .file-upload {
            position: relative;
            margin-top: 10px;
        }

        .file-upload input[type="file"] {
            position: absolute;
            width: 100%;
            height: 100%;
            opacity: 0;
            cursor: pointer;
            z-index: 2;
        }

        .file-upload-label {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            padding: 18px;
            border: 2px dashed #ddd;
            border-radius: 10px;
            background: #f9f9f9;
            color: #666;
            font-weight: 500;
            transition: all 0.3s;
            cursor: pointer;
        }

        .file-upload-label:hover {
            border-color: #2e8b57;
            background: #f0f9f4;
            color: #2e8b57;
        }

        .file-upload-label i {
            font-size: 20px;
        }

        .file-info {
            font-size: 13px;
            color: #777;
            margin-top: 8px;
            margin-left: 5px;
        }

        .preview-box {
            margin-top: 15px;
            text-align: center;
            display: none;
        }

        .preview-img {
            max-width: 200px;
            max-height: 150px;
            border-radius: 8px;
            border: 2px solid #eee;
            margin-bottom: 10px;
        }

        .example-box {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 25px;
            border: 1px dashed #ddd;
        }

        .example-box h4 {
            color: #2e8b57;
            margin-bottom: 10px;
            font-size: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .example-content {
            font-size: 14px;
            color: #666;
            line-height: 1.5;
        }

        .example-content ul {
            padding-left: 20px;
            margin-top: 8px;
        }

        .info-box {
            background: #f0f9ff;
            border-left: 4px solid #17a2b8;
            padding: 15px 20px;
            margin-bottom: 25px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .info-box i {
            color: #17a2b8;
            font-size: 18px;
        }

        .button-group {
            display: flex;
            gap: 15px;
            margin-top: 35px;
            padding-top: 25px;
            border-top: 1px solid #eee;
        }

        .btn {
            padding: 16px 30px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            border: none;
            text-decoration: none;
            flex: 1;
        }

        .btn-primary {
            background: linear-gradient(to right, #2e8b57, #3cb371);
            color: white;
            box-shadow: 0 4px 15px rgba(46, 139, 87, 0.3);
        }

        .btn-primary:hover {
            background: linear-gradient(to right, #26734d, #2e8b57);
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(46, 139, 87, 0.4);
        }

        .btn-secondary {
            background: #f5f5f5;
            color: #666;
            border: 1px solid #ddd;
        }

        .btn-secondary:hover {
            background: #e9e9e9;
            transform: translateY(-3px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 768px) {
            .container {
                margin: 20px auto;
                border-radius: 12px;
            }
            
            .content {
                padding: 25px;
            }
            
            .header {
                padding: 25px 20px;
            }
            
            .header h1 {
                font-size: 24px;
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
            
            .header p {
                margin-left: 0;
                margin-top: 5px;
            }
            
            .back-link {
                position: relative;
                right: auto;
                top: auto;
                display: inline-flex;
                margin-top: 15px;
                width: 100%;
                justify-content: center;
            }
            
            .button-group {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <h1>
            <i class="fas fa-plus-circle"></i>
            Tambah Profil Desa Baru
        </h1>
        <p>Isi formulir di bawah untuk menambahkan data profil desa</p>
        <a href="index.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Kembali ke Daftar
        </a>
    </div>
    
    <div class="content">
        <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <span><?= htmlspecialchars($success) ?></span>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i>
                <span><?= htmlspecialchars($error) ?></span>
            </div>
        <?php endif; ?>

        <div class="example-box">
            <h4>
                <i class="fas fa-lightbulb"></i>
                Contoh Data Profil Desa
            </h4>
            <div class="example-content">
                <p><strong>Nama Desa:</strong> "Desa Sampora"</p>
                <p><strong>Alamat:</strong> "Jl. Raya Sampora No. 123, Kecamatan Ciputat, Kabupaten Tangerang Selatan, Banten 15412"</p>
                <p><strong>Peta:</strong> File gambar peta wilayah atau PDF denah desa</p>
            </div>
        </div>

        <form method="post" enctype="multipart/form-data" id="profilForm">
            <div class="form-group">
                <label for="nama_desa">
                    <i class="fas fa-home"></i>
                    Nama Desa
                </label>
                <input type="text" id="nama_desa" name="nama_desa" 
                       value="<?= htmlspecialchars($_POST['nama_desa'] ?? '') ?>"
                       placeholder="Masukkan nama desa lengkap"
                       maxlength="100"
                       required>
                <div class="char-count" id="namaCount">0/100 karakter</div>
            </div>
            
            <div class="form-group">
                <label for="alamat">
                    <i class="fas fa-map-marker-alt"></i>
                    Alamat Lengkap Desa
                </label>
                <textarea id="alamat" name="alamat" 
                          placeholder="Masukkan alamat lengkap desa termasuk kecamatan, kabupaten, dan kode pos"
                          rows="4"
                          required><?= htmlspecialchars($_POST['alamat'] ?? '') ?></textarea>
                <div class="char-count" id="alamatCount">0 karakter</div>
            </div>
            
            <div class="form-group">
                <label for="peta_desa">
                    <i class="fas fa-map"></i>
                    Peta Desa (Opsional)
                </label>
                
                <div class="file-upload">
                    <input type="file" id="peta_desa" name="peta_desa" 
                           accept=".jpg,.jpeg,.png,.pdf,.gif,.svg"
                           onchange="previewImage(this)">
                    <div class="file-upload-label">
                        <i class="fas fa-cloud-upload-alt"></i>
                        <span>Klik untuk memilih file peta</span>
                    </div>
                </div>
                <div class="file-info">
                    <i class="fas fa-info-circle"></i>
                    Format: JPG, PNG, PDF, GIF, SVG | Maksimal: 5MB
                </div>
                <div class="preview-box" id="previewBox">
                    <img id="previewImg" class="preview-img" src="" alt="Preview Peta">
                    <div style="font-size: 14px; color: #666;">Preview Peta</div>
                </div>
            </div>

            <div class="info-box">
                <i class="fas fa-info-circle"></i>
                <span><strong>Catatan:</strong> Peta desa bersifat opsional. Anda dapat menambahkannya nanti melalui fitur edit.</span>
            </div>
            
            <div class="button-group">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i>
                    Simpan Profil Desa
                </button>
                <a href="index.php" class="btn btn-secondary">
                    <i class="fas fa-times"></i>
                    Batal
                </a>
            </div>
        </form>
    </div>
</div>

<script>
    // Fungsi untuk menghitung karakter
    function updateCharCount(element, counterId, maxLength = null) {
        const count = element.value.length;
        const counter = document.getElementById(counterId);
        
        if (maxLength) {
            counter.textContent = `${count}/${maxLength} karakter`;
            if (count > maxLength * 0.9) {
                counter.style.color = '#ff5252';
                counter.innerHTML += ' <i class="fas fa-exclamation-triangle"></i>';
            } else if (count > maxLength * 0.7) {
                counter.style.color = '#ff9800';
            } else {
                counter.style.color = '#777';
            }
        } else {
            counter.textContent = `${count} karakter`;
        }
    }
    
    // Fungsi preview gambar (hanya untuk file gambar)
    function previewImage(input) {
        const previewBox = document.getElementById('previewBox');
        const previewImg = document.getElementById('previewImg');
        
        if (input.files && input.files[0]) {
            const file = input.files[0];
            const fileName = file.name;
            const fileExtension = fileName.split('.').pop().toLowerCase();
            
            // Update label
            document.querySelector('.file-upload-label span').innerHTML = 
                `<i class="fas fa-check-circle" style="color:#2e8b57"></i> ${fileName}`;
            
            // Preview hanya untuk file gambar
            const imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'svg'];
            
            if (imageExtensions.includes(fileExtension)) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    previewImg.src = e.target.result;
                    previewBox.style.display = 'block';
                }
                
                reader.readAsDataURL(file);
            } else if (fileExtension === 'pdf') {
                previewBox.style.display = 'block';
                previewImg.src = 'https://cdn-icons-png.flaticon.com/512/337/337946.png';
                previewImg.style.padding = '20px';
                previewImg.style.backgroundColor = '#f0f0f0';
            } else {
                previewBox.style.display = 'none';
            }
        } else {
            previewBox.style.display = 'none';
            document.querySelector('.file-upload-label span').innerHTML = 
                '<i class="fas fa-cloud-upload-alt"></i> Klik untuk memilih file peta';
        }
    }
    
    // Inisialisasi event listeners
    document.addEventListener('DOMContentLoaded', function() {
        const namaInput = document.getElementById('nama_desa');
        const alamatTextarea = document.getElementById('alamat');
        
        namaInput.addEventListener('input', function() {
            updateCharCount(this, 'namaCount', 100);
        });
        
        alamatTextarea.addEventListener('input', function() {
            updateCharCount(this, 'alamatCount');
        });
        
        // Set nilai awal
        updateCharCount(namaInput, 'namaCount', 100);
        updateCharCount(alamatTextarea, 'alamatCount');
        
        // Validasi form
        document.getElementById('profilForm').addEventListener('submit', function(e) {
            const nama = namaInput.value.trim();
            const alamat = alamatTextarea.value.trim();
            
            if (nama === '' || alamat === '') {
                e.preventDefault();
                alert('Nama desa dan alamat tidak boleh kosong!');
                return false;
            }
            
            if (nama.length > 100) {
                e.preventDefault();
                alert('Nama desa tidak boleh lebih dari 100 karakter!');
                return false;
            }
            
            if (alamat.length < 10) {
                e.preventDefault();
                alert('Alamat terlalu pendek! Minimal 10 karakter.');
                return false;
            }
            
            // Validasi file jika ada
            const fileInput = document.getElementById('peta_desa');
            if (fileInput.files.length > 0) {
                const fileSize = fileInput.files[0].size / 1024 / 1024; // MB
                if (fileSize > 5) {
                    e.preventDefault();
                    alert('Ukuran file maksimal 5MB!');
                    return false;
                }
                
                const allowedExtensions = ['jpg', 'jpeg', 'png', 'pdf', 'gif', 'svg'];
                const fileName = fileInput.files[0].name;
                const extension = fileName.split('.').pop().toLowerCase();
                
                if (!allowedExtensions.includes(extension)) {
                    e.preventDefault();
                    alert('Format file harus JPG, PNG, PDF, GIF, atau SVG!');
                    return false;
                }
            }
        });
    });
</script>

</body>
</html>