<?php
session_start();
include '../../koneksi.php';

// Cek session admin
if (!isset($_SESSION['admin'])) {
    header("Location: ../../login.php");
    exit;
}

$id = $_GET['id'] ?? null;
if (!$id) {
    header("Location: index.php");
    exit;
}

$data = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT * FROM persyaratan WHERE id=$id")
);

if (!$data) {
    header("Location: index.php");
    exit;
}

$success = "";
$error = "";

if (isset($_POST['update'])) {
    $judul = mysqli_real_escape_string($conn, trim($_POST['judul']));
    $deskripsi = mysqli_real_escape_string($conn, trim($_POST['deskripsi']));
    
    if (empty($judul) || empty($deskripsi)) {
        $error = "Judul dan deskripsi tidak boleh kosong!";
    } else {
        $update_query = "UPDATE persyaratan SET 
                        judul='$judul', 
                        deskripsi='$deskripsi' 
                        WHERE id=$id";
        
        if (mysqli_query($conn, $update_query)) {
            $success = "Persyaratan berhasil diperbarui!";
            // Refresh data
            $data = mysqli_fetch_assoc(
                mysqli_query($conn, "SELECT * FROM persyaratan WHERE id=$id")
            );
        } else {
            $error = "Gagal memperbarui persyaratan!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Persyaratan - Admin Desa</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            padding: 20px;
            color: #333;
        }

        .container {
            max-width: 800px;
            margin: 40px auto;
            background: white;
            border-radius: 16px;
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.12);
            overflow: hidden;
        }

        .header {
            background: linear-gradient(to right, #2e8b57, #3cb371);
            color: white;
            padding: 30px;
            position: relative;
        }

        .header h1 {
            font-size: 28px;
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 8px;
        }

        .header h1 i {
            background: rgba(255, 255, 255, 0.2);
            padding: 12px;
            border-radius: 10px;
            font-size: 22px;
        }

        .header p {
            opacity: 0.9;
            font-size: 15px;
            margin-left: 57px;
        }

        .back-link {
            position: absolute;
            right: 30px;
            top: 35px;
            color: white;
            text-decoration: none;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 8px;
            background: rgba(255, 255, 255, 0.15);
            padding: 10px 18px;
            border-radius: 30px;
            transition: all 0.3s;
        }

        .back-link:hover {
            background: rgba(255, 255, 255, 0.25);
            transform: translateX(-5px);
        }

        .content {
            padding: 40px;
        }

        .alert {
            padding: 16px 20px;
            margin-bottom: 25px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: fadeIn 0.3s ease;
        }

        .alert-success {
            background: #d4edda;
            border-left: 4px solid #28a745;
            color: #155724;
        }

        .alert-error {
            background: #ffeaea;
            border-left: 4px solid #ff5252;
            color: #d32f2f;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            margin-bottom: 10px;
            font-weight: 600;
            color: #444;
            font-size: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .form-group label i {
            color: #2e8b57;
            width: 20px;
        }

        .form-group input[type="text"],
        .form-group textarea {
            width: 100%;
            padding: 16px 18px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 15px;
            transition: all 0.3s;
            background: #fafafa;
        }

        .form-group input[type="text"]:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #2e8b57;
            background: white;
            box-shadow: 0 0 0 4px rgba(46, 139, 87, 0.1);
        }

        .form-group textarea {
            resize: vertical;
            min-height: 200px;
            line-height: 1.6;
        }

        .char-count {
            text-align: right;
            font-size: 13px;
            color: #777;
            margin-top: 8px;
        }

        .info-box {
            background: #f0f9ff;
            border-left: 4px solid #17a2b8;
            padding: 15px 20px;
            margin-bottom: 25px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .info-box i {
            color: #17a2b8;
            font-size: 18px;
        }

        .button-group {
            display: flex;
            gap: 15px;
            margin-top: 35px;
            padding-top: 25px;
            border-top: 1px solid #eee;
        }

        .btn {
            padding: 16px 30px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            border: none;
            text-decoration: none;
            flex: 1;
        }

        .btn-primary {
            background: linear-gradient(to right, #2e8b57, #3cb371);
            color: white;
            box-shadow: 0 4px 15px rgba(46, 139, 87, 0.3);
        }

        .btn-primary:hover {
            background: linear-gradient(to right, #26734d, #2e8b57);
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(46, 139, 87, 0.4);
        }

        .btn-secondary {
            background: #f5f5f5;
            color: #666;
            border: 1px solid #ddd;
        }

        .btn-secondary:hover {
            background: #e9e9e9;
            transform: translateY(-3px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .current-data {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 25px;
            border-left: 4px solid #2e8b57;
        }

        .current-data h3 {
            color: #2e8b57;
            margin-bottom: 10px;
            font-size: 16px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 768px) {
            .container {
                margin: 20px auto;
                border-radius: 12px;
            }
            
            .content {
                padding: 25px;
            }
            
            .header {
                padding: 25px 20px;
            }
            
            .header h1 {
                font-size: 24px;
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
            
            .header p {
                margin-left: 0;
                margin-top: 5px;
            }
            
            .back-link {
                position: relative;
                right: auto;
                top: auto;
                display: inline-flex;
                margin-top: 15px;
                width: 100%;
                justify-content: center;
            }
            
            .button-group {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <h1>
            <i class="fas fa-edit"></i>
            Edit Persyaratan Administrasi
        </h1>
        <p>Perbarui informasi persyaratan layanan desa</p>
        <a href="index.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Kembali ke Daftar
        </a>
    </div>
    
    <div class="content">
        <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <span><?= htmlspecialchars($success) ?></span>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i>
                <span><?= htmlspecialchars($error) ?></span>
            </div>
        <?php endif; ?>

        <div class="current-data">
            <h3>
                <i class="fas fa-info-circle"></i>
                Data Saat Ini
            </h3>
            <p><strong>Judul:</strong> <?= htmlspecialchars($data['judul']) ?></p>
            <p><strong>ID:</strong> #<?= htmlspecialchars($id) ?></p>
        </div>

        <form method="post" id="editForm">
            <div class="form-group">
                <label for="judul">
                    <i class="fas fa-heading"></i>
                    Judul Persyaratan
                </label>
                <input type="text" id="judul" name="judul" 
                       value="<?= htmlspecialchars($data['judul']) ?>"
                       placeholder="Contoh: Syarat Pengurusan KTP"
                       maxlength="100"
                       required>
                <div class="char-count" id="judulCount"><?= strlen($data['judul']) ?>/100 karakter</div>
            </div>
            
            <div class="form-group">
                <label for="deskripsi">
                    <i class="fas fa-align-left"></i>
                    Deskripsi / Isi Persyaratan
                </label>
                <textarea id="deskripsi" name="deskripsi" 
                          placeholder="Tulis deskripsi lengkap persyaratan..."
                          rows="8"
                          required><?= htmlspecialchars($data['deskripsi']) ?></textarea>
                <div class="char-count" id="deskripsiCount"><?= strlen($data['deskripsi']) ?> karakter</div>
            </div>

            <div class="info-box">
                <i class="fas fa-lightbulb"></i>
                <span>Pastikan informasi yang diisi akurat dan mudah dipahami oleh warga.</span>
            </div>
            
            <div class="button-group">
                <button type="submit" name="update" class="btn btn-primary">
                    <i class="fas fa-save"></i>
                    Simpan Perubahan
                </button>
                <a href="index.php" class="btn btn-secondary">
                    <i class="fas fa-times"></i>
                    Batal
                </a>
            </div>
        </form>
    </div>
</div>

<script>
    // Fungsi untuk menghitung karakter
    function updateCharCount(element, counterId, maxLength = null) {
        const count = element.value.length;
        const counter = document.getElementById(counterId);
        
        if (maxLength) {
            counter.textContent = `${count}/${maxLength} karakter`;
            if (count > maxLength * 0.9) {
                counter.style.color = '#ff5252';
                counter.innerHTML += ' <i class="fas fa-exclamation-triangle"></i>';
            } else if (count > maxLength * 0.7) {
                counter.style.color = '#ff9800';
            } else {
                counter.style.color = '#777';
            }
        } else {
            counter.textContent = `${count} karakter`;
        }
    }
    
    // Inisialisasi event listeners
    document.addEventListener('DOMContentLoaded', function() {
        const judulInput = document.getElementById('judul');
        const deskripsiTextarea = document.getElementById('deskripsi');
        
        judulInput.addEventListener('input', function() {
            updateCharCount(this, 'judulCount', 100);
        });
        
        deskripsiTextarea.addEventListener('input', function() {
            updateCharCount(this, 'deskripsiCount');
        });
        
        // Validasi form
        document.getElementById('editForm').addEventListener('submit', function(e) {
            const judul = judulInput.value.trim();
            const deskripsi = deskripsiTextarea.value.trim();
            
            if (judul === '' || deskripsi === '') {
                e.preventDefault();
                alert('Judul dan deskripsi tidak boleh kosong!');
                return false;
            }
            
            if (judul.length > 100) {
                e.preventDefault();
                alert('Judul tidak boleh lebih dari 100 karakter!');
                return false;
            }
            
            if (deskripsi.length < 10) {
                e.preventDefault();
                alert('Deskripsi terlalu pendek! Minimal 10 karakter.');
                return false;
            }
        });
    });
</script>

</body>
</html>