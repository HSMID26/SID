<?php
session_start();
include '../../koneksi.php';

/* ===============================
   CEK LOGIN ADMIN (BENAR)
================================ */
if (!isset($_SESSION['admin'])) {
    header("Location: ../../login.php");
    exit;
}

$admin = $_SESSION['admin'];

// Ambil data persyaratan dengan error handling
$query = mysqli_query($conn, "SELECT * FROM persyaratan ORDER BY id DESC");
if (!$query) {
    echo "Error: " . mysqli_error($conn);
    exit;
}

$total_persyaratan = mysqli_num_rows($query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Persyaratan - Admin Desa</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            color: #333;
        }

        .admin-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 30px;
        }

        .header-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 20px;
        }

        .page-title {
            font-size: 28px;
            font-weight: 700;
            color: #2e8b57;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .page-title i {
            background: linear-gradient(135deg, #2e8b57, #3cb371);
            padding: 12px;
            border-radius: 10px;
            color: white;
            font-size: 22px;
        }

        .action-buttons {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 12px 24px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 15px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }

        .btn-primary {
            background: linear-gradient(to right, #2e8b57, #3cb371);
            color: white;
            box-shadow: 0 4px 12px rgba(46, 139, 87, 0.2);
        }

        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 18px rgba(46, 139, 87, 0.3);
            background: linear-gradient(to right, #26734d, #2e8b57);
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background: #5a6268;
            transform: translateY(-3px);
        }

        .btn-edit {
            background: #17a2b8;
            color: white;
            padding: 8px 16px;
            font-size: 14px;
            border-radius: 6px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: all 0.2s;
        }

        .btn-edit:hover {
            background: #138496;
            transform: translateY(-2px);
            box-shadow: 0 3px 8px rgba(23, 162, 184, 0.3);
        }

        .btn-delete {
            background: #dc3545;
            color: white;
            padding: 8px 16px;
            font-size: 14px;
            border-radius: 6px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: all 0.2s;
        }

        .btn-delete:hover {
            background: #c82333;
            transform: translateY(-2px);
            box-shadow: 0 3px 8px rgba(220, 53, 69, 0.3);
        }

        .stats-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .stats-icon {
            background: linear-gradient(135deg, #2e8b57, #3cb371);
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 22px;
        }

        .stats-info h3 {
            font-size: 28px;
            color: #2e8b57;
            margin-bottom: 5px;
        }

        .stats-info p {
            color: #6c757d;
            font-size: 14px;
        }

        .table-container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
            overflow: hidden;
            margin-bottom: 30px;
        }

        .table-responsive {
            overflow-x: auto;
        }

        .requirements-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 800px;
        }

        .requirements-table thead {
            background: linear-gradient(to right, #2e8b57, #3cb371);
        }

        .requirements-table th {
            padding: 18px 20px;
            color: white;
            font-weight: 600;
            text-align: left;
            font-size: 15px;
        }

        .requirements-table th:first-child {
            width: 80px;
            text-align: center;
        }

        .requirements-table th:nth-child(2) {
            min-width: 300px;
        }

        .requirements-table th:last-child {
            width: 200px;
            text-align: center;
        }

        .requirements-table tbody tr {
            border-bottom: 1px solid #f0f0f0;
            transition: all 0.2s;
        }

        .requirements-table tbody tr:hover {
            background: #f8f9fa;
        }

        .requirements-table td {
            padding: 16px 20px;
            vertical-align: middle;
        }

        .requirements-table td:first-child {
            text-align: center;
            font-weight: 600;
            color: #2e8b57;
        }

        .requirement-title {
            font-weight: 600;
            color: #333;
            font-size: 15px;
            line-height: 1.4;
        }

        .requirement-title:hover {
            color: #2e8b57;
        }

        .requirement-preview {
            font-size: 13px;
            color: #6c757d;
            margin-top: 5px;
            line-height: 1.4;
            max-width: 600px;
        }

        .action-buttons-cell {
            display: flex;
            gap: 8px;
            justify-content: center;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #6c757d;
        }

        .empty-state i {
            font-size: 48px;
            color: #ddd;
            margin-bottom: 15px;
        }

        .empty-state p {
            font-size: 16px;
            margin-bottom: 20px;
        }

        .back-dashboard {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: #2e8b57;
            text-decoration: none;
            font-weight: 600;
            padding: 12px 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);
            transition: all 0.3s;
        }

        .back-dashboard:hover {
            background: #f8f9fa;
            transform: translateX(-5px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .badge {
            display: inline-block;
            padding: 3px 8px;
            font-size: 11px;
            font-weight: 600;
            border-radius: 4px;
            margin-left: 8px;
            vertical-align: middle;
        }

        .badge-count {
            background: #e3f2fd;
            color: #1976d2;
        }

        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #dc3545;
        }

        @media (max-width: 768px) {
            .admin-container {
                padding: 20px;
            }
            
            .header-section {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .action-buttons {
                width: 100%;
            }
            
            .btn {
                flex: 1;
                justify-content: center;
            }
            
            .requirements-table td, .requirements-table th {
                padding: 12px 15px;
            }
            
            .action-buttons-cell {
                flex-direction: column;
                gap: 6px;
            }
            
            .btn-edit, .btn-delete {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>

<div class="admin-container">
    <!-- Header Section -->
    <div class="header-section">
        <div>
            <h1 class="page-title">
                <i class="fas fa-file-alt"></i>
                Kelola Persyaratan Administrasi
            </h1>
            <p style="color: #6c757d; margin-top: 5px;">Kelola persyaratan layanan administrasi desa</p>
        </div>
        
        <div class="action-buttons">
            <a href="tambah.php" class="btn btn-primary">
                <i class="fas fa-plus-circle"></i>
                Tambah Persyaratan
            </a>
            <a href="../dashboard.php" class="btn btn-secondary">
                <i class="fas fa-tachometer-alt"></i>
                Dashboard
            </a>
        </div>
    </div>

    <!-- Stats Card -->
    <div class="stats-card">
        <div class="stats-icon">
            <i class="fas fa-clipboard-list"></i>
        </div>
        <div class="stats-info">
            <h3><?= $total_persyaratan ?></h3>
            <p>Total Persyaratan Tersedia</p>
        </div>
    </div>

    <!-- Requirements Table -->
    <div class="table-container">
        <div class="table-responsive">
            <table class="requirements-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Judul Persyaratan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($total_persyaratan > 0): 
                        $no = 1;
                        mysqli_data_seek($query, 0); // Reset pointer
                        while ($row = mysqli_fetch_assoc($query)): 
                            // Periksa apakah kolom ada sebelum mengaksesnya
                            $judul = isset($row['judul']) ? htmlspecialchars($row['judul']) : 'Tidak ada judul';
                            $deskripsi = isset($row['deskripsi']) ? $row['deskripsi'] : '';
                            $truncated_desc = strlen($deskripsi) > 120 ? 
                                substr($deskripsi, 0, 117) . '...' : 
                                $deskripsi;
                    ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td>
                            <div class="requirement-title">
                                <?= $judul ?>
                                <span class="badge badge-count">#<?= $row['id'] ?></span>
                            </div>
                            <?php if (!empty($deskripsi)): ?>
                            <div class="requirement-preview">
                                <?= htmlspecialchars($truncated_desc) ?>
                            </div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="action-buttons-cell">
                                <a href="edit.php?id=<?= $row['id']; ?>" class="btn-edit">
                                    <i class="fas fa-edit"></i> Edit
                                </a>
                                <a href="hapus.php?id=<?= $row['id']; ?>" 
                                   class="btn-delete"
                                   onclick="return confirm('Apakah Anda yakin ingin menghapus persyaratan ini?\n\nJudul: <?= addslashes($judul) ?>')">
                                    <i class="fas fa-trash-alt"></i> Hapus
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                    
                    <?php else: ?>
                    <tr>
                        <td colspan="3">
                            <div class="empty-state">
                                <i class="far fa-clipboard"></i>
                                <p>Belum ada persyaratan yang ditambahkan</p>
                                <a href="tambah.php" class="btn btn-primary">
                                    <i class="fas fa-plus-circle"></i>
                                    Tambah Persyaratan Pertama
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Debug info untuk developer -->
    <?php if (isset($_GET['debug'])): ?>
    <div class="error-message">
        <h4>Debug Info:</h4>
        <p>Total rows: <?= $total_persyaratan ?></p>
        <?php 
        mysqli_data_seek($query, 0);
        if ($row = mysqli_fetch_assoc($query)): 
            echo '<pre>';
            print_r($row);
            echo '</pre>';
        endif; 
        ?>
    </div>
    <?php endif; ?>

    <!-- Back to Dashboard -->
    <a href="../dashboard.php" class="back-dashboard">
        <i class="fas fa-arrow-left"></i>
        Kembali ke Dashboard Admin
    </a>
</div>

<script>
    // Tambahkan efek hover untuk baris tabel
    document.querySelectorAll('.requirements-table tbody tr').forEach(row => {
        row.addEventListener('mouseenter', function() {
            this.style.transform = 'translateX(5px)';
            this.style.boxShadow = '0 3px 10px rgba(0,0,0,0.08)';
        });
        
        row.addEventListener('mouseleave', function() {
            this.style.transform = 'translateX(0)';
            this.style.boxShadow = 'none';
        });
    });

    // Konfirmasi penghapusan yang lebih baik
    document.querySelectorAll('.btn-delete').forEach(button => {
        button.addEventListener('click', function(e) {
            if (!confirm('Yakin ingin menghapus persyaratan ini?')) {
                e.preventDefault();
            }
        });
    });

    // Efek hover untuk semua tombol
    document.querySelectorAll('.btn').forEach(btn => {
        btn.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-3px)';
        });
        
        btn.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
</script>

</body>
</html>