<?php
session_start();
include '../../koneksi.php';

// Cek session admin
if (!isset($_SESSION['admin'])) {
    header("Location: ../../login.php");
    exit;
}

$error = "";
$success = "";

if (isset($_POST['simpan'])) {
    $nama_layanan = mysqli_real_escape_string($conn, trim($_POST['nama_layanan']));
    $persyaratan = mysqli_real_escape_string($conn, trim($_POST['persyaratan']));
    
    if (empty($nama_layanan) || empty($persyaratan)) {
        $error = "Nama layanan dan persyaratan tidak boleh kosong!";
    } else {
        $insert_query = "INSERT INTO persyaratan (nama_layanan, persyaratan) 
                        VALUES ('$nama_layanan', '$persyaratan')";
        
        if (mysqli_query($conn, $insert_query)) {
            $success = "Layanan dan persyaratan berhasil ditambahkan!";
            // Reset form
            $_POST['nama_layanan'] = '';
            $_POST['persyaratan'] = '';
        } else {
            $error = "Gagal menambahkan data! Error: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Layanan & Persyaratan - Admin Desa</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            padding: 20px;
            color: #333;
        }

        .container {
            max-width: 800px;
            margin: 40px auto;
            background: white;
            border-radius: 16px;
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.12);
            overflow: hidden;
        }

        .header {
            background: linear-gradient(to right, #2e8b57, #3cb371);
            color: white;
            padding: 30px;
            position: relative;
        }

        .header h1 {
            font-size: 28px;
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 8px;
        }

        .header h1 i {
            background: rgba(255, 255, 255, 0.2);
            padding: 12px;
            border-radius: 10px;
            font-size: 22px;
        }

        .header p {
            opacity: 0.9;
            font-size: 15px;
            margin-left: 57px;
        }

        .back-link {
            position: absolute;
            right: 30px;
            top: 35px;
            color: white;
            text-decoration: none;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 8px;
            background: rgba(255, 255, 255, 0.15);
            padding: 10px 18px;
            border-radius: 30px;
            transition: all 0.3s;
        }

        .back-link:hover {
            background: rgba(255, 255, 255, 0.25);
            transform: translateX(-5px);
        }

        .content {
            padding: 40px;
        }

        .alert {
            padding: 16px 20px;
            margin-bottom: 25px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: fadeIn 0.3s ease;
        }

        .alert-success {
            background: #d4edda;
            border-left: 4px solid #28a745;
            color: #155724;
        }

        .alert-error {
            background: #ffeaea;
            border-left: 4px solid #ff5252;
            color: #d32f2f;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            margin-bottom: 10px;
            font-weight: 600;
            color: #444;
            font-size: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .form-group label i {
            color: #2e8b57;
            width: 20px;
        }

        .form-group input[type="text"],
        .form-group textarea {
            width: 100%;
            padding: 16px 18px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 15px;
            transition: all 0.3s;
            background: #fafafa;
        }

        .form-group input[type="text"]:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #2e8b57;
            background: white;
            box-shadow: 0 0 0 4px rgba(46, 139, 87, 0.1);
        }

        .form-group textarea {
            resize: vertical;
            min-height: 200px;
            line-height: 1.6;
        }

        .char-count {
            text-align: right;
            font-size: 13px;
            color: #777;
            margin-top: 8px;
        }

        .info-box {
            background: #f0f9ff;
            border-left: 4px solid #17a2b8;
            padding: 15px 20px;
            margin-bottom: 25px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .info-box i {
            color: #17a2b8;
            font-size: 18px;
        }

        .example-box {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 25px;
            border: 1px dashed #ddd;
        }

        .example-box h4 {
            color: #2e8b57;
            margin-bottom: 10px;
            font-size: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .example-content {
            font-size: 14px;
            color: #666;
            line-height: 1.5;
        }

        .example-content ul {
            padding-left: 20px;
            margin-top: 8px;
        }

        .button-group {
            display: flex;
            gap: 15px;
            margin-top: 35px;
            padding-top: 25px;
            border-top: 1px solid #eee;
        }

        .btn {
            padding: 16px 30px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            border: none;
            text-decoration: none;
            flex: 1;
        }

        .btn-primary {
            background: linear-gradient(to right, #2e8b57, #3cb371);
            color: white;
            box-shadow: 0 4px 15px rgba(46, 139, 87, 0.3);
        }

        .btn-primary:hover {
            background: linear-gradient(to right, #26734d, #2e8b57);
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(46, 139, 87, 0.4);
        }

        .btn-secondary {
            background: #f5f5f5;
            color: #666;
            border: 1px solid #ddd;
        }

        .btn-secondary:hover {
            background: #e9e9e9;
            transform: translateY(-3px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .services-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 25px;
        }

        .service-example {
            background: white;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            padding: 15px;
            cursor: pointer;
            transition: all 0.3s;
        }

        .service-example:hover {
            border-color: #2e8b57;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(46, 139, 87, 0.1);
        }

        .service-example i {
            color: #2e8b57;
            font-size: 20px;
            margin-bottom: 10px;
            display: block;
        }

        .service-example h5 {
            font-size: 14px;
            color: #333;
            margin-bottom: 5px;
        }

        .service-example p {
            font-size: 12px;
            color: #666;
            line-height: 1.4;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 768px) {
            .container {
                margin: 20px auto;
                border-radius: 12px;
            }
            
            .content {
                padding: 25px;
            }
            
            .header {
                padding: 25px 20px;
            }
            
            .header h1 {
                font-size: 24px;
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
            
            .header p {
                margin-left: 0;
                margin-top: 5px;
            }
            
            .back-link {
                position: relative;
                right: auto;
                top: auto;
                display: inline-flex;
                margin-top: 15px;
                width: 100%;
                justify-content: center;
            }
            
            .button-group {
                flex-direction: column;
            }
            
            .services-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        
        @media (max-width: 480px) {
            .services-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <h1>
            <i class="fas fa-plus-circle"></i>
            Tambah Layanan & Persyaratan
        </h1>
        <p>Tambahkan layanan administrasi desa beserta persyaratannya</p>
        <a href="index.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Kembali ke Daftar
        </a>
    </div>
    
    <div class="content">
        <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <span><?= htmlspecialchars($success) ?></span>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i>
                <span><?= htmlspecialchars($error) ?></span>
            </div>
        <?php endif; ?>

        <div class="example-box">
            <h4>
                <i class="fas fa-lightbulb"></i>
                Contoh Layanan & Persyaratan
            </h4>
            <div class="example-content">
                <div class="services-grid">
                    <div class="service-example" onclick="fillExample(1)">
                        <i class="fas fa-id-card"></i>
                        <h5>Pembuatan KTP</h5>
                        <p>Pengurusan KTP baru atau perpanjangan</p>
                    </div>
                    <div class="service-example" onclick="fillExample(2)">
                        <i class="fas fa-home"></i>
                        <h5>Kartu Keluarga</h5>
                        <p>Pembuatan atau perubahan data KK</p>
                    </div>
                    <div class="service-example" onclick="fillExample(3)">
                        <i class="fas fa-baby"></i>
                        <h5>Akta Kelahiran</h5>
                        <p>Pencatatan kelahiran dan pembuatan akta</p>
                    </div>
                    <div class="service-example" onclick="fillExample(4)">
                        <i class="fas fa-file-alt"></i>
                        <h5>Surat Keterangan</h5>
                        <p>Berbagai jenis surat keterangan</p>
                    </div>
                </div>
            </div>
        </div>

        <form method="post" id="addForm">
            <div class="form-group">
                <label for="nama_layanan">
                    <i class="fas fa-heading"></i>
                    Nama Layanan
                </label>
                <input type="text" id="nama_layanan" name="nama_layanan" 
                       value="<?= htmlspecialchars($_POST['nama_layanan'] ?? '') ?>"
                       placeholder="Contoh: Pembuatan KTP Baru, Pengurusan Kartu Keluarga, dll"
                       maxlength="150"
                       required>
                <div class="char-count" id="namaLayananCount">0/150 karakter</div>
            </div>
            
            <div class="form-group">
                <label for="persyaratan">
                    <i class="fas fa-align-left"></i>
                    Persyaratan
                </label>
                <textarea id="persyaratan" name="persyaratan" 
                          placeholder="Tulis persyaratan secara lengkap. Contoh:
• Fotokopi Kartu Keluarga
• Surat pengantar RT/RW
• Pas foto 3x4 (2 lembar)
• dll."
                          rows="10"
                          required><?= htmlspecialchars($_POST['persyaratan'] ?? '') ?></textarea>
                <div class="char-count" id="persyaratanCount">0 karakter</div>
            </div>

            <div class="info-box">
                <i class="fas fa-info-circle"></i>
                <span><strong>Format yang Disarankan:</strong> Gunakan bullet points (•) untuk setiap persyaratan. Tekan Enter untuk membuat poin baru otomatis.</span>
            </div>
            
            <div class="button-group">
                <button type="submit" name="simpan" class="btn btn-primary">
                    <i class="fas fa-save"></i>
                    Simpan Layanan
                </button>
                <a href="index.php" class="btn btn-secondary">
                    <i class="fas fa-times"></i>
                    Batal
                </a>
            </div>
        </form>
    </div>
</div>

<script>
    // Data contoh untuk layanan
    const examples = {
        1: {
            nama_layanan: "Pembuatan KTP Baru",
            persyaratan: "• Fotokopi Kartu Keluarga (KK)\n• Surat pengantar dari RT/RW setempat\n• Pas foto 3x4 sebanyak 3 lembar (berlatar merah)\n• Fotokopi akta kelahiran\n• Fotokopi surat nikah untuk yang sudah menikah\n• Mengisi formulir pendaftaran"
        },
        2: {
            nama_layanan: "Pengurusan Kartu Keluarga (KK)",
            persyaratan: "• Surat pengantar dari RT/RW\n• Fotokopi KTP kepala keluarga\n• Fotokopi KTP anggota keluarga (jika ada perubahan)\n• Fotokopi akta kelahiran untuk anggota baru\n• Fotokopi akta kematian (jika ada yang meninggal)\n• Surat nikah/cerai (jika ada perubahan status)\n• Formulir perubahan data keluarga"
        },
        3: {
            nama_layanan: "Pencatatan Kelahiran dan Akta",
            persyaratan: "• Surat keterangan lahir dari dokter/bidan/rumah sakit\n• Fotokopi KTP kedua orang tua\n• Fotokopi Kartu Keluarga\n• Surat nikah orang tua\n• Surat pengantar RT/RW\n• Mengisi formulir pencatatan kelahiran"
        },
        4: {
            nama_layanan: "Surat Keterangan Tidak Mampu (SKTM)",
            persyaratan: "• Fotokopi KTP pemohon\n• Fotokopi Kartu Keluarga\n• Surat pengantar RT/RW\n• Surat keterangan penghasilan dari tempat kerja (jika bekerja)\n• Data kondisi ekonomi keluarga\n• Mengisi formulir permohonan SKTM"
        }
    };

    // Fungsi untuk mengisi contoh
    function fillExample(exampleId) {
        const example = examples[exampleId];
        if (example) {
            document.getElementById('nama_layanan').value = example.nama_layanan;
            document.getElementById('persyaratan').value = example.persyaratan;
            
            // Update character count
            updateCharCount(document.getElementById('nama_layanan'), 'namaLayananCount', 150);
            updateCharCount(document.getElementById('persyaratan'), 'persyaratanCount');
            
            // Scroll ke form
            document.getElementById('nama_layanan').focus();
        }
    }

    // Fungsi untuk menghitung karakter
    function updateCharCount(element, counterId, maxLength = null) {
        const count = element.value.length;
        const counter = document.getElementById(counterId);
        
        if (maxLength) {
            counter.textContent = `${count}/${maxLength} karakter`;
            if (count > maxLength * 0.9) {
                counter.style.color = '#ff5252';
                counter.innerHTML += ' <i class="fas fa-exclamation-triangle"></i>';
            } else if (count > maxLength * 0.7) {
                counter.style.color = '#ff9800';
            } else {
                counter.style.color = '#777';
            }
        } else {
            counter.textContent = `${count} karakter`;
        }
    }
    
    // Inisialisasi event listeners
    document.addEventListener('DOMContentLoaded', function() {
        const namaLayananInput = document.getElementById('nama_layanan');
        const persyaratanTextarea = document.getElementById('persyaratan');
        
        namaLayananInput.addEventListener('input', function() {
            updateCharCount(this, 'namaLayananCount', 150);
        });
        
        persyaratanTextarea.addEventListener('input', function() {
            updateCharCount(this, 'persyaratanCount');
        });
        
        // Set nilai awal
        updateCharCount(namaLayananInput, 'namaLayananCount', 150);
        updateCharCount(persyaratanTextarea, 'persyaratanCount');
        
        // Validasi form
        document.getElementById('addForm').addEventListener('submit', function(e) {
            const namaLayanan = namaLayananInput.value.trim();
            const persyaratan = persyaratanTextarea.value.trim();
            
            if (namaLayanan === '' || persyaratan === '') {
                e.preventDefault();
                alert('Nama layanan dan persyaratan tidak boleh kosong!');
                return false;
            }
            
            if (namaLayanan.length > 150) {
                e.preventDefault();
                alert('Nama layanan tidak boleh lebih dari 150 karakter!');
                return false;
            }
            
            if (persyaratan.length < 10) {
                e.preventDefault();
                alert('Persyaratan terlalu pendek! Minimal 10 karakter.');
                return false;
            }
        });
        
        // Auto-format bullet points pada textarea
        persyaratanTextarea.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                const start = this.selectionStart;
                const end = this.selectionEnd;
                const value = this.value;
                
                // Cari awal baris saat ini
                const lineStart = value.lastIndexOf('\n', start - 1) + 1;
                const currentLine = value.substring(lineStart, start);
                
                // Cek apakah baris saat ini dimulai dengan bullet point
                if (currentLine.trim().startsWith('•') || 
                    currentLine.trim().endsWith(':') ||
                    /^\d+\./.test(currentLine.trim())) {
                    
                    // Tambah bullet point otomatis
                    setTimeout(() => {
                        const newStart = this.selectionStart;
                        this.value = this.value.substring(0, newStart) + '• ' + this.value.substring(newStart);
                        this.selectionStart = newStart + 2;
                        this.selectionEnd = newStart + 2;
                    }, 0);
                }
            }
        });
        
        // Shortcut untuk membuat bullet point
        persyaratanTextarea.addEventListener('keydown', function(e) {
            // Ctrl + B untuk bullet point
            if (e.ctrlKey && e.key === 'b') {
                e.preventDefault();
                const start = this.selectionStart;
                const end = this.selectionEnd;
                
                this.value = this.value.substring(0, start) + '• ' + this.value.substring(start);
                this.selectionStart = start + 2;
                this.selectionEnd = start + 2;
            }
        });
    });
</script>

</body>
</html>