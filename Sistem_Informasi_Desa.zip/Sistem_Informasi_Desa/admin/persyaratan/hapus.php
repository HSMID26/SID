<?php
session_start();
include '../../koneksi.php';

$id = $_GET['id'];
mysqli_query($conn, "DELETE FROM persyaratan WHERE id=$id");

header("Location: index.php");
