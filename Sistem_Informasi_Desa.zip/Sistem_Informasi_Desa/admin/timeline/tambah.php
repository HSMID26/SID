<?php
session_start();
include '../../koneksi.php';

// Cek session admin
if (!isset($_SESSION['admin'])) {
    header("Location: ../../login.php");
    exit;
}

$error = "";
$success = "";

if (isset($_POST['simpan'])) {
    $judul = mysqli_real_escape_string($conn, trim($_POST['judul']));
    $deskripsi = mysqli_real_escape_string($conn, trim($_POST['deskripsi']));
    $tanggal = mysqli_real_escape_string($conn, trim($_POST['tanggal']));
    
    if (empty($judul) || empty($deskripsi) || empty($tanggal)) {
        $error = "Semua field tidak boleh kosong!";
    } else {
        // Validasi format tanggal
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal)) {
            $error = "Format tanggal tidak valid! Gunakan format YYYY-MM-DD.";
        } else {
            $insert_query = "INSERT INTO timeline (judul, deskripsi, tanggal_kegiatan)
                            VALUES ('$judul', '$deskripsi', '$tanggal')";
            
            if (mysqli_query($conn, $insert_query)) {
                $success = "Timeline berhasil ditambahkan!";
                // Reset form values
                $_POST['judul'] = '';
                $_POST['deskripsi'] = '';
                $_POST['tanggal'] = '';
            } else {
                $error = "Gagal menambahkan timeline!";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Timeline - Admin Desa</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            padding: 20px;
            color: #333;
        }

        .container {
            max-width: 800px;
            margin: 40px auto;
            background: white;
            border-radius: 16px;
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.12);
            overflow: hidden;
        }

        .header {
            background: linear-gradient(to right, #2e8b57, #3cb371);
            color: white;
            padding: 30px;
            position: relative;
        }

        .header h1 {
            font-size: 28px;
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 8px;
        }

        .header h1 i {
            background: rgba(255, 255, 255, 0.2);
            padding: 12px;
            border-radius: 10px;
            font-size: 22px;
        }

        .header p {
            opacity: 0.9;
            font-size: 15px;
            margin-left: 57px;
        }

        .back-link {
            position: absolute;
            right: 30px;
            top: 35px;
            color: white;
            text-decoration: none;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 8px;
            background: rgba(255, 255, 255, 0.15);
            padding: 10px 18px;
            border-radius: 30px;
            transition: all 0.3s;
        }

        .back-link:hover {
            background: rgba(255, 255, 255, 0.25);
            transform: translateX(-5px);
        }

        .content {
            padding: 40px;
        }

        .alert {
            padding: 16px 20px;
            margin-bottom: 25px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: fadeIn 0.3s ease;
        }

        .alert-success {
            background: #d4edda;
            border-left: 4px solid #28a745;
            color: #155724;
        }

        .alert-error {
            background: #ffeaea;
            border-left: 4px solid #ff5252;
            color: #d32f2f;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            margin-bottom: 10px;
            font-weight: 600;
            color: #444;
            font-size: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .form-group label i {
            color: #2e8b57;
            width: 20px;
        }

        .form-group input[type="text"],
        .form-group input[type="date"],
        .form-group textarea {
            width: 100%;
            padding: 16px 18px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 15px;
            transition: all 0.3s;
            background: #fafafa;
        }

        .form-group input[type="text"]:focus,
        .form-group input[type="date"]:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #2e8b57;
            background: white;
            box-shadow: 0 0 0 4px rgba(46, 139, 87, 0.1);
        }

        .form-group textarea {
            resize: vertical;
            min-height: 150px;
            line-height: 1.6;
        }

        .form-group input[type="date"] {
            max-width: 300px;
        }

        .char-count {
            text-align: right;
            font-size: 13px;
            color: #777;
            margin-top: 8px;
        }

        .date-picker-container {
            display: flex;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
        }

        .date-hint {
            font-size: 13px;
            color: #666;
            margin-top: 8px;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .date-hint i {
            color: #ff9800;
        }

        .example-box {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 25px;
            border: 1px dashed #ddd;
        }

        .example-box h4 {
            color: #2e8b57;
            margin-bottom: 10px;
            font-size: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .example-content {
            font-size: 14px;
            color: #666;
            line-height: 1.5;
        }

        .example-content ul {
            padding-left: 20px;
            margin-top: 8px;
        }

        .info-box {
            background: #f0f9ff;
            border-left: 4px solid #17a2b8;
            padding: 15px 20px;
            margin-bottom: 25px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .info-box i {
            color: #17a2b8;
            font-size: 18px;
        }

        .button-group {
            display: flex;
            gap: 15px;
            margin-top: 35px;
            padding-top: 25px;
            border-top: 1px solid #eee;
        }

        .btn {
            padding: 16px 30px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            border: none;
            text-decoration: none;
            flex: 1;
        }

        .btn-primary {
            background: linear-gradient(to right, #2e8b57, #3cb371);
            color: white;
            box-shadow: 0 4px 15px rgba(46, 139, 87, 0.3);
        }

        .btn-primary:hover {
            background: linear-gradient(to right, #26734d, #2e8b57);
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(46, 139, 87, 0.4);
        }

        .btn-secondary {
            background: #f5f5f5;
            color: #666;
            border: 1px solid #ddd;
        }

        .btn-secondary:hover {
            background: #e9e9e9;
            transform: translateY(-3px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 768px) {
            .container {
                margin: 20px auto;
                border-radius: 12px;
            }
            
            .content {
                padding: 25px;
            }
            
            .header {
                padding: 25px 20px;
            }
            
            .header h1 {
                font-size: 24px;
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
            
            .header p {
                margin-left: 0;
                margin-top: 5px;
            }
            
            .back-link {
                position: relative;
                right: auto;
                top: auto;
                display: inline-flex;
                margin-top: 15px;
                width: 100%;
                justify-content: center;
            }
            
            .button-group {
                flex-direction: column;
            }
            
            .form-group input[type="date"] {
                max-width: 100%;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <h1>
            <i class="fas fa-plus-circle"></i>
            Tambah Timeline Baru
        </h1>
        <p>Isi formulir di bawah untuk menambahkan kegiatan baru ke timeline desa</p>
        <a href="index.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Kembali ke Daftar
        </a>
    </div>
    
    <div class="content">
        <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <span><?= htmlspecialchars($success) ?></span>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i>
                <span><?= htmlspecialchars($error) ?></span>
            </div>
        <?php endif; ?>

        <div class="example-box">
            <h4>
                <i class="fas fa-lightbulb"></i>
                Contoh Kegiatan Timeline
            </h4>
            <div class="example-content">
                <p><strong>Judul:</strong> "Musyawarah Desa Tahunan 2024"</p>
                <p><strong>Deskripsi:</strong> "Musyawarah tahunan desa untuk membahas program kerja dan anggaran tahun 2024. Acara akan dilaksanakan di balai desa dengan dihadiri oleh seluruh perangkat desa dan perwakilan warga."</p>
                <p><strong>Tanggal:</strong> "2024-03-15" (15 Maret 2024)</p>
            </div>
        </div>

        <form method="post" id="timelineForm">
            <div class="form-group">
                <label for="judul">
                    <i class="fas fa-heading"></i>
                    Judul Kegiatan
                </label>
                <input type="text" id="judul" name="judul" 
                       value="<?= htmlspecialchars($_POST['judul'] ?? '') ?>"
                       placeholder="Contoh: Musyawarah Desa, Kerja Bakti, Pelatihan UMKM"
                       maxlength="150"
                       required>
                <div class="char-count" id="judulCount">0/150 karakter</div>
            </div>
            
            <div class="form-group">
                <label for="deskripsi">
                    <i class="fas fa-align-left"></i>
                    Deskripsi Kegiatan
                </label>
                <textarea id="deskripsi" name="deskripsi" 
                          placeholder="Jelaskan detail kegiatan, lokasi, waktu pelaksanaan, peserta, dan informasi penting lainnya..."
                          rows="6"
                          required><?= htmlspecialchars($_POST['deskripsi'] ?? '') ?></textarea>
                <div class="char-count" id="deskripsiCount">0 karakter</div>
            </div>
            
            <div class="form-group">
                <label for="tanggal">
                    <i class="fas fa-calendar-day"></i>
                    Tanggal Kegiatan
                </label>
                <div class="date-picker-container">
                    <input type="date" id="tanggal" name="tanggal" 
                           value="<?= htmlspecialchars($_POST['tanggal'] ?? '') ?>"
                           required>
                    <div style="flex: 1;">
                        <div class="date-hint">
                            <i class="fas fa-info-circle"></i>
                            Format: YYYY-MM-DD (Tahun-Bulan-Tanggal)
                        </div>
                        <div class="date-hint" id="datePreview" style="color: #2e8b57; font-weight: 500;">
                            Tanggal akan ditampilkan di sini
                        </div>
                    </div>
                </div>
            </div>

            <div class="info-box">
                <i class="fas fa-clock"></i>
                <span><strong>Tips:</strong> Pastikan tanggal kegiatan sudah benar. Timeline akan ditampilkan secara urut berdasarkan tanggal.</span>
            </div>
            
            <div class="button-group">
                <button type="submit" name="simpan" class="btn btn-primary">
                    <i class="fas fa-save"></i>
                    Simpan Timeline
                </button>
                <a href="index.php" class="btn btn-secondary">
                    <i class="fas fa-times"></i>
                    Batal
                </a>
            </div>
        </form>
    </div>
</div>

<script>
    // Fungsi untuk menghitung karakter
    function updateCharCount(element, counterId, maxLength = null) {
        const count = element.value.length;
        const counter = document.getElementById(counterId);
        
        if (maxLength) {
            counter.textContent = `${count}/${maxLength} karakter`;
            if (count > maxLength * 0.9) {
                counter.style.color = '#ff5252';
                counter.innerHTML += ' <i class="fas fa-exclamation-triangle"></i>';
            } else if (count > maxLength * 0.7) {
                counter.style.color = '#ff9800';
            } else {
                counter.style.color = '#777';
            }
        } else {
            counter.textContent = `${count} karakter`;
        }
    }
    
    // Fungsi untuk memformat tanggal
    function formatDate(dateString) {
        if (!dateString) return '';
        
        const date = new Date(dateString);
        if (isNaN(date.getTime())) return 'Format tidak valid';
        
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        return date.toLocaleDateString('id-ID', options);
    }
    
    // Update preview tanggal
    function updateDatePreview() {
        const dateInput = document.getElementById('tanggal');
        const preview = document.getElementById('datePreview');
        
        if (dateInput.value) {
            const formatted = formatDate(dateInput.value);
            preview.textContent = formatted;
            preview.style.color = '#2e8b57';
        } else {
            preview.textContent = 'Tanggal akan ditampilkan di sini';
            preview.style.color = '#666';
        }
    }
    
    // Validasi tanggal tidak boleh di masa lalu terlalu jauh atau masa depan terlalu jauh
    function validateDate(dateString) {
        const selectedDate = new Date(dateString);
        const today = new Date();
        const minDate = new Date('2020-01-01');
        const maxDate = new Date();
        maxDate.setFullYear(today.getFullYear() + 3); // Maksimal 3 tahun ke depan
        
        return selectedDate >= minDate && selectedDate <= maxDate;
    }
    
    // Inisialisasi event listeners
    document.addEventListener('DOMContentLoaded', function() {
        const judulInput = document.getElementById('judul');
        const deskripsiTextarea = document.getElementById('deskripsi');
        const tanggalInput = document.getElementById('tanggal');
        
        // Set tanggal minimal dan maksimal
        const today = new Date();
        const minDate = new Date('2020-01-01');
        const maxDate = new Date();
        maxDate.setFullYear(today.getFullYear() + 3);
        
        tanggalInput.min = minDate.toISOString().split('T')[0];
        tanggalInput.max = maxDate.toISOString().split('T')[0];
        
        // Set tanggal default ke hari ini
        if (!tanggalInput.value) {
            tanggalInput.value = today.toISOString().split('T')[0];
        }
        
        // Initial updates
        updateCharCount(judulInput, 'judulCount', 150);
        updateCharCount(deskripsiTextarea, 'deskripsiCount');
        updateDatePreview();
        
        judulInput.addEventListener('input', function() {
            updateCharCount(this, 'judulCount', 150);
        });
        
        deskripsiTextarea.addEventListener('input', function() {
            updateCharCount(this, 'deskripsiCount');
        });
        
        tanggalInput.addEventListener('change', updateDatePreview);
        tanggalInput.addEventListener('input', updateDatePreview);
        
        // Validasi form
        document.getElementById('timelineForm').addEventListener('submit', function(e) {
            const judul = judulInput.value.trim();
            const deskripsi = deskripsiTextarea.value.trim();
            const tanggal = tanggalInput.value;
            
            if (judul === '' || deskripsi === '' || tanggal === '') {
                e.preventDefault();
                alert('Semua field tidak boleh kosong!');
                return false;
            }
            
            if (judul.length > 150) {
                e.preventDefault();
                alert('Judul tidak boleh lebih dari 150 karakter!');
                return false;
            }
            
            if (deskripsi.length < 10) {
                e.preventDefault();
                alert('Deskripsi terlalu pendek! Minimal 10 karakter.');
                return false;
            }
            
            if (!validateDate(tanggal)) {
                e.preventDefault();
                alert('Tanggal tidak valid! Harus antara tahun 2020 dan 3 tahun ke depan dari sekarang.');
                return false;
            }
            
            // Konfirmasi jika tanggal di masa lalu
            const selectedDate = new Date(tanggal);
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            
            if (selectedDate < today) {
                if (!confirm('Anda memilih tanggal di masa lalu. Apakah ini benar?')) {
                    e.preventDefault();
                    return false;
                }
            }
            
            // Konfirmasi jika tanggal lebih dari 1 tahun ke depan
            const oneYearLater = new Date();
            oneYearLater.setFullYear(today.getFullYear() + 1);
            
            if (selectedDate > oneYearLater) {
                if (!confirm('Anda memilih tanggal lebih dari 1 tahun ke depan. Apakah ini benar?')) {
                    e.preventDefault();
                    return false;
                }
            }
        });
    });
</script>

</body>
</html>