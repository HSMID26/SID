<?php
session_start();
include '../../koneksi.php';

/* ===============================
   PROTEKSI LOGIN ADMIN
================================ */
if (!isset($_SESSION['admin'])) {
    header("Location: ../../login.php");
    exit;
}

// Ambil data timeline
$query = mysqli_query($conn, "SELECT * FROM timeline ORDER BY tanggal_kegiatan DESC");
$total_timeline = mysqli_num_rows($query);
mysqli_data_seek($query, 0); // Reset pointer untuk loop
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Timeline - Admin Desa</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            color: #333;
        }

        .admin-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 30px;
        }

        .header-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 20px;
        }

        .page-title {
            font-size: 28px;
            font-weight: 700;
            color: #2e8b57;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .page-title i {
            background: linear-gradient(135deg, #2e8b57, #3cb371);
            padding: 12px;
            border-radius: 10px;
            color: white;
            font-size: 22px;
        }

        .action-buttons {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 12px 24px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 15px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }

        .btn-primary {
            background: linear-gradient(to right, #2e8b57, #3cb371);
            color: white;
            box-shadow: 0 4px 12px rgba(46, 139, 87, 0.2);
        }

        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 18px rgba(46, 139, 87, 0.3);
            background: linear-gradient(to right, #26734d, #2e8b57);
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background: #5a6268;
            transform: translateY(-3px);
        }

        .btn-edit {
            background: #17a2b8;
            color: white;
            padding: 8px 16px;
            font-size: 14px;
            border-radius: 6px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: all 0.2s;
        }

        .btn-edit:hover {
            background: #138496;
            transform: translateY(-2px);
            box-shadow: 0 3px 8px rgba(23, 162, 184, 0.3);
        }

        .btn-delete {
            background: #dc3545;
            color: white;
            padding: 8px 16px;
            font-size: 14px;
            border-radius: 6px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: all 0.2s;
        }

        .btn-delete:hover {
            background: #c82333;
            transform: translateY(-2px);
            box-shadow: 0 3px 8px rgba(220, 53, 69, 0.3);
        }

        .stats-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .stats-icon {
            background: linear-gradient(135deg, #2e8b57, #3cb371);
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 22px;
        }

        .stats-info h3 {
            font-size: 28px;
            color: #2e8b57;
            margin-bottom: 5px;
        }

        .stats-info p {
            color: #6c757d;
            font-size: 14px;
        }

        .table-container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
            overflow: hidden;
            margin-bottom: 30px;
        }

        .table-responsive {
            overflow-x: auto;
        }

        .timeline-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 800px;
        }

        .timeline-table thead {
            background: linear-gradient(to right, #2e8b57, #3cb371);
        }

        .timeline-table th {
            padding: 18px 20px;
            color: white;
            font-weight: 600;
            text-align: left;
            font-size: 15px;
        }

        .timeline-table th:first-child {
            width: 60px;
            text-align: center;
        }

        .timeline-table th:nth-child(2) {
            min-width: 300px;
        }

        .timeline-table th:nth-child(3) {
            width: 150px;
        }

        .timeline-table th:nth-child(4) {
            width: 150px;
            text-align: center;
        }

        .timeline-table th:last-child {
            width: 180px;
            text-align: center;
        }

        .timeline-table tbody tr {
            border-bottom: 1px solid #f0f0f0;
            transition: all 0.2s;
        }

        .timeline-table tbody tr:hover {
            background: #f8f9fa;
        }

        .timeline-table td {
            padding: 16px 20px;
            vertical-align: middle;
        }

        .timeline-table td:first-child {
            text-align: center;
            font-weight: 600;
            color: #2e8b57;
        }

        .timeline-title {
            font-weight: 600;
            color: #333;
            font-size: 15px;
            line-height: 1.4;
            margin-bottom: 5px;
        }

        .timeline-description {
            font-size: 13px;
            color: #666;
            line-height: 1.4;
            max-width: 500px;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .timeline-date {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .date-main {
            font-weight: 600;
            color: #2e8b57;
            font-size: 14px;
        }

        .date-relative {
            font-size: 12px;
            color: #6c757d;
            font-style: italic;
        }

        .timeline-status {
            text-align: center;
        }

        .status-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }

        .status-upcoming {
            background: #fff3cd;
            color: #856404;
        }

        .status-ongoing {
            background: #d4edda;
            color: #155724;
        }

        .status-completed {
            background: #e2e3e5;
            color: #383d41;
        }

        .action-buttons-cell {
            display: flex;
            gap: 8px;
            justify-content: center;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #6c757d;
        }

        .empty-state i {
            font-size: 48px;
            color: #ddd;
            margin-bottom: 15px;
        }

        .empty-state p {
            font-size: 16px;
            margin-bottom: 20px;
        }

        .back-dashboard {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: #2e8b57;
            text-decoration: none;
            font-weight: 600;
            padding: 12px 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);
            transition: all 0.3s;
        }

        .back-dashboard:hover {
            background: #f8f9fa;
            transform: translateX(-5px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .badge-id {
            display: inline-block;
            padding: 2px 6px;
            background: #f8f9fa;
            color: #6c757d;
            border-radius: 4px;
            font-size: 11px;
            margin-left: 5px;
        }

        @media (max-width: 768px) {
            .admin-container {
                padding: 20px;
            }
            
            .header-section {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .action-buttons {
                width: 100%;
            }
            
            .btn {
                flex: 1;
                justify-content: center;
            }
            
            .timeline-table td, .timeline-table th {
                padding: 12px 15px;
            }
            
            .action-buttons-cell {
                flex-direction: column;
                gap: 6px;
            }
            
            .btn-edit, .btn-delete {
                width: 100%;
                justify-content: center;
            }
            
            .timeline-description {
                -webkit-line-clamp: 1;
            }
        }
    </style>
</head>
<body>

<div class="admin-container">
    <!-- Header Section -->
    <div class="header-section">
        <div>
            <h1 class="page-title">
                <i class="fas fa-calendar-alt"></i>
                Kelola Timeline Desa
            </h1>
            <p style="color: #6c757d; margin-top: 5px;">Kelola jadwal kegiatan dan event desa</p>
        </div>
        
        <div class="action-buttons">
            <a href="tambah.php" class="btn btn-primary">
                <i class="fas fa-plus-circle"></i>
                Tambah Timeline
            </a>
            <a href="../dashboard.php" class="btn btn-secondary">
                <i class="fas fa-tachometer-alt"></i>
                Dashboard
            </a>
        </div>
    </div>

    <!-- Stats Card -->
    <div class="stats-card">
        <div class="stats-icon">
            <i class="fas fa-clock"></i>
        </div>
        <div class="stats-info">
            <h3><?= $total_timeline ?></h3>
            <p>Total Kegiatan Tersimpan</p>
        </div>
    </div>

    <!-- Timeline Table -->
    <div class="table-container">
        <div class="table-responsive">
            <table class="timeline-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Judul & Deskripsi</th>
                        <th>Tanggal</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($query && mysqli_num_rows($query) > 0): 
                        $no = 1;
                        while ($row = mysqli_fetch_assoc($query)): 
                            $truncated_desc = strlen($row['deskripsi']) > 120 ? 
                                substr($row['deskripsi'], 0, 117) . '...' : 
                                $row['deskripsi'];
                            
                            $event_date = new DateTime($row['tanggal_kegiatan']);
                            $today = new DateTime();
                            $interval = $today->diff($event_date);
                            
                            // Tentukan status berdasarkan tanggal
                            $status_class = '';
                            $status_text = '';
                            
                            if ($event_date < $today) {
                                $status_class = 'status-completed';
                                $status_text = 'Selesai';
                            } elseif ($interval->days <= 7) {
                                $status_class = 'status-ongoing';
                                $status_text = 'Segera';
                            } else {
                                $status_class = 'status-upcoming';
                                $status_text = 'Akan Datang';
                            }
                            
                            // Format tanggal relatif
                            $relative_date = '';
                            if ($event_date < $today) {
                                $days_passed = $interval->days;
                                if ($days_passed == 0) {
                                    $relative_date = 'Hari ini';
                                } elseif ($days_passed == 1) {
                                    $relative_date = 'Kemarin';
                                } else {
                                    $relative_date = $days_passed . ' hari yang lalu';
                                }
                            } else {
                                $days_left = $interval->days;
                                if ($days_left == 0) {
                                    $relative_date = 'Hari ini';
                                } elseif ($days_left == 1) {
                                    $relative_date = 'Besok';
                                } else {
                                    $relative_date = $days_left . ' hari lagi';
                                }
                            }
                    ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td>
                            <div class="timeline-title">
                                <?= htmlspecialchars($row['judul']) ?>
                                <span class="badge-id">#<?= $row['id'] ?></span>
                            </div>
                            <div class="timeline-description">
                                <?= htmlspecialchars($truncated_desc) ?>
                            </div>
                        </td>
                        <td>
                            <div class="timeline-date">
                                <span class="date-main">
                                    <?= date('d M Y', strtotime($row['tanggal_kegiatan'])) ?>
                                </span>
                                <span class="date-relative">
                                    <?= $relative_date ?>
                                </span>
                            </div>
                        </td>
                        <td class="timeline-status">
                            <span class="status-badge <?= $status_class ?>">
                                <?= $status_text ?>
                            </span>
                        </td>
                        <td>
                            <div class="action-buttons-cell">
                                <a href="edit.php?id=<?= $row['id']; ?>" class="btn-edit">
                                    <i class="fas fa-edit"></i> Edit
                                </a>
                                <a href="hapus.php?id=<?= $row['id']; ?>" 
                                   class="btn-delete"
                                   onclick="return confirm('Apakah Anda yakin ingin menghapus timeline ini?\n\nJudul: <?= addslashes(htmlspecialchars($row['judul'])) ?>\nTanggal: <?= date('d M Y', strtotime($row['tanggal_kegiatan'])) ?>')">
                                    <i class="fas fa-trash-alt"></i> Hapus
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                    
                    <?php else: ?>
                    <tr>
                        <td colspan="5">
                            <div class="empty-state">
                                <i class="far fa-calendar-alt"></i>
                                <p>Belum ada timeline kegiatan yang ditambahkan</p>
                                <a href="tambah.php" class="btn btn-primary">
                                    <i class="fas fa-plus-circle"></i>
                                    Tambah Kegiatan Pertama
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Back to Dashboard -->
    <a href="../dashboard.php" class="back-dashboard">
        <i class="fas fa-arrow-left"></i>
        Kembali ke Dashboard Admin
    </a>
</div>

<script>
    // Efek hover untuk baris tabel
    document.querySelectorAll('.timeline-table tbody tr').forEach(row => {
        row.addEventListener('mouseenter', function() {
            this.style.transform = 'translateX(5px)';
            this.style.boxShadow = '0 3px 10px rgba(0,0,0,0.05)';
        });
        
        row.addEventListener('mouseleave', function() {
            this.style.transform = 'translateX(0)';
            this.style.boxShadow = 'none';
        });
    });

    // Konfirmasi penghapusan yang lebih baik
    document.querySelectorAll('.btn-delete').forEach(button => {
        button.addEventListener('click', function(e) {
            const row = this.closest('tr');
            const title = row.querySelector('.timeline-title').textContent.trim();
            const date = row.querySelector('.date-main').textContent.trim();
            
            if (!confirm(`Yakin ingin menghapus timeline:\n\n"${title}"\n\nTanggal: ${date}`)) {
                e.preventDefault();
            }
        });
    });

    // Efek hover untuk semua tombol
    document.querySelectorAll('.btn').forEach(btn => {
        btn.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-3px)';
        });
        
        btn.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });

    // Update status real-time berdasarkan waktu
    function updateTimelineStatus() {
        const now = new Date();
        const rows = document.querySelectorAll('.timeline-table tbody tr');
        
        rows.forEach(row => {
            const dateText = row.querySelector('.date-main').textContent;
            const dateParts = dateText.split(' ');
            const months = {
                'Jan': 0, 'Feb': 1, 'Mar': 2, 'Apr': 3, 'Mei': 4, 'Jun': 5,
                'Jul': 6, 'Agu': 7, 'Sep': 8, 'Okt': 9, 'Nov': 10, 'Des': 11
            };
            
            const day = parseInt(dateParts[0]);
            const month = months[dateParts[1]];
            const year = parseInt(dateParts[2]);
            
            const eventDate = new Date(year, month, day);
            const diffTime = eventDate - now;
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
            
            // Update relative date
            const relativeEl = row.querySelector('.date-relative');
            if (relativeEl) {
                if (diffDays === 0) {
                    relativeEl.textContent = 'Hari ini';
                } else if (diffDays === 1) {
                    relativeEl.textContent = 'Besok';
                } else if (diffDays === -1) {
                    relativeEl.textContent = 'Kemarin';
                } else if (diffDays > 1) {
                    relativeEl.textContent = `${diffDays} hari lagi`;
                } else {
                    relativeEl.textContent = `${Math.abs(diffDays)} hari yang lalu`;
                }
            }
        });
    }

    // Update status setiap jam
    updateTimelineStatus();
    setInterval(updateTimelineStatus, 3600000); // Setiap 1 jam
</script>

</body>
</html>