<?php
session_start();
include '../../koneksi.php';

$id = $_GET['id'];
mysqli_query($conn, "DELETE FROM timeline_desa WHERE id=$id");

header("Location: index.php");
