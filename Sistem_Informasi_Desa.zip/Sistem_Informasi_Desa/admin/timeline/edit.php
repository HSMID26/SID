<?php
session_start();
include '../../koneksi.php';

// Cek session admin
if (!isset($_SESSION['admin'])) {
    header("Location: ../../login.php");
    exit;
}

$id = $_GET['id'] ?? null;
if (!$id) {
    header("Location: index.php");
    exit;
}

$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM timeline_desa WHERE id=$id"));

if (!$data) {
    header("Location: index.php");
    exit;
}

$success = "";
$error = "";

if (isset($_POST['update'])) {
    $judul = mysqli_real_escape_string($conn, trim($_POST['judul']));
    $deskripsi = mysqli_real_escape_string($conn, trim($_POST['deskripsi']));
    $tanggal = mysqli_real_escape_string($conn, trim($_POST['tanggal']));
    
    if (empty($judul) || empty($deskripsi) || empty($tanggal)) {
        $error = "Semua field tidak boleh kosong!";
    } else {
        $update_query = "UPDATE timeline_desa SET
                        judul='$judul',
                        deskripsi='$deskripsi',
                        tanggal_kegiatan='$tanggal'
                        WHERE id=$id";
        
        if (mysqli_query($conn, $update_query)) {
            $success = "Timeline berhasil diperbarui!";
            // Refresh data
            $data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM timeline_desa WHERE id=$id"));
        } else {
            $error = "Gagal memperbarui timeline!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Timeline - Admin Desa</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            padding: 20px;
            color: #333;
        }

        .container {
            max-width: 800px;
            margin: 40px auto;
            background: white;
            border-radius: 16px;
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.12);
            overflow: hidden;
        }

        .header {
            background: linear-gradient(to right, #2e8b57, #3cb371);
            color: white;
            padding: 30px;
            position: relative;
        }

        .header h1 {
            font-size: 28px;
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 8px;
        }

        .header h1 i {
            background: rgba(255, 255, 255, 0.2);
            padding: 12px;
            border-radius: 10px;
            font-size: 22px;
        }

        .header p {
            opacity: 0.9;
            font-size: 15px;
            margin-left: 57px;
        }

        .back-link {
            position: absolute;
            right: 30px;
            top: 35px;
            color: white;
            text-decoration: none;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 8px;
            background: rgba(255, 255, 255, 0.15);
            padding: 10px 18px;
            border-radius: 30px;
            transition: all 0.3s;
        }

        .back-link:hover {
            background: rgba(255, 255, 255, 0.25);
            transform: translateX(-5px);
        }

        .content {
            padding: 40px;
        }

        .alert {
            padding: 16px 20px;
            margin-bottom: 25px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: fadeIn 0.3s ease;
        }

        .alert-success {
            background: #d4edda;
            border-left: 4px solid #28a745;
            color: #155724;
        }

        .alert-error {
            background: #ffeaea;
            border-left: 4px solid #ff5252;
            color: #d32f2f;
        }

        .current-data {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 25px;
            border-left: 4px solid #2e8b57;
        }

        .current-data h3 {
            color: #2e8b57;
            margin-bottom: 15px;
            font-size: 16px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .data-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }

        .data-item {
            background: white;
            padding: 12px;
            border-radius: 6px;
            border: 1px solid #eee;
        }

        .data-label {
            font-size: 12px;
            color: #666;
            margin-bottom: 5px;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .data-value {
            font-weight: 500;
            color: #333;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            margin-bottom: 10px;
            font-weight: 600;
            color: #444;
            font-size: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .form-group label i {
            color: #2e8b57;
            width: 20px;
        }

        .form-group input[type="text"],
        .form-group input[type="date"],
        .form-group textarea {
            width: 100%;
            padding: 16px 18px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 15px;
            transition: all 0.3s;
            background: #fafafa;
        }

        .form-group input[type="text"]:focus,
        .form-group input[type="date"]:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #2e8b57;
            background: white;
            box-shadow: 0 0 0 4px rgba(46, 139, 87, 0.1);
        }

        .form-group textarea {
            resize: vertical;
            min-height: 150px;
            line-height: 1.6;
        }

        .form-group input[type="date"] {
            max-width: 300px;
        }

        .char-count {
            text-align: right;
            font-size: 13px;
            color: #777;
            margin-top: 8px;
        }

        .date-hint {
            font-size: 13px;
            color: #666;
            margin-top: 8px;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .date-hint i {
            color: #ff9800;
        }

        .button-group {
            display: flex;
            gap: 15px;
            margin-top: 35px;
            padding-top: 25px;
            border-top: 1px solid #eee;
        }

        .btn {
            padding: 16px 30px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            border: none;
            text-decoration: none;
            flex: 1;
        }

        .btn-primary {
            background: linear-gradient(to right, #2e8b57, #3cb371);
            color: white;
            box-shadow: 0 4px 15px rgba(46, 139, 87, 0.3);
        }

        .btn-primary:hover {
            background: linear-gradient(to right, #26734d, #2e8b57);
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(46, 139, 87, 0.4);
        }

        .btn-secondary {
            background: #f5f5f5;
            color: #666;
            border: 1px solid #ddd;
        }

        .btn-secondary:hover {
            background: #e9e9e9;
            transform: translateY(-3px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 768px) {
            .container {
                margin: 20px auto;
                border-radius: 12px;
            }
            
            .content {
                padding: 25px;
            }
            
            .header {
                padding: 25px 20px;
            }
            
            .header h1 {
                font-size: 24px;
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
            
            .header p {
                margin-left: 0;
                margin-top: 5px;
            }
            
            .back-link {
                position: relative;
                right: auto;
                top: auto;
                display: inline-flex;
                margin-top: 15px;
                width: 100%;
                justify-content: center;
            }
            
            .data-grid {
                grid-template-columns: 1fr;
            }
            
            .button-group {
                flex-direction: column;
            }
            
            .form-group input[type="date"] {
                max-width: 100%;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <h1>
            <i class="fas fa-edit"></i>
            Edit Timeline Desa
        </h1>
        <p>Perbarui kegiatan atau event dalam timeline desa</p>
        <a href="index.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Kembali ke Daftar
        </a>
    </div>
    
    <div class="content">
        <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <span><?= htmlspecialchars($success) ?></span>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i>
                <span><?= htmlspecialchars($error) ?></span>
            </div>
        <?php endif; ?>

        <div class="current-data">
            <h3>
                <i class="fas fa-info-circle"></i>
                Data Timeline Saat Ini
            </h3>
            <div class="data-grid">
                <div class="data-item">
                    <div class="data-label">
                        <i class="fas fa-hashtag"></i>
                        ID Timeline
                    </div>
                    <div class="data-value">#<?= htmlspecialchars($id) ?></div>
                </div>
                <div class="data-item">
                    <div class="data-label">
                        <i class="fas fa-calendar-alt"></i>
                        Tanggal Saat Ini
                    </div>
                    <div class="data-value"><?= date('d M Y', strtotime($data['tanggal_kegiatan'])) ?></div>
                </div>
                <div class="data-item">
                    <div class="data-label">
                        <i class="fas fa-clock"></i>
                        Terakhir Diupdate
                    </div>
                    <div class="data-value">
                        <?= !empty($data['updated_at']) ? date('d M Y H:i', strtotime($data['updated_at'])) : '-' ?>
                    </div>
                </div>
            </div>
        </div>

        <form method="post" id="timelineForm">
            <div class="form-group">
                <label for="judul">
                    <i class="fas fa-heading"></i>
                    Judul Kegiatan
                </label>
                <input type="text" id="judul" name="judul" 
                       value="<?= htmlspecialchars($data['judul']) ?>"
                       placeholder="Contoh: Musyawarah Desa Tahunan 2024"
                       maxlength="150"
                       required>
                <div class="char-count" id="judulCount"><?= strlen($data['judul']) ?>/150 karakter</div>
            </div>
            
            <div class="form-group">
                <label for="deskripsi">
                    <i class="fas fa-align-left"></i>
                    Deskripsi Kegiatan
                </label>
                <textarea id="deskripsi" name="deskripsi" 
                          placeholder="Jelaskan detail kegiatan, lokasi, waktu, dan informasi penting lainnya..."
                          rows="6"
                          required><?= htmlspecialchars($data['deskripsi']) ?></textarea>
                <div class="char-count" id="deskripsiCount"><?= strlen($data['deskripsi']) ?> karakter</div>
            </div>
            
            <div class="form-group">
                <label for="tanggal">
                    <i class="fas fa-calendar-day"></i>
                    Tanggal Kegiatan
                </label>
                <input type="date" id="tanggal" name="tanggal" 
                       value="<?= htmlspecialchars($data['tanggal_kegiatan']) ?>"
                       required>
                <div class="date-hint">
                    <i class="fas fa-lightbulb"></i>
                    Format: YYYY-MM-DD (Tahun-Bulan-Tanggal)
                </div>
            </div>
            
            <div class="button-group">
                <button type="submit" name="update" class="btn btn-primary">
                    <i class="fas fa-save"></i>
                    Simpan Perubahan
                </button>
                <a href="index.php" class="btn btn-secondary">
                    <i class="fas fa-times"></i>
                    Batal
                </a>
            </div>
        </form>
    </div>
</div>

<script>
    // Fungsi untuk menghitung karakter
    function updateCharCount(element, counterId, maxLength = null) {
        const count = element.value.length;
        const counter = document.getElementById(counterId);
        
        if (maxLength) {
            counter.textContent = `${count}/${maxLength} karakter`;
            if (count > maxLength * 0.9) {
                counter.style.color = '#ff5252';
                counter.innerHTML += ' <i class="fas fa-exclamation-triangle"></i>';
            } else if (count > maxLength * 0.7) {
                counter.style.color = '#ff9800';
            } else {
                counter.style.color = '#777';
            }
        } else {
            counter.textContent = `${count} karakter`;
        }
    }
    
    // Format tanggal untuk tampilan yang lebih baik
    function formatDate(dateString) {
        const options = { year: 'numeric', month: 'long', day: 'numeric' };
        return new Date(dateString).toLocaleDateString('id-ID', options);
    }
    
    // Inisialisasi event listeners
    document.addEventListener('DOMContentLoaded', function() {
        const judulInput = document.getElementById('judul');
        const deskripsiTextarea = document.getElementById('deskripsi');
        const tanggalInput = document.getElementById('tanggal');
        
        // Format tanggal yang ditampilkan
        const originalDate = tanggalInput.value;
        if (originalDate) {
            const formattedDate = formatDate(originalDate);
            console.log('Tanggal kegiatan:', formattedDate);
        }
        
        judulInput.addEventListener('input', function() {
            updateCharCount(this, 'judulCount', 150);
        });
        
        deskripsiTextarea.addEventListener('input', function() {
            updateCharCount(this, 'deskripsiCount');
        });
        
        // Validasi tanggal tidak boleh lebih dari hari ini + 2 tahun
        const today = new Date();
        const maxDate = new Date();
        maxDate.setFullYear(today.getFullYear() + 2);
        
        const todayStr = today.toISOString().split('T')[0];
        const maxDateStr = maxDate.toISOString().split('T')[0];
        
        tanggalInput.min = '2000-01-01';
        tanggalInput.max = maxDateStr;
        
        // Validasi form
        document.getElementById('timelineForm').addEventListener('submit', function(e) {
            const judul = judulInput.value.trim();
            const deskripsi = deskripsiTextarea.value.trim();
            const tanggal = tanggalInput.value;
            
            if (judul === '' || deskripsi === '' || tanggal === '') {
                e.preventDefault();
                alert('Semua field tidak boleh kosong!');
                return false;
            }
            
            if (judul.length > 150) {
                e.preventDefault();
                alert('Judul tidak boleh lebih dari 150 karakter!');
                return false;
            }
            
            if (deskripsi.length < 10) {
                e.preventDefault();
                alert('Deskripsi terlalu pendek! Minimal 10 karakter.');
                return false;
            }
            
            // Validasi tanggal
            const selectedDate = new Date(tanggal);
            const minDate = new Date('2000-01-01');
            const maxValidDate = new Date(maxDateStr);
            
            if (selectedDate < minDate) {
                e.preventDefault();
                alert('Tanggal tidak valid! Minimal tahun 2000.');
                return false;
            }
            
            if (selectedDate > maxValidDate) {
                e.preventDefault();
                alert('Tanggal tidak boleh lebih dari 2 tahun dari sekarang.');
                return false;
            }
        });
    });
</script>

</body>
</html>