<?php
session_start();
include '../koneksi.php';

/* ===============================
   CEK LOGIN ADMIN
================================ */
if (!isset($_SESSION['admin'])) {
    header("Location: ../login.php");
    exit;
}

$admin = $_SESSION['admin'];

// Query untuk data statistik
$total_berita = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM berita"))[0];
$total_pengaduan = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM pengaduan"))[0];
$pengaduan_baru = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM pengaduan WHERE status='terkirim'"))[0];
$total_timeline = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM timeline"))[0];
$total_persyaratan = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM persyaratan"))[0];

// Dapatkan base URL/direktori
$current_dir = dirname($_SERVER['PHP_SELF']);
$base_path = rtrim(str_replace('/admin', '', $current_dir), '/') . '/admin/';

// Waktu sambutan berdasarkan jam
$hour = date('H');
if ($hour < 12) {
    $greeting = "Selamat Pagi";
} elseif ($hour < 15) {
    $greeting = "Selamat Siang";
} elseif ($hour < 19) {
    $greeting = "Selamat Sore";
} else {
    $greeting = "Selamat Malam";
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Desa Sampora</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary: #2e8b57;
            --primary-dark: #26734d;
            --primary-light: #3cb371;
            --sidebar: #1e5631;
            --sidebar-hover: #2a7d46;
            --text-light: #fff;
            --text-dark: #333;
            --text-muted: #6c757d;
            --card-bg: #fff;
            --card-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
            --success: #28a745;
            --warning: #ffc107;
            --danger: #dc3545;
            --info: #17a2b8;
            --gray: #f8f9fa;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #e3e7f0 100%);
            min-height: 100vh;
            color: var(--text-dark);
            display: flex;
        }

        /* SIDEBAR */
        .sidebar {
            width: 260px;
            background: linear-gradient(180deg, var(--sidebar) 0%, #164a2d 100%);
            color: var(--text-light);
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            padding: 25px 0;
            box-shadow: 5px 0 15px rgba(0, 0, 0, 0.1);
            z-index: 1000;
            transition: all 0.3s ease;
        }

        .sidebar-header {
            padding: 0 25px 30px 25px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 20px;
        }

        .sidebar-header h2 {
            font-size: 22px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 5px;
        }

        .sidebar-header h2 i {
            background: rgba(255, 255, 255, 0.15);
            padding: 10px;
            border-radius: 10px;
            font-size: 20px;
        }

        .sidebar-header p {
            font-size: 13px;
            opacity: 0.8;
            margin-left: 42px;
        }

        .nav-menu {
            padding: 0 15px;
        }

        .nav-item {
            margin-bottom: 5px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 14px 20px;
            color: rgba(255, 255, 255, 0.9);
            text-decoration: none;
            border-radius: 10px;
            transition: all 0.3s ease;
            font-size: 15px;
            font-weight: 500;
        }

        .nav-link i {
            width: 20px;
            text-align: center;
            font-size: 18px;
            opacity: 0.9;
        }

        .nav-link:hover {
            background: var(--sidebar-hover);
            color: white;
            transform: translateX(5px);
        }

        .nav-link.active {
            background: linear-gradient(to right, var(--primary), var(--primary-light));
            color: white;
            box-shadow: 0 4px 12px rgba(46, 139, 87, 0.3);
        }

        /* MAIN CONTENT */
        .main-content {
            flex: 1;
            margin-left: 260px;
            padding: 30px;
            min-height: 100vh;
        }

        /* TOPBAR */
        .topbar {
            background: var(--card-bg);
            border-radius: 12px;
            padding: 20px 25px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: var(--card-shadow);
        }

        .page-title h1 {
            font-size: 28px;
            color: var(--primary);
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .page-title p {
            color: var(--text-muted);
            font-size: 14px;
            margin-top: 5px;
            margin-left: 42px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .user-details {
            text-align: right;
        }

        .user-name {
            font-weight: 600;
            color: var(--text-dark);
            font-size: 15px;
        }

        .user-role {
            font-size: 13px;
            color: var(--text-muted);
            margin-top: 2px;
        }

        .logout-btn {
            background: var(--danger);
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
        }

        .logout-btn:hover {
            background: #c82333;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(220, 53, 69, 0.3);
        }

        /* WELCOME CARD */
        .welcome-card {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-light) 100%);
            border-radius: 16px;
            padding: 30px;
            margin-bottom: 30px;
            color: white;
            box-shadow: 0 10px 30px rgba(46, 139, 87, 0.3);
            position: relative;
            overflow: hidden;
        }

        .welcome-card::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -20%;
            width: 200px;
            height: 200px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
        }

        .welcome-card h3 {
            font-size: 24px;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .welcome-card p {
            font-size: 15px;
            opacity: 0.9;
            max-width: 600px;
        }

        .welcome-info {
            display: flex;
            gap: 30px;
            margin-top: 20px;
            flex-wrap: wrap;
        }

        .info-item {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .info-item i {
            background: rgba(255, 255, 255, 0.2);
            padding: 10px;
            border-radius: 10px;
            font-size: 18px;
        }

        /* STATS GRID */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 25px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: var(--card-bg);
            border-radius: 12px;
            padding: 25px;
            box-shadow: var(--card-shadow);
            transition: all 0.3s ease;
            border-left: 4px solid var(--primary);
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.15);
        }

        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 20px;
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            color: white;
        }

        .stat-news .stat-icon { background: linear-gradient(135deg, #3498db, #2980b9); }
        .stat-complaints .stat-icon { background: linear-gradient(135deg, #e74c3c, #c0392b); }
        .stat-timeline .stat-icon { background: linear-gradient(135deg, #9b59b6, #8e44ad); }
        .stat-requirements .stat-icon { background: linear-gradient(135deg, #2ecc71, #27ae60); }

        .stat-number {
            font-size: 32px;
            font-weight: 700;
            color: var(--text-dark);
            margin-bottom: 5px;
        }

        .stat-label {
            font-size: 15px;
            color: var(--text-muted);
            font-weight: 500;
        }

        .stat-trend {
            font-size: 13px;
            padding: 4px 10px;
            border-radius: 20px;
            display: inline-block;
            margin-top: 10px;
        }

        .trend-up { background: #d4edda; color: #155724; }
        .trend-down { background: #f8d7da; color: #721c24; }

        /* QUICK ACTIONS */
        .quick-actions {
            background: var(--card-bg);
            border-radius: 12px;
            padding: 30px;
            box-shadow: var(--card-shadow);
            margin-bottom: 30px;
        }

        .section-title {
            font-size: 20px;
            font-weight: 600;
            color: var(--text-dark);
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .actions-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }

        .action-btn {
            background: var(--gray);
            border: 2px solid #e9ecef;
            border-radius: 10px;
            padding: 20px;
            text-decoration: none;
            color: var(--text-dark);
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .action-btn:hover {
            background: white;
            border-color: var(--primary);
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .action-icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 22px;
        }

        .action-info h4 {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 5px;
        }

        .action-info p {
            font-size: 13px;
            color: var(--text-muted);
        }

        /* FOOTER */
        .admin-footer {
            text-align: center;
            padding: 20px;
            color: var(--text-muted);
            font-size: 14px;
            border-top: 1px solid #eee;
            margin-top: 40px;
        }

        /* RESPONSIVE */
        @media (max-width: 1024px) {
            .sidebar {
                width: 230px;
            }
            
            .main-content {
                margin-left: 230px;
            }
            
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 768px) {
            body {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                padding: 20px;
            }
            
            .nav-menu {
                display: flex;
                flex-wrap: wrap;
                gap: 10px;
            }
            
            .nav-item {
                flex: 1;
                min-width: 150px;
            }
            
            .main-content {
                margin-left: 0;
                padding: 20px;
            }
            
            .topbar {
                flex-direction: column;
                gap: 20px;
                text-align: center;
            }
            
            .user-info {
                flex-direction: column;
                gap: 15px;
            }
            
            .user-details {
                text-align: center;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .actions-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 480px) {
            .nav-menu {
                flex-direction: column;
            }
            
            .nav-item {
                width: 100%;
            }
            
            .welcome-info {
                flex-direction: column;
                gap: 15px;
            }
        }
    </style>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <div class="sidebar-header">
        <h2>
            <i class="fas fa-user-shield"></i>
            Admin Desa
        </h2>
        <p>Panel Administrasi Desa Sampora</p>
    </div>
    
    <div class="nav-menu">
        <div class="nav-item">
            <a href="<?php echo $base_path; ?>dashboard.php" class="nav-link active">
                <i class="fas fa-tachometer-alt"></i>
                Dashboard
            </a>
        </div>
        <div class="nav-item">
            <a href="<?php echo $base_path; ?>profil_desa/index.php" class="nav-link">
                <i class="fas fa-home"></i>
                Profil Desa
            </a>
        </div>
        <div class="nav-item">
            <a href="<?php echo $base_path; ?>berita/index.php" class="nav-link">
                <i class="fas fa-newspaper"></i>
                Berita Desa
            </a>
        </div>
        <div class="nav-item">
            <a href="<?php echo $base_path; ?>anggaran/index.php" class="nav-link">
                <i class="fas fa-chart-pie"></i>
                Anggaran
            </a>
        </div>
        <div class="nav-item">
            <a href="<?php echo $base_path; ?>timeline/index.php" class="nav-link">
                <i class="fas fa-calendar-alt"></i>
                Timeline
            </a>
        </div>
        <div class="nav-item">
            <a href="<?php echo $base_path; ?>persyaratan/index.php" class="nav-link">
                <i class="fas fa-file-alt"></i>
                Persyaratan
            </a>
        </div>
        <div class="nav-item">
            <a href="<?php echo $base_path; ?>pengaduan/index.php" class="nav-link">
                <i class="fas fa-comments"></i>
                Pengaduan
            </a>
        </div>
    </div>
</div>

<!-- MAIN CONTENT -->
<div class="main-content">
    <!-- TOPBAR -->
    <div class="topbar">
        <div class="page-title">
            <h1>
                <i class="fas fa-tachometer-alt"></i>
                Dashboard Admin
            </h1>
            <p>Kelola website dan data desa secara efisien</p>
        </div>
        
        <div class="user-info">
            <div class="user-details">
                <div class="user-name"><?= htmlspecialchars($admin['nama_lengkap']) ?></div>
                <div class="user-role"><?= htmlspecialchars($admin['jabatan']) ?></div>
            </div>
            <a href="../logout.php" class="logout-btn">
                <i class="fas fa-sign-out-alt"></i>
                Logout
            </a>
        </div>
    </div>

    <!-- WELCOME CARD -->
    <div class="welcome-card">
        <h3>
            <i class="fas fa-hand-wave"></i>
            <?= $greeting ?>, <?= htmlspecialchars($admin['nama_lengkap']) ?>!
        </h3>
        <p>Selamat datang di dashboard administrasi Desa Sampora. Anda dapat mengelola semua konten dan data desa dari sini.</p>
        
        <div class="welcome-info">
            <div class="info-item">
                <i class="far fa-calendar-alt"></i>
                <span><?= date('l, d F Y') ?></span>
            </div>
            <div class="info-item">
                <i class="far fa-clock"></i>
                <span><?= date('H:i') ?> WIB</span>
            </div>
            <div class="info-item">
                <i class="fas fa-map-marker-alt"></i>
                <span>Desa Sampora</span>
            </div>
        </div>
    </div>

    <!-- STATS GRID -->
    <div class="stats-grid">
        <div class="stat-card stat-news">
            <div class="stat-header">
                <div>
                    <div class="stat-number"><?= $total_berita ?></div>
                    <div class="stat-label">Total Berita</div>
                </div>
                <div class="stat-icon">
                    <i class="fas fa-newspaper"></i>
                </div>
            </div>
            <div class="stat-trend trend-up">
                <i class="fas fa-arrow-up"></i> Terupdate
            </div>
        </div>
        
        <div class="stat-card stat-complaints">
            <div class="stat-header">
                <div>
                    <div class="stat-number"><?= $total_pengaduan ?></div>
                    <div class="stat-label">Total Pengaduan</div>
                </div>
                <div class="stat-icon">
                    <i class="fas fa-comments"></i>
                </div>
            </div>
            <?php if ($pengaduan_baru > 0): ?>
            <div class="stat-trend trend-up" style="background: #fff3cd; color: #856404;">
                <i class="fas fa-exclamation-circle"></i> <?= $pengaduan_baru ?> baru
            </div>
            <?php else: ?>
            <div class="stat-trend trend-down">
                <i class="fas fa-check-circle"></i> Semua diproses
            </div>
            <?php endif; ?>
        </div>
        
        <div class="stat-card stat-timeline">
            <div class="stat-header">
                <div>
                    <div class="stat-number"><?= $total_timeline ?></div>
                    <div class="stat-label">Kegiatan Timeline</div>
                </div>
                <div class="stat-icon">
                    <i class="fas fa-calendar-alt"></i>
                </div>
            </div>
            <div class="stat-trend trend-up">
                <i class="fas fa-calendar-check"></i> Aktif
            </div>
        </div>
        
        <div class="stat-card stat-requirements">
            <div class="stat-header">
                <div>
                    <div class="stat-number"><?= $total_persyaratan ?></div>
                    <div class="stat-label">Persyaratan</div>
                </div>
                <div class="stat-icon">
                    <i class="fas fa-file-alt"></i>
                </div>
            </div>
            <div class="stat-trend trend-up">
                <i class="fas fa-file-contract"></i> Tersedia
            </div>
        </div>
    </div>

    <!-- QUICK ACTIONS -->
    <div class="quick-actions">
        <h3 class="section-title">
            <i class="fas fa-bolt"></i>
            Akses Cepat
        </h3>
        
        <div class="actions-grid">
            <a href="<?php echo $base_path; ?>berita/tambah.php" class="action-btn">
                <div class="action-icon">
                    <i class="fas fa-plus"></i>
                </div>
                <div class="action-info">
                    <h4>Tambah Berita</h4>
                    <p>Buat berita baru untuk warga</p>
                </div>
            </a>
            
            <a href="<?php echo $base_path; ?>pengaduan/index.php" class="action-btn">
                <div class="action-icon" style="background: linear-gradient(135deg, #e74c3c, #c0392b);">
                    <i class="fas fa-comments"></i>
                </div>
                <div class="action-info">
                    <h4>Kelola Pengaduan</h4>
                    <p>Lihat dan tanggapi pengaduan</p>
                </div>
            </a>
            
            <a href="<?php echo $base_path; ?>timeline/tambah.php" class="action-btn">
                <div class="action-icon" style="background: linear-gradient(135deg, #9b59b6, #8e44ad);">
                    <i class="fas fa-calendar-plus"></i>
                </div>
                <div class="action-info">
                    <h4>Tambah Kegiatan</h4>
                    <p>Jadwalkan kegiatan baru</p>
                </div>
            </a>
            
            <a href="<?php echo $base_path; ?>persyaratan/tambah.php" class="action-btn">
                <div class="action-icon" style="background: linear-gradient(135deg, #2ecc71, #27ae60);">
                    <i class="fas fa-file-signature"></i>
                </div>
                <div class="action-info">
                    <h4>Tambah Persyaratan</h4>
                    <p>Buat dokumen persyaratan</p>
                </div>
            </a>
        </div>
    </div>

    <!-- FOOTER -->
    <div class="admin-footer">
        <p>© <?= date('Y') ?> Sistem Administrasi Desa Sampora | Versi 2.0</p>
        <p style="font-size: 12px; margin-top: 5px; opacity: 0.7;">
            <i class="fas fa-server"></i> Terakhir login: <?= date('d M Y H:i') ?>
        </p>
    </div>
</div>

<script>
    // Update waktu secara real-time
    function updateTime() {
        const now = new Date();
        const options = { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
        };
        
        // Format waktu
        const timeString = now.toLocaleTimeString('id-ID', { 
            hour: '2-digit', 
            minute: '2-digit',
            hour12: false 
        });
        
        // Format tanggal
        const dateString = now.toLocaleDateString('id-ID', options);
        
        // Update elemen jika ada
        const timeElements = document.querySelectorAll('.info-item:nth-child(2) span');
        const dateElements = document.querySelectorAll('.info-item:nth-child(1) span');
        
        timeElements.forEach(el => {
            if (el.closest('.info-item:nth-child(2)')) {
                el.textContent = timeString + ' WIB';
            }
        });
        
        dateElements.forEach(el => {
            if (el.closest('.info-item:nth-child(1)')) {
                el.textContent = dateString;
            }
        });
    }
    
    // Update greeting berdasarkan waktu
    function updateGreeting() {
        const hour = new Date().getHours();
        let greeting = '';
        
        if (hour < 12) greeting = 'Selamat Pagi';
        else if (hour < 15) greeting = 'Selamat Siang';
        else if (hour < 19) greeting = 'Selamat Sore';
        else greeting = 'Selamat Malam';
        
        const greetingElements = document.querySelectorAll('.welcome-card h3');
        greetingElements.forEach(el => {
            const name = "<?= htmlspecialchars($admin['nama_lengkap']) ?>";
            const icon = '<i class="fas fa-hand-wave"></i>';
            el.innerHTML = `${icon} ${greeting}, ${name}!`;
        });
    }
    
    // Inisialisasi
    document.addEventListener('DOMContentLoaded', function() {
        updateTime();
        updateGreeting();
        
        // Update setiap menit
        setInterval(updateTime, 60000);
        
        // Update greeting setiap jam
        setInterval(updateGreeting, 3600000);
        
        // Efek hover untuk stat cards
        const statCards = document.querySelectorAll('.stat-card');
        statCards.forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-5px)';
            });
            
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0)';
            });
        });
        
        // Efek aktif untuk menu sidebar
        const currentPage = window.location.pathname;
        const navLinks = document.querySelectorAll('.nav-link');
        
        navLinks.forEach(link => {
            if (link.href.includes(currentPage.split('/').pop())) {
                link.classList.add('active');
            }
            
            link.addEventListener('click', function() {
                navLinks.forEach(l => l.classList.remove('active'));
                this.classList.add('active');
            });
        });
    });
</script>

</body>
</html>