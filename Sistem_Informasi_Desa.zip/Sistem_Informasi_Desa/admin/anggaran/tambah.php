<?php
include '../../koneksi.php';

if (isset($_POST['simpan'])) {
    $tahun = $_POST['tahun'];
    $keterangan = $_POST['keterangan'];
    $jumlah = $_POST['jumlah'];

    mysqli_query($conn, "INSERT INTO anggaran_desa (tahun, keterangan, jumlah)
        VALUES ('$tahun', '$keterangan', '$jumlah')");

    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Anggaran Desa</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #f5f7fa;
            padding: 20px;
            line-height: 1.6;
        }
        
        .container {
            max-width: 800px;
            margin: 30px auto;
            background-color: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        
        .form-header {
            background: linear-gradient(135deg, #0b8f5a, #0da768);
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .form-header h2 {
            font-size: 32px;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px;
        }
        
        .form-header p {
            opacity: 0.9;
            font-size: 16px;
            max-width: 600px;
            margin: 0 auto;
        }
        
        .form-content {
            padding: 40px;
        }
        
        .form-group {
            margin-bottom: 30px;
            position: relative;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 10px;
            font-weight: 600;
            color: #2c3e50;
            font-size: 16px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .form-group label i {
            color: #0b8f5a;
            width: 20px;
            text-align: center;
        }
        
        .form-control {
            width: 100%;
            padding: 15px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 16px;
            transition: all 0.3s;
            background-color: #f9f9f9;
            color: #333;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #0b8f5a;
            background-color: white;
            box-shadow: 0 0 0 4px rgba(11, 143, 90, 0.1);
        }
        
        .form-control:focus + .input-icon {
            color: #0b8f5a;
        }
        
        .input-with-icon {
            position: relative;
        }
        
        .input-icon {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #95a5a6;
            font-size: 18px;
            transition: color 0.3s;
        }
        
        .currency-prefix {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #7f8c8d;
            font-weight: 600;
            font-size: 16px;
        }
        
        .currency-input .form-control {
            padding-left: 60px;
        }
        
        .form-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-top: 30px;
            border-top: 2px solid #f0f0f0;
            margin-top: 40px;
            flex-wrap: wrap;
            gap: 20px;
        }
        
        .btn-simpan {
            background: linear-gradient(135deg, #0b8f5a, #0da768);
            color: white;
            border: none;
            padding: 16px 40px;
            border-radius: 10px;
            font-size: 17px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 12px;
            box-shadow: 0 5px 15px rgba(11, 143, 90, 0.3);
        }
        
        .btn-simpan:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(11, 143, 90, 0.4);
            background: linear-gradient(135deg, #0a7a4d, #0b8f5a);
        }
        
        .btn-kembali {
            background-color: #7f8c8d;
            color: white;
            text-decoration: none;
            padding: 16px 40px;
            border-radius: 10px;
            font-size: 17px;
            font-weight: 600;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 12px;
            box-shadow: 0 5px 15px rgba(127, 140, 141, 0.2);
        }
        
        .btn-kembali:hover {
            background-color: #636e72;
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(127, 140, 141, 0.3);
        }
        
        .info-box {
            background-color: #e8f6ef;
            border-left: 4px solid #0b8f5a;
            padding: 20px;
            margin-bottom: 30px;
            border-radius: 0 10px 10px 0;
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .info-box i {
            color: #0b8f5a;
            font-size: 24px;
            flex-shrink: 0;
        }
        
        .info-box p {
            margin: 0;
            color: #2c3e50;
            font-size: 15px;
            line-height: 1.5;
        }
        
        .input-hint {
            font-size: 14px;
            color: #7f8c8d;
            margin-top: 8px;
            display: flex;
            align-items: center;
            gap: 8px;
            margin-left: 30px;
        }
        
        .input-hint i {
            color: #f39c12;
        }
        
        .required {
            color: #e74c3c;
            margin-left: 4px;
        }
        
        @media (max-width: 768px) {
            .container {
                margin: 10px auto;
                border-radius: 10px;
            }
            
            .form-header {
                padding: 20px;
            }
            
            .form-header h2 {
                font-size: 26px;
                flex-direction: column;
                gap: 10px;
            }
            
            .form-content {
                padding: 25px;
            }
            
            .form-footer {
                flex-direction: column;
                gap: 15px;
            }
            
            .btn-simpan, .btn-kembali {
                width: 100%;
                justify-content: center;
            }
        }
        
        @media (max-width: 480px) {
            body {
                padding: 10px;
            }
            
            .form-control {
                padding: 12px;
            }
            
            .btn-simpan, .btn-kembali {
                padding: 14px 20px;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <div class="form-header">
            <h2>
                <i class="fas fa-plus-circle"></i>
                Tambah Anggaran Desa
            </h2>
            <p>Tambahkan data anggaran desa baru untuk perencanaan keuangan</p>
        </div>
        
        <div class="form-content">
            <div class="info-box">
                <i class="fas fa-info-circle"></i>
                <p>Silakan isi form berikut dengan data anggaran desa yang valid. Pastikan semua kolom diisi dengan benar sebelum disimpan.</p>
            </div>
            
            <form method="post" id="anggaranForm">
                <div class="form-group">
                    <label for="tahun">
                        <i class="far fa-calendar-alt"></i>
                        Tahun Anggaran <span class="required">*</span>
                    </label>
                    <div class="input-with-icon">
                        <input 
                            type="number" 
                            name="tahun" 
                            id="tahun" 
                            class="form-control" 
                            min="2000" 
                            max="2050" 
                            placeholder="Contoh: 2024" 
                            required
                        >
                        <div class="input-icon">
                            <i class="far fa-calendar"></i>
                        </div>
                    </div>
                    <div class="input-hint">
                        <i class="fas fa-lightbulb"></i>
                        Masukkan tahun anggaran (2000-2050)
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="keterangan">
                        <i class="far fa-file-alt"></i>
                        Keterangan <span class="required">*</span>
                    </label>
                    <div class="input-with-icon">
                        <input 
                            type="text" 
                            name="keterangan" 
                            id="keterangan" 
                            class="form-control" 
                            placeholder="Contoh: Anggaran Pembangunan Jalan Desa" 
                            required
                            maxlength="200"
                        >
                        <div class="input-icon">
                            <i class="fas fa-align-left"></i>
                        </div>
                    </div>
                    <div class="input-hint">
                        <i class="fas fa-lightbulb"></i>
                        Deskripsi singkat tentang tujuan anggaran (maks. 200 karakter)
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="jumlah">
                        <i class="fas fa-money-bill-wave"></i>
                        Jumlah Anggaran <span class="required">*</span>
                    </label>
                    <div class="input-with-icon currency-input">
                        <span class="currency-prefix">Rp</span>
                        <input 
                            type="number" 
                            name="jumlah" 
                            id="jumlah" 
                            class="form-control" 
                            min="0" 
                            step="1000" 
                            placeholder="0" 
                            required
                        >
                        <div class="input-icon">
                            <i class="fas fa-wallet"></i>
                        </div>
                    </div>
                    <div class="input-hint">
                        <i class="fas fa-lightbulb"></i>
                        Masukkan jumlah anggaran dalam Rupiah (tanpa titik atau koma)
                    </div>
                </div>
                
                <div class="form-footer">
                    <button type="submit" name="simpan" class="btn-simpan">
                        <i class="fas fa-save"></i>
                        Simpan Data
                    </button>
                    <a href="index.php" class="btn-kembali">
                        <i class="fas fa-arrow-left"></i>
                        Kembali ke Daftar
                    </a>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        // Format jumlah dengan separator ribuan
        document.getElementById('jumlah').addEventListener('blur', function() {
            const value = this.value.replace(/[^0-9]/g, '');
            if (value) {
                this.value = parseInt(value).toLocaleString('id-ID');
            }
        });
        
        document.getElementById('jumlah').addEventListener('focus', function() {
            this.value = this.value.replace(/[^0-9]/g, '');
        });
        
        // Validasi form sebelum submit
        document.getElementById('anggaranForm').addEventListener('submit', function(e) {
            const tahun = document.getElementById('tahun').value;
            const keterangan = document.getElementById('keterangan').value;
            const jumlah = document.getElementById('jumlah').value.replace(/[^0-9]/g, '');
            
            // Validasi tahun
            if (tahun < 2000 || tahun > 2050) {
                alert('Tahun harus antara 2000 dan 2050');
                e.preventDefault();
                return false;
            }
            
            // Validasi jumlah
            if (jumlah <= 0) {
                alert('Jumlah anggaran harus lebih dari 0');
                e.preventDefault();
                return false;
            }
            
            // Validasi keterangan
            if (keterangan.trim().length < 5) {
                alert('Keterangan terlalu pendek (minimal 5 karakter)');
                e.preventDefault();
                return false;
            }
            
            return true;
        });
        
        // Reset form jika halaman direfresh
        window.addEventListener('beforeunload', function() {
            document.getElementById('anggaranForm').reset();
        });
        
        // Auto-focus pada input pertama
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('tahun').focus();
        });
    </script>
</body>
</html>