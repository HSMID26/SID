<?php
include '../../koneksi.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Anggaran Desa</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #f5f7fa;
            padding: 20px;
            line-height: 1.6;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 20px;
        }
        
        h2 {
            color: #2c3e50;
            font-size: 28px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        h2 i {
            color: #3498db;
        }
        
        .btn-tambah {
            background: linear-gradient(135deg, #0b8f5a, #0da768);
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            font-size: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
            box-shadow: 0 4px 6px rgba(11, 143, 90, 0.2);
        }
        
        .btn-tambah:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(11, 143, 90, 0.3);
            background: linear-gradient(135deg, #0a7a4d, #0b8f5a);
        }
        
        .table-container {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            overflow: hidden;
            margin-bottom: 30px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        thead {
            background: linear-gradient(135deg, #3498db, #2980b9);
        }
        
        th {
            padding: 18px 15px;
            text-align: left;
            color: white;
            font-weight: 600;
            font-size: 15px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        th:first-child {
            border-top-left-radius: 10px;
        }
        
        th:last-child {
            border-top-right-radius: 10px;
        }
        
        tbody tr {
            border-bottom: 1px solid #f0f0f0;
            transition: background-color 0.2s;
        }
        
        tbody tr:hover {
            background-color: #f8fafc;
        }
        
        tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        
        tbody tr:nth-child(even):hover {
            background-color: #f0f7ff;
        }
        
        td {
            padding: 16px 15px;
            color: #333;
            font-size: 15px;
        }
        
        .no-data {
            text-align: center;
            padding: 40px !important;
            color: #7f8c8d;
            font-style: italic;
        }
        
        .no-data i {
            font-size: 48px;
            margin-bottom: 15px;
            color: #bdc3c7;
            display: block;
        }
        
        .aksi-buttons {
            display: flex;
            gap: 10px;
        }
        
        .btn-edit, .btn-hapus {
            padding: 8px 16px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .btn-edit {
            background-color: #f39c12;
            color: white;
        }
        
        .btn-edit:hover {
            background-color: #e67e22;
            transform: translateY(-2px);
            box-shadow: 0 3px 8px rgba(243, 156, 18, 0.3);
        }
        
        .btn-hapus {
            background-color: #e74c3c;
            color: white;
        }
        
        .btn-hapus:hover {
            background-color: #c0392b;
            transform: translateY(-2px);
            box-shadow: 0 3px 8px rgba(231, 76, 60, 0.3);
        }
        
        .jumlah-anggaran {
            font-weight: 600;
            color: #27ae60;
            font-family: 'Courier New', monospace;
            font-size: 15px;
        }
        
        .info-box {
            background-color: #e8f4fc;
            border-left: 4px solid #3498db;
            padding: 15px 20px;
            margin-bottom: 25px;
            border-radius: 0 8px 8px 0;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .info-box i {
            color: #3498db;
            font-size: 20px;
        }
        
        .info-box p {
            margin: 0;
            color: #2c3e50;
            font-size: 14px;
        }
        
        .summary-card {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }
        
        .card {
            flex: 1;
            min-width: 200px;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .card-icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
        }
        
        .card.total .card-icon {
            background-color: rgba(52, 152, 219, 0.1);
            color: #3498db;
        }
        
        .card.data .card-icon {
            background-color: rgba(46, 204, 113, 0.1);
            color: #2ecc71;
        }
        
        .card-content h3 {
            font-size: 12px;
            color: #7f8c8d;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 5px;
        }
        
        .card-content .value {
            font-size: 24px;
            font-weight: 700;
            color: #2c3e50;
        }
        
        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                align-items: flex-start;
            }
            
            th, td {
                padding: 12px 8px;
                font-size: 14px;
            }
            
            .aksi-buttons {
                flex-direction: column;
                gap: 8px;
            }
            
            .btn-edit, .btn-hapus {
                justify-content: center;
                padding: 10px;
            }
            
            .card {
                min-width: 100%;
            }
            
            table {
                display: block;
                overflow-x: auto;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <h2><i class="fas fa-chart-pie"></i> Data Anggaran Desa</h2>
            <a href="tambah.php" class="btn-tambah">
                <i class="fas fa-plus-circle"></i> Tambah Anggaran
            </a>
        </div>
        
        <?php
        $totalQuery = mysqli_query($conn, "SELECT SUM(jumlah) as total FROM anggaran");
        $totalData = mysqli_fetch_assoc($totalQuery);
        $totalAnggaran = $totalData['total'] ? $totalData['total'] : 0;
        
        $countQuery = mysqli_query($conn, "SELECT COUNT(*) as total FROM anggaran");
        $countData = mysqli_fetch_assoc($countQuery);
        $totalRows = $countData['total'];
        ?>
        
        <div class="summary-card">
            <div class="card total">
                <div class="card-icon">
                    <i class="fas fa-wallet"></i>
                </div>
                <div class="card-content">
                    <h3>Total Anggaran</h3>
                    <div class="value">Rp <?= number_format($totalAnggaran, 0, ',', '.'); ?></div>
                </div>
            </div>
            
            <div class="card data">
                <div class="card-icon">
                    <i class="fas fa-database"></i>
                </div>
                <div class="card-content">
                    <h3>Jumlah Data</h3>
                    <div class="value"><?= $totalRows; ?> Data</div>
                </div>
            </div>
        </div>
        
        <div class="info-box">
            <i class="fas fa-info-circle"></i>
            <p>Berikut adalah daftar anggaran desa yang telah direncanakan. Anda dapat mengedit atau menghapus data dengan tombol aksi di kolom terakhir.</p>
        </div>
        
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th width="60">No</th>
                        <th width="100">Tahun</th>
                        <th>Keterangan</th>
                        <th width="200">Jumlah (Rp)</th>
                        <th width="150">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    $query = mysqli_query($conn, "SELECT * FROM anggaran ORDER BY tahun DESC");

                    if (mysqli_num_rows($query) > 0) {
                        while ($a = mysqli_fetch_assoc($query)) {
                    ?>
                    <tr>
                        <td align="center"><?= $no++; ?></td>
                        <td align="center">
                            <span style="background-color: #e8f4fc; padding: 5px 10px; border-radius: 20px; font-weight: 600;">
                                <?= $a['tahun']; ?>
                            </span>
                        </td>
                        <td><?= htmlspecialchars($a['keterangan']); ?></td>
                        <td class="jumlah-anggaran" align="right">Rp <?= number_format($a['jumlah'], 0, ',', '.'); ?></td>
                        <td>
                            <div class="aksi-buttons">
                                <a href="edit.php?id=<?= $a['id']; ?>" class="btn-edit">
                                    <i class="fas fa-edit"></i> Edit
                                </a>
                                <a href="hapus.php?id=<?= $a['id']; ?>" class="btn-hapus" onclick="return confirm('Apakah Anda yakin ingin menghapus data anggaran ini?')">
                                    <i class="fas fa-trash"></i> Hapus
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php
                        }
                    } else {
                    ?>
                    <tr>
                        <td colspan="5" class="no-data">
                            <i class="fas fa-inbox"></i>
                            Belum ada data anggaran. Silakan tambah data baru.
                        </td>
                    </tr>
                    <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <script>
        // Menambahkan efek konfirmasi yang lebih baik untuk hapus
        document.querySelectorAll('.btn-hapus').forEach(button => {
            button.addEventListener('click', function(e) {
                if (!confirm('Apakah Anda yakin ingin menghapus data anggaran ini? Tindakan ini tidak dapat dibatalkan.')) {
                    e.preventDefault();
                }
            });
        });
        
        // Menambahkan efek hover pada baris tabel
        document.querySelectorAll('tbody tr').forEach(row => {
            row.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-2px)';
                this.style.boxShadow = '0 4px 8px rgba(0,0,0,0.1)';
            });
            
            row.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0)';
                this.style.boxShadow = 'none';
            });
        });
    </script>
</body>
</html>