<?php
include '../../koneksi.php';

$id = $_GET['id'];
$data = mysqli_query($conn, "SELECT * FROM anggaran WHERE id='$id'");
$a = mysqli_fetch_assoc($data);

if (isset($_POST['update'])) {
    $tahun = $_POST['tahun'];
    $keterangan = $_POST['keterangan'];
    $jumlah = $_POST['jumlah'];

    mysqli_query($conn, "UPDATE anggaran_desa SET
        tahun='$tahun',
        keterangan='$keterangan',
        jumlah='$jumlah'
        WHERE id='$id'
    ");

    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Anggaran Desa</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #f5f7fa;
            padding: 20px;
            line-height: 1.6;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            padding: 30px;
        }
        
        h2 {
            color: #2c3e50;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #eaeaea;
            font-size: 28px;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #34495e;
            font-size: 15px;
        }
        
        input[type="number"],
        input[type="text"] {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 16px;
            transition: all 0.3s;
            background-color: #f9f9f9;
        }
        
        input[type="number"]:focus,
        input[type="text"]:focus {
            outline: none;
            border-color: #3498db;
            box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.2);
            background-color: white;
        }
        
        .button-group {
            display: flex;
            gap: 15px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }
        
        .btn-update {
            background-color: #2ecc71;
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 6px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-update:hover {
            background-color: #27ae60;
        }
        
        .btn-back {
            background-color: #7f8c8d;
            color: white;
            text-decoration: none;
            padding: 12px 30px;
            border-radius: 6px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-back:hover {
            background-color: #636e72;
        }
        
        .info-box {
            background-color: #f8f9fa;
            border-left: 4px solid #3498db;
            padding: 15px;
            margin-bottom: 25px;
            border-radius: 0 6px 6px 0;
        }
        
        .info-box p {
            margin: 0;
            color: #555;
            font-size: 14px;
        }
        
        .currency-input {
            position: relative;
        }
        
        .currency-prefix {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #7f8c8d;
            font-weight: 500;
        }
        
        .currency-input input {
            padding-left: 40px;
        }
        
        @media (max-width: 768px) {
            .container {
                padding: 20px;
            }
            
            .button-group {
                flex-direction: column;
            }
            
            .btn-update, .btn-back {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <h2><i class="fas fa-edit"></i> Edit Anggaran Desa</h2>
        
        <div class="info-box">
            <p><i class="fas fa-info-circle"></i> Silakan edit data anggaran desa sesuai dengan informasi yang benar.</p>
        </div>
        
        <form method="post">
            <div class="form-group">
                <label for="tahun"><i class="far fa-calendar-alt"></i> Tahun</label>
                <input type="number" name="tahun" id="tahun" value="<?= $a['tahun']; ?>" min="2000" max="2050" required>
            </div>
            
            <div class="form-group">
                <label for="keterangan"><i class="far fa-file-alt"></i> Keterangan</label>
                <input type="text" name="keterangan" id="keterangan" value="<?= htmlspecialchars($a['keterangan']); ?>" required>
            </div>
            
            <div class="form-group">
                <label for="jumlah"><i class="fas fa-money-bill-wave"></i> Jumlah Anggaran</label>
                <div class="currency-input">
                    <span class="currency-prefix">Rp</span>
                    <input type="number" name="jumlah" id="jumlah" value="<?= $a['jumlah']; ?>" min="0" step="1000" required>
                </div>
            </div>
            
            <div class="button-group">
                <button type="submit" name="update" class="btn-update">
                    <i class="fas fa-save"></i> Update Data
                </button>
                <a href="index.php" class="btn-back">
                    <i class="fas fa-arrow-left"></i> Kembali
                </a>
            </div>
        </form>
    </div>
    
    <script>
        // Format jumlah dengan separator ribuan
        document.addEventListener('DOMContentLoaded', function() {
            const jumlahInput = document.getElementById('jumlah');
            
            jumlahInput.addEventListener('blur', function() {
                const value = this.value.replace(/[^0-9]/g, '');
                if (value) {
                    this.value = parseInt(value).toLocaleString('id-ID');
                }
            });
            
            jumlahInput.addEventListener('focus', function() {
                this.value = this.value.replace(/[^0-9]/g, '');
            });
        });
    </script>
</body>
</html>