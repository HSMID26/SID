<?php
session_start();
include '../../koneksi.php';

if (!isset($_SESSION['admin'])) {
    header("Location: ../../login.php");
    exit;
}

$id     = $_POST['id'];
$status = $_POST['status'];

$stmt = mysqli_prepare($conn, "
    UPDATE pengaduan SET status=? WHERE id=?
");
mysqli_stmt_bind_param($stmt, "si", $status, $id);
mysqli_stmt_execute($stmt);

header("Location: index.php");
exit;
