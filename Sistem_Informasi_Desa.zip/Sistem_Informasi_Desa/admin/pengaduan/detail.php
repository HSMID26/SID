<?php
session_start();
include '../../koneksi.php';

if (!isset($_SESSION['admin'])) {
    header("Location: ../../login.php");
    exit;
}

$id = $_GET['id'] ?? 0;

$stmt = mysqli_prepare($conn, "
    SELECT p.*, u.nama_lengkap, u.no_hp, u.username 
    FROM pengaduan p
    JOIN users u ON p.user_id = u.id
    WHERE p.id = ?
");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$data = mysqli_stmt_get_result($stmt);
$pengaduan = mysqli_fetch_assoc($data);

if (!$pengaduan) {
    echo "Data tidak ditemukan";
    exit;
}

// Format tanggal
$tanggal_dibuat = date('d M Y H:i', strtotime($pengaduan['created_at']));
$tanggal_diupdate = !empty($pengaduan['updated_at']) ? 
    date('d M Y H:i', strtotime($pengaduan['updated_at'])) : 
    'Belum ada update';

// Path untuk bukti file
$bukti_path = '';
$bukti_full_path = '';
if (!empty($pengaduan['bukti'])) {
    $base_url = ($_SERVER['SERVER_NAME'] == 'localhost') ? 
                'http://localhost/Sistem_Informasi_Desa/' : 
                'https://' . $_SERVER['SERVER_NAME'] . '/';
    
    $possible_paths = [
        "../../uploads/pengaduan/" . $pengaduan['bukti'],
        "../../uploads/" . $pengaduan['bukti'],
        "../../uploads/pengaduan/bukti/" . $pengaduan['bukti'],
        "../../uploads/bukti_pengaduan/" . $pengaduan['bukti'],
        "../uploads/pengaduan/" . $pengaduan['bukti'],
        "uploads/pengaduan/" . $pengaduan['bukti']
    ];
    
    foreach ($possible_paths as $path) {
        if (file_exists($path)) {
            $bukti_full_path = $path;
            
            if (strpos($path, '../../') === 0) {
                $bukti_path = $base_url . 'uploads/pengaduan/' . $pengaduan['bukti'];
            } elseif (strpos($path, '../') === 0) {
                $bukti_path = $base_url . 'uploads/pengaduan/' . $pengaduan['bukti'];
            } else {
                $bukti_path = $base_url . $path;
            }
            break;
        }
    }
    
    if (empty($bukti_path)) {
        $bukti_path = $base_url . 'uploads/pengaduan/' . $pengaduan['bukti'];
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Pengaduan - Admin Desa</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f5f7fa;
            color: #333;
            line-height: 1.6;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .header {
            background: linear-gradient(135deg, #2e8b57 0%, #3cb371 100%);
            color: white;
            padding: 25px 30px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 5px 15px rgba(46, 139, 87, 0.2);
        }

        .header h1 {
            font-size: 28px;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .header p {
            opacity: 0.9;
            font-size: 16px;
            margin-bottom: 20px;
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .back-link:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: translateY(-2px);
        }

        .content {
            display: flex;
            flex-direction: column;
            gap: 25px;
        }

        /* Complaint Header */
        .complaint-header {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 3px 15px rgba(0, 0, 0, 0.08);
            border-left: 5px solid #2e8b57;
        }

        .complaint-id {
            color: #666;
            font-size: 14px;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .complaint-title {
            font-size: 22px;
            font-weight: 600;
            color: #2e8b57;
            margin-bottom: 15px;
        }

        .status-badge {
            display: inline-flex;
            align-items: center;
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 500;
            margin-bottom: 20px;
        }

        .status-terkirim {
            background: #fff3cd;
            color: #856404;
            border: 1px solid #ffeaa7;
        }

        .status-diproses {
            background: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }

        .status-selesai {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        /* Info Grid */
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 25px;
        }

        .info-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 3px 15px rgba(0, 0, 0, 0.08);
            transition: transform 0.3s ease;
        }

        .info-card:hover {
            transform: translateY(-5px);
        }

        .info-card h3 {
            color: #2e8b57;
            margin-bottom: 20px;
            padding-bottom: 12px;
            border-bottom: 2px solid #f0f0f0;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .info-item {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid #f5f5f5;
        }

        .info-item:last-child {
            border-bottom: none;
        }

        .info-label {
            color: #666;
            font-weight: 500;
        }

        .info-value {
            font-weight: 600;
            color: #333;
            text-align: right;
            max-width: 60%;
        }

        /* Message Card */
        .message-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 3px 15px rgba(0, 0, 0, 0.08);
        }

        .message-card h3 {
            color: #2e8b57;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .message-content {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            border-left: 4px solid #2e8b57;
            line-height: 1.8;
            white-space: pre-line;
        }

        /* Evidence Section */
        .evidence-section {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 3px 15px rgba(0, 0, 0, 0.08);
        }

        .evidence-section h3 {
            color: #2e8b57;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .evidence-preview {
            background: #f8f9fa;
            border-radius: 12px;
            padding: 20px;
            border: 2px dashed #dee2e6;
        }

        .evidence-img {
            max-width: 100%;
            max-height: 300px;
            border-radius: 8px;
            cursor: pointer;
            transition: transform 0.3s ease;
            display: block;
            margin: 0 auto 20px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
        }

        .evidence-img:hover {
            transform: scale(1.02);
        }

        .evidence-actions {
            display: flex;
            gap: 15px;
            margin-bottom: 15px;
            flex-wrap: wrap;
        }

        .evidence-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            background: #2e8b57;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .evidence-link:hover {
            background: #256e46;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(46, 139, 87, 0.3);
        }

        .evidence-download {
            background: #6c757d;
        }

        .evidence-download:hover {
            background: #545b62;
            box-shadow: 0 4px 12px rgba(108, 117, 125, 0.3);
        }

        .file-info {
            background: white;
            padding: 12px 15px;
            border-radius: 8px;
            border: 1px solid #e9ecef;
            display: flex;
            align-items: center;
            gap: 10px;
            color: #666;
            font-size: 14px;
        }

        .no-evidence {
            text-align: center;
            padding: 40px 20px;
            color: #999;
        }

        /* Status Form */
        .status-form-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 3px 15px rgba(0, 0, 0, 0.08);
            margin-top: 10px;
        }

        .status-form-card h3 {
            color: #2e8b57;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            margin-bottom: 15px;
            color: #333;
            font-weight: 600;
            font-size: 16px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .status-options {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }

        .status-option {
            position: relative;
            cursor: pointer;
        }

        .status-option input[type="radio"] {
            display: none;
        }

        .option-content {
            background: white;
            border: 2px solid #e0e0e0;
            border-radius: 12px;
            padding: 20px;
            text-align: center;
            transition: all 0.3s ease;
            height: 100%;
        }

        .status-option input[type="radio"]:checked + .option-content {
            border-color: #2e8b57;
            background: #f0f9f4;
            box-shadow: 0 5px 15px rgba(46, 139, 87, 0.1);
        }

        .option-content i {
            font-size: 32px;
            margin-bottom: 10px;
            display: block;
        }

        .option-content span {
            display: block;
            font-weight: 600;
            color: #333;
            margin-bottom: 5px;
        }

        .option-content small {
            color: #666;
            display: block;
        }

        .button-group {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            padding-top: 20px;
            border-top: 1px solid #f0f0f0;
        }

        .btn {
            padding: 12px 25px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
        }

        .btn-primary {
            background: #2e8b57;
            color: white;
        }

        .btn-primary:hover {
            background: #256e46;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(46, 139, 87, 0.3);
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background: #545b62;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(108, 117, 125, 0.3);
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .modal-content {
            position: relative;
            max-width: 90%;
            max-height: 90%;
        }

        .modal-img {
            max-width: 100%;
            max-height: 80vh;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
        }

        .modal-close {
            position: absolute;
            top: -40px;
            right: 0;
            background: white;
            color: #333;
            border: none;
            width: 36px;
            height: 36px;
            border-radius: 50%;
            font-size: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .modal-close:hover {
            background: #f8f9fa;
            transform: rotate(90deg);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .container {
                padding: 15px;
            }
            
            .info-grid {
                grid-template-columns: 1fr;
            }
            
            .status-options {
                grid-template-columns: 1fr;
            }
            
            .button-group {
                flex-direction: column;
            }
            
            .btn {
                width: 100%;
                justify-content: center;
            }
            
            .evidence-actions {
                flex-direction: column;
            }
            
            .evidence-link {
                justify-content: center;
            }
        }

        @media (max-width: 480px) {
            .header {
                padding: 20px;
            }
            
            .header h1 {
                font-size: 22px;
            }
            
            .info-item {
                flex-direction: column;
                gap: 5px;
            }
            
            .info-value {
                max-width: 100%;
                text-align: left;
            }
        }
    </style>
</head>
<body>

<!-- Modal untuk preview gambar -->
<div id="imageModal" class="modal">
    <div class="modal-content">
        <button class="modal-close" onclick="closeModal()">&times;</button>
        <img id="modalImage" class="modal-img" src="" alt="Preview Bukti">
    </div>
</div>

<div class="container">
    <div class="header">
        <h1>
            <i class="fas fa-file-alt"></i>
            Detail Pengaduan Warga
        </h1>
        <p>Tinjau dan kelola pengaduan dari masyarakat desa</p>
        <a href="index.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Kembali ke Daftar
        </a>
    </div>
    
    <div class="content">
        <!-- Complaint Header -->
        <div class="complaint-header">
            <div class="complaint-id">
                <i class="fas fa-hashtag"></i>
                ID Pengaduan: #<?= htmlspecialchars($pengaduan['id']) ?>
            </div>
            <div class="complaint-title">
                <?= htmlspecialchars($pengaduan['kategori']) ?>
            </div>
            <div class="status-badge status-<?= $pengaduan['status'] ?>">
                <i class="fas fa-circle" style="font-size: 10px; margin-right: 8px;"></i>
                <?= ucfirst($pengaduan['status']) ?>
            </div>
            <div style="display: flex; gap: 20px; color: #666; font-size: 14px; flex-wrap: wrap;">
                <div>
                    <i class="far fa-calendar-plus"></i>
                    Dibuat: <?= $tanggal_dibuat ?>
                </div>
                <div>
                    <i class="far fa-calendar-check"></i>
                    Diupdate: <?= $tanggal_diupdate ?>
                </div>
            </div>
        </div>

        <!-- Info Grid -->
        <div class="info-grid">
            <div class="info-card">
                <h3><i class="fas fa-user-circle"></i> Informasi Pelapor</h3>
                <div class="info-item">
                    <span class="info-label">Nama Lengkap</span>
                    <span class="info-value"><?= htmlspecialchars($pengaduan['nama_lengkap']) ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label">Username</span>
                    <span class="info-value"><?= htmlspecialchars($pengaduan['username']) ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label">No. Telepon</span>
                    <span class="info-value"><?= htmlspecialchars($pengaduan['no_hp']) ?></span>
                </div>
            </div>
            
            <div class="info-card">
                <h3><i class="fas fa-info-circle"></i> Informasi Pengaduan</h3>
                <div class="info-item">
                    <span class="info-label">Kategori</span>
                    <span class="info-value"><?= htmlspecialchars($pengaduan['kategori']) ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label">Lokasi</span>
                    <span class="info-value"><?= htmlspecialchars($pengaduan['lokasi']) ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label">Status Saat Ini</span>
                    <span class="info-value">
                        <span class="status-badge status-<?= $pengaduan['status'] ?>" style="font-size: 12px; padding: 4px 10px;">
                            <?= ucfirst($pengaduan['status']) ?>
                        </span>
                    </span>
                </div>
            </div>
        </div>

        <!-- Message Content -->
        <div class="message-card">
            <h3><i class="fas fa-comment-dots"></i> Isi Pengaduan</h3>
            <div class="message-content">
                <?= nl2br(htmlspecialchars($pengaduan['pesan'])) ?>
            </div>
        </div>

        <!-- Evidence Section -->
        <div class="evidence-section">
            <h3><i class="fas fa-image"></i> Bukti Pengaduan</h3>
            <?php if (!empty($pengaduan['bukti'])): 
                $file_extension = strtolower(pathinfo($pengaduan['bukti'], PATHINFO_EXTENSION));
                $image_extensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'];
                $is_image = in_array($file_extension, $image_extensions);
                
                $img_src = '';
                if ($is_image && !empty($bukti_full_path)) {
                    if (strpos($bukti_full_path, '../../') === 0) {
                        $img_src = '../' . substr($bukti_full_path, 6);
                    } elseif (strpos($bukti_full_path, '../') === 0) {
                        $img_src = $bukti_full_path;
                    } else {
                        $img_src = $bukti_full_path;
                    }
                }
            ?>
                <div class="evidence-preview">
                    <?php if ($is_image && !empty($img_src) && file_exists(str_replace('../', '', $img_src))): ?>
                        <img src="<?= $img_src ?>" 
                             alt="Bukti Pengaduan" 
                             class="evidence-img"
                             onclick="openModal('<?= $bukti_path ?>')"
                             onerror="this.style.display='none'; document.getElementById('viewLink').style.display='flex';">
                    <?php endif; ?>
                    
                    <div class="evidence-actions">
                        <a href="<?= $bukti_path ?>" 
                           target="_blank" 
                           class="evidence-link"
                           id="viewLink">
                            <i class="fas fa-external-link-alt"></i>
                            Lihat File
                            <span style="font-size: 12px; margin-left: 8px; opacity: 0.8;">
                                (<?= strtoupper($file_extension) ?>)
                            </span>
                        </a>
                        
                        <a href="<?= $bukti_path ?>" 
                           download="<?= htmlspecialchars($pengaduan['bukti']) ?>"
                           class="evidence-link evidence-download">
                            <i class="fas fa-download"></i>
                            Download File
                        </a>
                    </div>
                    
                    <div class="file-info">
                        <i class="fas fa-info-circle"></i>
                        <span>
                            File: <strong><?= htmlspecialchars($pengaduan['bukti']) ?></strong> 
                            <?php if (!empty($bukti_full_path) && file_exists($bukti_full_path)): ?>
                            • Ukuran: <?= formatFileSize($bukti_full_path) ?>
                            <?php endif; ?>
                            • Tipe: <?= strtoupper($file_extension) ?>
                        </span>
                    </div>
                </div>
            <?php else: ?>
                <div class="no-evidence">
                    <i class="far fa-image" style="font-size: 48px; color: #ddd; margin-bottom: 15px;"></i>
                    <p>Tidak ada bukti yang dilampirkan</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Status Update Form -->
        <div class="status-form-card">
            <h3><i class="fas fa-sync-alt"></i> Perbarui Status Pengaduan</h3>
            
            <form method="post" action="update_status.php" id="statusForm">
                <input type="hidden" name="id" value="<?= $pengaduan['id'] ?>">
                
                <div class="form-group">
                    <label><i class="fas fa-flag"></i> Pilih Status Baru</label>
                    
                    <div class="status-options">
                        <label class="status-option">
                            <input type="radio" name="status" value="terkirim" 
                                   <?= $pengaduan['status']=='terkirim'?'checked':'' ?>>
                            <div class="option-content">
                                <i class="fas fa-paper-plane" style="color: #ffc107;"></i>
                                <span>Terkirim</span>
                                <small>Pengaduan baru diterima</small>
                            </div>
                        </label>
                        
                        <label class="status-option">
                            <input type="radio" name="status" value="diproses" 
                                   <?= $pengaduan['status']=='diproses'?'checked':'' ?>>
                            <div class="option-content">
                                <i class="fas fa-cogs" style="color: #17a2b8;"></i>
                                <span>Diproses</span>
                                <small>Sedang ditangani</small>
                            </div>
                        </label>
                        
                        <label class="status-option">
                            <input type="radio" name="status" value="selesai" 
                                   <?= $pengaduan['status']=='selesai'?'checked':'' ?>>
                            <div class="option-content">
                                <i class="fas fa-check-circle" style="color: #28a745;"></i>
                                <span>Selesai</span>
                                <small>Sudah diselesaikan</small>
                            </div>
                        </label>
                    </div>
                </div>
                
                <div class="button-group">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i>
                        Simpan Perubahan Status
                    </button>
                    <a href="index.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i>
                        Kembali ke Daftar
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    // Fungsi untuk modal gambar
    function openModal(imageSrc) {
        const modal = document.getElementById('imageModal');
        const modalImg = document.getElementById('modalImage');
        
        modalImg.src = imageSrc;
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }
    
    function closeModal() {
        const modal = document.getElementById('imageModal');
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
    
    // Tutup modal dengan ESC
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeModal();
        }
    });
    
    // Tutup modal dengan klik di luar gambar
    document.getElementById('imageModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeModal();
        }
    });

    // Validasi form
    document.getElementById('statusForm').addEventListener('submit', function(e) {
        const selectedStatus = document.querySelector('input[name="status"]:checked');
        
        if (!selectedStatus) {
            e.preventDefault();
            alert('Silakan pilih status terlebih dahulu!');
            return false;
        }
        
        const currentStatus = "<?= $pengaduan['status'] ?>";
        const newStatus = selectedStatus.value;
        
        if (currentStatus === newStatus) {
            if (!confirm('Status tidak berubah. Apakah Anda yakin ingin melanjutkan?')) {
                e.preventDefault();
                return false;
            }
        } else {
            const statusNames = {
                'terkirim': 'Terkirim',
                'diproses': 'Diproses', 
                'selesai': 'Selesai'
            };
            
            if (!confirm(`Ubah status pengaduan dari "${statusNames[currentStatus]}" menjadi "${statusNames[newStatus]}"?`)) {
                e.preventDefault();
                return false;
            }
        }
    });

    // Auto-handle gambar error
    document.addEventListener('DOMContentLoaded', function() {
        const evidenceImg = document.querySelector('.evidence-img');
        const viewLink = document.getElementById('viewLink');
        
        if (evidenceImg) {
            evidenceImg.addEventListener('error', function() {
                this.style.display = 'none';
                if (viewLink) {
                    viewLink.style.display = 'flex';
                }
            });
        }
        
        // Inisialisasi status options yang terpilih
        document.querySelectorAll('.status-option').forEach(option => {
            if (option.querySelector('input[type="radio"]').checked) {
                option.querySelector('.option-content').style.borderColor = '#2e8b57';
                option.querySelector('.option-content').style.background = '#f0f9f4';
                option.querySelector('.option-content').style.boxShadow = '0 5px 15px rgba(46, 139, 87, 0.1)';
            }
        });
    });
</script>

</body>
</html>

<?php
// Fungsi helper untuk format ukuran file
function formatFileSize($path) {
    if (!file_exists($path)) {
        return 'Unknown';
    }
    
    $bytes = filesize($path);
    $units = ['B', 'KB', 'MB', 'GB'];
    
    for ($i = 0; $bytes >= 1024 && $i < count($units) - 1; $i++) {
        $bytes /= 1024;
    }
    
    return round($bytes, 2) . ' ' . $units[$i];
}
?>