<?php
session_start();
include '../../koneksi.php';

/* CEK LOGIN ADMIN */
if (!isset($_SESSION['admin'])) {
    header("Location: ../../login.php");
    exit;
}

// Query untuk data statistik
$total_pengaduan = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM pengaduan"))[0];
$pengaduan_terkirim = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM pengaduan WHERE status='terkirim'"))[0];
$pengaduan_diproses = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM pengaduan WHERE status='diproses'"))[0];
$pengaduan_selesai = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM pengaduan WHERE status='selesai'"))[0];

// Query untuk data pengaduan
$q = mysqli_query($conn, "
    SELECT p.*, u.nama_lengkap, u.no_hp 
    FROM pengaduan p
    JOIN users u ON p.user_id = u.id
    ORDER BY p.id DESC
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Pengaduan Warga - Admin Desa</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            color: #333;
        }

        .admin-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 30px;
        }

        .header-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 20px;
        }

        .page-title {
            font-size: 28px;
            font-weight: 700;
            color: #2e8b57;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .page-title i {
            background: linear-gradient(135deg, #2e8b57, #3cb371);
            padding: 12px;
            border-radius: 10px;
            color: white;
            font-size: 22px;
        }

        .action-buttons {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 12px 24px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 15px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }

        .btn-primary {
            background: linear-gradient(to right, #2e8b57, #3cb371);
            color: white;
            box-shadow: 0 4px 12px rgba(46, 139, 87, 0.2);
        }

        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 18px rgba(46, 139, 87, 0.3);
            background: linear-gradient(to right, #26734d, #2e8b57);
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background: #5a6268;
            transform: translateY(-3px);
        }

        .btn-detail {
            background: #17a2b8;
            color: white;
            padding: 8px 16px;
            font-size: 14px;
            border-radius: 6px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: all 0.2s;
        }

        .btn-detail:hover {
            background: #138496;
            transform: translateY(-2px);
            box-shadow: 0 3px 8px rgba(23, 162, 184, 0.3);
        }

        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
            border-top: 4px solid;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.12);
        }

        .stat-total { border-color: #2e8b57; }
        .stat-terkirim { border-color: #e67e22; }
        .stat-diproses { border-color: #3498db; }
        .stat-selesai { border-color: #2ecc71; }

        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 22px;
        }

        .stat-total .stat-icon { background: linear-gradient(135deg, #2e8b57, #3cb371); }
        .stat-terkirim .stat-icon { background: linear-gradient(135deg, #e67e22, #d35400); }
        .stat-diproses .stat-icon { background: linear-gradient(135deg, #3498db, #2980b9); }
        .stat-selesai .stat-icon { background: linear-gradient(135deg, #2ecc71, #27ae60); }

        .stat-number {
            font-size: 32px;
            font-weight: 700;
            color: #333;
            margin-bottom: 5px;
        }

        .stat-label {
            font-size: 14px;
            color: #6c757d;
            font-weight: 500;
        }

        .stat-percentage {
            font-size: 13px;
            padding: 3px 10px;
            border-radius: 20px;
            background: #f8f9fa;
            color: #666;
            display: inline-block;
            margin-top: 8px;
        }

        /* Table Container */
        .table-container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
            overflow: hidden;
            margin-bottom: 30px;
        }

        .table-responsive {
            overflow-x: auto;
        }

        .complaints-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1000px;
        }

        .complaints-table thead {
            background: linear-gradient(to right, #2e8b57, #3cb371);
        }

        .complaints-table th {
            padding: 18px 20px;
            color: white;
            font-weight: 600;
            text-align: left;
            font-size: 15px;
            white-space: nowrap;
        }

        .complaints-table th:first-child {
            width: 60px;
            text-align: center;
        }

        .complaints-table th:nth-child(2) {
            width: 180px;
        }

        .complaints-table th:nth-child(3) {
            width: 150px;
        }

        .complaints-table th:nth-child(4) {
            width: 120px;
        }

        .complaints-table th:nth-child(5) {
            width: 120px;
        }

        .complaints-table th:nth-child(6) {
            width: 150px;
        }

        .complaints-table th:nth-child(7) {
            width: 120px;
            text-align: center;
        }

        .complaints-table tbody tr {
            border-bottom: 1px solid #f0f0f0;
            transition: all 0.2s;
        }

        .complaints-table tbody tr:hover {
            background: #f8f9fa;
            transform: translateX(3px);
        }

        .complaints-table td {
            padding: 16px 20px;
            vertical-align: middle;
        }

        .complaints-table td:first-child {
            text-align: center;
            font-weight: 600;
            color: #2e8b57;
        }

        .user-info {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .user-name {
            font-weight: 600;
            color: #333;
            font-size: 15px;
        }

        .user-phone {
            font-size: 13px;
            color: #666;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .complaint-category {
            font-weight: 500;
            color: #333;
            font-size: 14px;
        }

        .complaint-location {
            font-size: 13px;
            color: #666;
            margin-top: 3px;
        }

        .complaint-date {
            font-size: 14px;
            color: #333;
            font-weight: 500;
        }

        .complaint-time {
            font-size: 12px;
            color: #6c757d;
            margin-top: 3px;
        }

        /* Status Badges */
        .status-badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-align: center;
            min-width: 80px;
        }

        .status-terkirim {
            background: #fff3cd;
            color: #856404;
            border: 1px solid #ffeaa7;
        }

        .status-diproses {
            background: #cce5ff;
            color: #004085;
            border: 1px solid #b8daff;
        }

        .status-selesai {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .action-buttons-cell {
            display: flex;
            justify-content: center;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #6c757d;
        }

        .empty-state i {
            font-size: 48px;
            color: #ddd;
            margin-bottom: 15px;
        }

        .empty-state p {
            font-size: 16px;
            margin-bottom: 20px;
        }

        /* Back Button */
        .back-dashboard {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: #2e8b57;
            text-decoration: none;
            font-weight: 600;
            padding: 12px 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);
            transition: all 0.3s;
        }

        .back-dashboard:hover {
            background: #f8f9fa;
            transform: translateX(-5px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        /* Filter Section */
        .filter-section {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
        }

        .filter-group {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .filter-label {
            font-size: 14px;
            color: #666;
            font-weight: 500;
        }

        .filter-select {
            padding: 10px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-family: inherit;
            font-size: 14px;
            background: white;
            cursor: pointer;
            transition: all 0.3s;
        }

        .filter-select:focus {
            outline: none;
            border-color: #2e8b57;
            box-shadow: 0 0 0 3px rgba(46, 139, 87, 0.1);
        }

        @media (max-width: 1024px) {
            .admin-container {
                padding: 20px;
            }
            
            .header-section {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .action-buttons {
                width: 100%;
            }
            
            .btn {
                flex: 1;
                justify-content: center;
            }
            
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .filter-section {
                flex-direction: column;
                align-items: stretch;
            }
            
            .filter-group {
                width: 100%;
            }
            
            .filter-select {
                flex: 1;
            }
        }

        @media (max-width: 768px) {
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .complaints-table td, .complaints-table th {
                padding: 12px 15px;
            }
            
            .user-info {
                min-width: 150px;
            }
        }
    </style>
</head>
<body>

<div class="admin-container">
    <!-- Header Section -->
    <div class="header-section">
        <div>
            <h1 class="page-title">
                <i class="fas fa-comments"></i>
                Kelola Pengaduan Warga
            </h1>
            <p style="color: #6c757d; margin-top: 5px;">Kelola dan tanggapi pengaduan dari masyarakat desa</p>
        </div>
        
        <div class="action-buttons">
            <a href="../dashboard.php" class="btn btn-secondary">
                <i class="fas fa-tachometer-alt"></i>
                Dashboard
            </a>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="stats-grid">
        <div class="stat-card stat-total">
            <div class="stat-header">
                <div>
                    <div class="stat-number"><?= $total_pengaduan ?></div>
                    <div class="stat-label">Total Pengaduan</div>
                </div>
                <div class="stat-icon">
                    <i class="fas fa-inbox"></i>
                </div>
            </div>
            <div class="stat-percentage">
                <i class="fas fa-chart-line"></i> Semua periode
            </div>
        </div>
        
        <div class="stat-card stat-terkirim">
            <div class="stat-header">
                <div>
                    <div class="stat-number"><?= $pengaduan_terkirim ?></div>
                    <div class="stat-label">Terkirim</div>
                </div>
                <div class="stat-icon">
                    <i class="fas fa-paper-plane"></i>
                </div>
            </div>
            <div class="stat-percentage">
                <?= $total_pengaduan > 0 ? round(($pengaduan_terkirim / $total_pengaduan) * 100, 1) : 0 ?>% dari total
            </div>
        </div>
        
        <div class="stat-card stat-diproses">
            <div class="stat-header">
                <div>
                    <div class="stat-number"><?= $pengaduan_diproses ?></div>
                    <div class="stat-label">Diproses</div>
                </div>
                <div class="stat-icon">
                    <i class="fas fa-cogs"></i>
                </div>
            </div>
            <div class="stat-percentage">
                <?= $total_pengaduan > 0 ? round(($pengaduan_diproses / $total_pengaduan) * 100, 1) : 0 ?>% dari total
            </div>
        </div>
        
        <div class="stat-card stat-selesai">
            <div class="stat-header">
                <div>
                    <div class="stat-number"><?= $pengaduan_selesai ?></div>
                    <div class="stat-label">Selesai</div>
                </div>
                <div class="stat-icon">
                    <i class="fas fa-check-circle"></i>
                </div>
            </div>
            <div class="stat-percentage">
                <?= $total_pengaduan > 0 ? round(($pengaduan_selesai / $total_pengaduan) * 100, 1) : 0 ?>% dari total
            </div>
        </div>
    </div>

    <!-- Filter Section -->
    <div class="filter-section">
        <div class="filter-group">
            <span class="filter-label">
                <i class="fas fa-filter"></i> Filter Status:
            </span>
            <select class="filter-select" id="statusFilter">
                <option value="all">Semua Status</option>
                <option value="terkirim">Terkirim</option>
                <option value="diproses">Diproses</option>
                <option value="selesai">Selesai</option>
            </select>
        </div>
        
        <div class="filter-group">
            <span class="filter-label">
                <i class="fas fa-sort"></i> Urutkan:
            </span>
            <select class="filter-select" id="sortFilter">
                <option value="newest">Terbaru</option>
                <option value="oldest">Terlama</option>
                <option value="status">Status</option>
            </select>
        </div>
    </div>

    <!-- Complaints Table -->
    <div class="table-container">
        <div class="table-responsive">
            <table class="complaints-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Pelapor</th>
                        <th>Kategori</th>
                        <th>Lokasi</th>
                        <th>Tanggal</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($q && mysqli_num_rows($q) > 0): 
                        $no = 1;
                        while ($row = mysqli_fetch_assoc($q)): 
                            $tanggal = date('d M Y', strtotime($row['tanggal']));
                            $waktu = date('H:i', strtotime($row['tanggal']));
                    ?>
                    <tr class="complaint-row" data-status="<?= $row['status'] ?>">
                        <td><?= $no++ ?></td>
                        <td>
                            <div class="user-info">
                                <div class="user-name">
                                    <?= htmlspecialchars($row['nama_lengkap']) ?>
                                </div>
                                <div class="user-phone">
                                    <i class="fas fa-phone-alt"></i>
                                    <?= htmlspecialchars($row['no_hp']) ?>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="complaint-category">
                                <?= htmlspecialchars($row['kategori']) ?>
                            </div>
                        </td>
                        <td>
                            <div class="complaint-location">
                                <?= htmlspecialchars($row['lokasi']) ?>
                            </div>
                        </td>
                        <td>
                            <div class="complaint-date"><?= $tanggal ?></div>
                            <div class="complaint-time"><?= $waktu ?> WIB</div>
                        </td>
                        <td>
                            <span class="status-badge status-<?= $row['status'] ?>">
                                <?= ucfirst($row['status']) ?>
                            </span>
                        </td>
                        <td class="action-buttons-cell">
                            <a href="detail.php?id=<?= $row['id']; ?>" class="btn-detail">
                                <i class="fas fa-eye"></i> Detail
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                    
                    <?php else: ?>
                    <tr>
                        <td colspan="7">
                            <div class="empty-state">
                                <i class="far fa-comments"></i>
                                <p>Belum ada pengaduan yang tercatat</p>
                            </div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Back to Dashboard -->
    <a href="../dashboard.php" class="back-dashboard">
        <i class="fas fa-arrow-left"></i>
        Kembali ke Dashboard Admin
    </a>
</div>

<script>
    // Filter data berdasarkan status
    document.getElementById('statusFilter').addEventListener('change', function() {
        const selectedStatus = this.value;
        const rows = document.querySelectorAll('.complaint-row');
        
        rows.forEach(row => {
            if (selectedStatus === 'all' || row.getAttribute('data-status') === selectedStatus) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    });

    // Sort data
    document.getElementById('sortFilter').addEventListener('change', function() {
        const sortBy = this.value;
        const tableBody = document.querySelector('.complaints-table tbody');
        const rows = Array.from(document.querySelectorAll('.complaint-row'));
        
        rows.sort((a, b) => {
            switch(sortBy) {
                case 'newest':
                    return b.querySelector('.complaint-date').textContent.localeCompare(
                        a.querySelector('.complaint-date').textContent
                    );
                case 'oldest':
                    return a.querySelector('.complaint-date').textContent.localeCompare(
                        b.querySelector('.complaint-date').textContent
                    );
                case 'status':
                    const statusOrder = { 'terkirim': 1, 'diproses': 2, 'selesai': 3 };
                    const statusA = a.getAttribute('data-status');
                    const statusB = b.getAttribute('data-status');
                    return statusOrder[statusA] - statusOrder[statusB];
                default:
                    return 0;
            }
        });
        
        // Update nomor urut setelah sorting
        rows.forEach((row, index) => {
            tableBody.appendChild(row);
            const noCell = row.querySelector('td:first-child');
            if (noCell) noCell.textContent = index + 1;
        });
    });

    // Efek hover untuk baris tabel
    document.querySelectorAll('.complaint-row').forEach(row => {
        row.addEventListener('mouseenter', function() {
            this.style.boxShadow = '0 3px 10px rgba(0,0,0,0.05)';
        });
        
        row.addEventListener('mouseleave', function() {
            this.style.boxShadow = 'none';
        });
    });

    // Efek hover untuk stat cards
    document.querySelectorAll('.stat-card').forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });

    // Efek hover untuk semua tombol
    document.querySelectorAll('.btn').forEach(btn => {
        btn.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-3px)';
        });
        
        btn.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });

    // Update stat cards warna berdasarkan jumlah
    document.addEventListener('DOMContentLoaded', function() {
        const total = <?= $total_pengaduan ?>;
        const newComplaints = <?= $pengaduan_terkirim ?>;
        
        // Highlight jika ada pengaduan baru
        if (newComplaints > 0) {
            const newCard = document.querySelector('.stat-terkirim');
            if (newCard) {
                newCard.style.animation = 'pulse 2s infinite';
                newCard.style.setProperty('--pulse-color', '#e67e22');
            }
        }
    });

    // CSS animation untuk pulsing effect
    const style = document.createElement('style');
    style.textContent = `
        @keyframes pulse {
            0% { box-shadow: 0 5px 15px rgba(230, 126, 34, 0.2); }
            50% { box-shadow: 0 5px 20px rgba(230, 126, 34, 0.4); }
            100% { box-shadow: 0 5px 15px rgba(230, 126, 34, 0.2); }
        }
    `;
    document.head.appendChild(style);
</script>

</body>
</html>