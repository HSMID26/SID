<?php
session_start();
include '../../koneksi.php';

if (!isset($_SESSION['login'])) {
    header("Location: ../../login.php");
    exit;
}

$id = $_GET['id'] ?? null;
if (!$id) {
    header("Location: index.php");
    exit;
}

// Ambil data berita
$data = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT * FROM berita WHERE id='$id'")
);

$error = "";

if (isset($_POST['update'])) {
    $judul = trim($_POST['judul']);
    $isi   = trim($_POST['isi']);

    if ($judul == "" || $isi == "") {
        $error = "Data tidak boleh kosong!";
    } else {
        $stmt = mysqli_prepare($conn,
            "UPDATE berita SET judul=?, isi=? WHERE id=?"
        );
        mysqli_stmt_bind_param($stmt, "ssi", $judul, $isi, $id);

        if (mysqli_stmt_execute($stmt)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Gagal update berita!";
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Berita - Admin Desa</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 900px;
            margin: 40px auto;
            background: white;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        
        .header {
            background: linear-gradient(to right, #2e8b57, #3cb371);
            color: white;
            padding: 25px 30px;
            position: relative;
        }
        
        .header h2 {
            font-size: 24px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .header h2 i {
            font-size: 22px;
        }
        
        .back-link {
            position: absolute;
            right: 30px;
            top: 30px;
            color: white;
            text-decoration: none;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 6px;
            background: rgba(255, 255, 255, 0.2);
            padding: 8px 15px;
            border-radius: 30px;
            transition: all 0.3s;
        }
        
        .back-link:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: translateY(-2px);
        }
        
        .content {
            padding: 40px;
        }
        
        .error-box {
            background: #ffeaea;
            border-left: 4px solid #ff5252;
            color: #d32f2f;
            padding: 15px 20px;
            margin-bottom: 25px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: fadeIn 0.3s ease;
        }
        
        .error-box i {
            font-size: 18px;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
            font-size: 15px;
        }
        
        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 14px 16px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 15px;
            transition: all 0.3s;
            background: #fafafa;
        }
        
        .form-group input:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #2e8b57;
            background: white;
            box-shadow: 0 0 0 3px rgba(46, 139, 87, 0.1);
        }
        
        .form-group textarea {
            resize: vertical;
            min-height: 200px;
            line-height: 1.6;
        }
        
        .button-group {
            display: flex;
            gap: 15px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }
        
        .btn {
            padding: 14px 28px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 15px;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            border: none;
            text-decoration: none;
        }
        
        .btn-primary {
            background: #2e8b57;
            color: white;
            flex: 1;
        }
        
        .btn-primary:hover {
            background: #26734d;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(46, 139, 87, 0.3);
        }
        
        .btn-secondary {
            background: #f5f5f5;
            color: #666;
            border: 1px solid #ddd;
        }
        
        .btn-secondary:hover {
            background: #e9e9e9;
            transform: translateY(-2px);
        }
        
        .char-count {
            text-align: right;
            font-size: 13px;
            color: #777;
            margin-top: 5px;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        @media (max-width: 768px) {
            .container {
                margin: 20px auto;
                border-radius: 12px;
            }
            
            .content {
                padding: 25px;
            }
            
            .header {
                padding: 20px;
            }
            
            .button-group {
                flex-direction: column;
            }
            
            .back-link {
                position: relative;
                right: auto;
                top: auto;
                display: inline-flex;
                margin-top: 10px;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <h2><i class="fas fa-newspaper"></i> Edit Berita</h2>
        <a href="index.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Kembali ke Daftar
        </a>
    </div>
    
    <div class="content">
        <?php if ($error) { ?>
            <div class="error-box">
                <i class="fas fa-exclamation-circle"></i>
                <span><?= htmlspecialchars($error) ?></span>
            </div>
        <?php } ?>

        <form method="post" id="editForm">
            <div class="form-group">
                <label for="judul"><i class="fas fa-heading"></i> Judul Berita</label>
                <input type="text" id="judul" name="judul" value="<?= htmlspecialchars($data['judul'] ?? '') ?>" 
                       placeholder="Masukkan judul berita" required>
                <div class="char-count" id="judulCount">0/150 karakter</div>
            </div>
            
            <div class="form-group">
                <label for="isi"><i class="fas fa-align-left"></i> Isi Berita</label>
                <textarea id="isi" name="isi" placeholder="Tulis isi berita di sini..." required><?= htmlspecialchars($data['isi'] ?? '') ?></textarea>
                <div class="char-count" id="isiCount">0 karakter</div>
            </div>
            
            <div class="button-group">
                <button type="submit" name="update" class="btn btn-primary">
                    <i class="fas fa-save"></i> Simpan Perubahan
                </button>
                <a href="index.php" class="btn btn-secondary">
                    <i class="fas fa-times"></i> Batal
                </a>
            </div>
        </form>
    </div>
</div>

<script>
    // Fungsi untuk menghitung karakter
    function updateCharCount(element, counterId, maxLength = null) {
        const count = element.value.length;
        const counter = document.getElementById(counterId);
        
        if (maxLength) {
            counter.textContent = `${count}/${maxLength} karakter`;
            if (count > maxLength * 0.9) {
                counter.style.color = '#ff5252';
            } else {
                counter.style.color = '#777';
            }
        } else {
            counter.textContent = `${count} karakter`;
        }
    }
    
    // Inisialisasi untuk judul
    const judulInput = document.getElementById('judul');
    const isiTextarea = document.getElementById('isi');
    
    judulInput.addEventListener('input', function() {
        updateCharCount(this, 'judulCount', 150);
    });
    
    isiTextarea.addEventListener('input', function() {
        updateCharCount(this, 'isiCount');
    });
    
    // Set nilai awal
    updateCharCount(judulInput, 'judulCount', 150);
    updateCharCount(isiTextarea, 'isiCount');
    
    // Validasi form sebelum submit
    document.getElementById('editForm').addEventListener('submit', function(e) {
        const judul = judulInput.value.trim();
        const isi = isiTextarea.value.trim();
        
        if (judul === '' || isi === '') {
            e.preventDefault();
            alert('Judul dan isi berita harus diisi!');
            return false;
        }
        
        if (judul.length > 150) {
            e.preventDefault();
            alert('Judul tidak boleh lebih dari 150 karakter!');
            return false;
        }
    });
</script>

</body>
</html>