<?php
session_start();
include '../../koneksi.php';

/* ===============================
   PROTEKSI LOGIN ADMIN
   WAJIB session admin
================================ */
if (!isset($_SESSION['admin'])) {
    header("Location: ../../login.php");
    exit;
}

// Ambil data berita
$query = mysqli_query($conn, "SELECT * FROM berita ORDER BY tanggal DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Berita - Admin Desa</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            color: #333;
        }

        .admin-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 30px;
        }

        .header-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 20px;
        }

        .page-title {
            font-size: 28px;
            font-weight: 700;
            color: #2e8b57;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .page-title i {
            background: linear-gradient(135deg, #2e8b57, #3cb371);
            padding: 12px;
            border-radius: 10px;
            color: white;
            font-size: 22px;
        }

        .action-buttons {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 12px 24px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 15px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }

        .btn-primary {
            background: linear-gradient(to right, #2e8b57, #3cb371);
            color: white;
            box-shadow: 0 4px 12px rgba(46, 139, 87, 0.2);
        }

        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 18px rgba(46, 139, 87, 0.3);
            background: linear-gradient(to right, #26734d, #2e8b57);
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background: #5a6268;
            transform: translateY(-3px);
        }

        .btn-danger {
            background: #dc3545;
            color: white;
            padding: 8px 16px;
            font-size: 14px;
        }

        .btn-danger:hover {
            background: #c82333;
            transform: translateY(-2px);
        }

        .btn-edit {
            background: #17a2b8;
            color: white;
            padding: 8px 16px;
            font-size: 14px;
        }

        .btn-edit:hover {
            background: #138496;
            transform: translateY(-2px);
        }

        .news-table-container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
            overflow: hidden;
            margin-bottom: 30px;
        }

        .table-responsive {
            overflow-x: auto;
        }

        .news-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 800px;
        }

        .news-table thead {
            background: linear-gradient(to right, #2e8b57, #3cb371);
        }

        .news-table th {
            padding: 18px 20px;
            color: white;
            font-weight: 600;
            text-align: left;
            font-size: 15px;
            white-space: nowrap;
        }

        .news-table th:first-child {
            border-radius: 12px 0 0 0;
        }

        .news-table th:last-child {
            border-radius: 0 12px 0 0;
        }

        .news-table tbody tr {
            border-bottom: 1px solid #f0f0f0;
            transition: all 0.2s;
        }

        .news-table tbody tr:hover {
            background: #f8f9fa;
            transform: translateX(5px);
        }

        .news-table td {
            padding: 16px 20px;
            vertical-align: middle;
        }

        .news-table td:first-child {
            font-weight: 600;
            color: #2e8b57;
        }

        .news-title {
            font-weight: 600;
            color: #333;
            max-width: 400px;
            line-height: 1.4;
        }

        .news-date {
            color: #6c757d;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .news-date i {
            color: #2e8b57;
        }

        .action-buttons-cell {
            display: flex;
            gap: 8px;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #6c757d;
        }

        .empty-state i {
            font-size: 48px;
            color: #ddd;
            margin-bottom: 15px;
        }

        .empty-state p {
            font-size: 16px;
            margin-bottom: 20px;
        }

        .back-dashboard {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: #2e8b57;
            text-decoration: none;
            font-weight: 600;
            padding: 12px 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);
            transition: all 0.3s;
        }

        .back-dashboard:hover {
            background: #f8f9fa;
            transform: translateX(-5px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .stats-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .stats-icon {
            background: linear-gradient(135deg, #2e8b57, #3cb371);
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 22px;
        }

        .stats-info h3 {
            font-size: 28px;
            color: #2e8b57;
            margin-bottom: 5px;
        }

        .stats-info p {
            color: #6c757d;
            font-size: 14px;
        }

        @media (max-width: 768px) {
            .admin-container {
                padding: 20px;
            }
            
            .header-section {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .action-buttons {
                width: 100%;
            }
            
            .btn {
                flex: 1;
                justify-content: center;
            }
            
            .news-table td, .news-table th {
                padding: 12px 15px;
            }
        }
    </style>
</head>
<body>

<div class="admin-container">
    <!-- Header Section -->
    <div class="header-section">
        <div>
            <h1 class="page-title">
                <i class="fas fa-newspaper"></i>
                Manajemen Berita
            </h1>
            <p style="color: #6c757d; margin-top: 5px;">Kelola berita dan informasi desa</p>
        </div>
        
        <div class="action-buttons">
            <a href="tambah.php" class="btn btn-primary">
                <i class="fas fa-plus-circle"></i>
                Tambah Berita Baru
            </a>
            <a href="../dashboard.php" class="btn btn-secondary">
                <i class="fas fa-tachometer-alt"></i>
                Dashboard
            </a>
        </div>
    </div>

    <!-- Stats Card -->
    <?php
    $total_berita = mysqli_num_rows($query);
    mysqli_data_seek($query, 0); // Reset pointer untuk loop nanti
    ?>
    <div class="stats-card">
        <div class="stats-icon">
            <i class="fas fa-file-alt"></i>
        </div>
        <div class="stats-info">
            <h3><?= $total_berita ?></h3>
            <p>Total Berita Tersimpan</p>
        </div>
    </div>

    <!-- News Table -->
    <div class="news-table-container">
        <div class="table-responsive">
            <table class="news-table">
                <thead>
                    <tr>
                        <th width="80">No</th>
                        <th>Judul Berita</th>
                        <th width="200">Tanggal</th>
                        <th width="180">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($query && mysqli_num_rows($query) > 0): 
                        $no = 1;
                        while ($row = mysqli_fetch_assoc($query)): 
                            $truncated_title = strlen($row['judul']) > 60 ? substr($row['judul'], 0, 57) . '...' : $row['judul'];
                    ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td>
                            <div class="news-title"><?= htmlspecialchars($truncated_title) ?></div>
                        </td>
                        <td>
                            <div class="news-date">
                                <i class="far fa-calendar-alt"></i>
                                <?= date('d M Y', strtotime($row['tanggal'])) ?>
                            </div>
                        </td>
                        <td>
                            <div class="action-buttons-cell">
                                <a href="edit.php?id=<?= $row['id']; ?>" class="btn btn-edit">
                                    <i class="fas fa-edit"></i> Edit
                                </a>
                                <a href="hapus.php?id=<?= $row['id']; ?>" 
                                   class="btn btn-danger"
                                   onclick="return confirm('Apakah Anda yakin ingin menghapus berita ini?\n\nJudul: <?= addslashes(htmlspecialchars($row['judul'])) ?>')">
                                    <i class="fas fa-trash-alt"></i> Hapus
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                    
                    <?php else: ?>
                    <tr>
                        <td colspan="4">
                            <div class="empty-state">
                                <i class="far fa-newspaper"></i>
                                <p>Belum ada berita yang ditambahkan</p>
                                <a href="tambah.php" class="btn btn-primary">
                                    <i class="fas fa-plus-circle"></i>
                                    Tambah Berita Pertama
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Back to Dashboard -->
    <a href="../dashboard.php" class="back-dashboard">
        <i class="fas fa-arrow-left"></i>
        Kembali ke Dashboard Admin
    </a>
</div>

<script>
    // Tambahkan efek konfirmasi yang lebih baik untuk penghapusan
    document.querySelectorAll('.btn-danger').forEach(button => {
        button.addEventListener('click', function(e) {
            if (!confirm('Yakin ingin menghapus berita ini?')) {
                e.preventDefault();
            }
        });
    });

    // Efek hover untuk semua tombol
    document.querySelectorAll('.btn').forEach(btn => {
        btn.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-3px)';
        });
        
        btn.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
</script>

</body>
</html>