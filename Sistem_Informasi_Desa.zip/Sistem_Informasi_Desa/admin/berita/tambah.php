<?php
session_start();
include '../../koneksi.php';

if (!isset($_SESSION['admin'])) {
    header("Location: ../../login.php");
    exit;
}

$error = "";

if (isset($_POST['simpan'])) {
    $judul = trim($_POST['judul']);
    $isi   = trim($_POST['isi']);

    $gambar = null;

    if ($judul == "" || $isi == "") {
        $error = "Judul dan isi tidak boleh kosong!";
    } else {

        /* ===== UPLOAD GAMBAR ===== */
        if (!empty($_FILES['gambar']['name'])) {
            $allowed = ['jpg','jpeg','png'];
            $ext = strtolower(pathinfo($_FILES['gambar']['name'], PATHINFO_EXTENSION));

            if (!in_array($ext, $allowed)) {
                $error = "Format gambar harus JPG / PNG!";
            } else if ($_FILES['gambar']['size'] > 2 * 1024 * 1024) {
                $error = "Ukuran gambar maksimal 2MB!";
            } else {
                $gambar = time() . '_' . basename($_FILES['gambar']['name']);
                move_uploaded_file(
                    $_FILES['gambar']['tmp_name'],
                    "../../uploads/berita/" . $gambar
                );
            }
        }

        if ($error == "") {
            $stmt = mysqli_prepare($conn,
                "INSERT INTO berita (judul, isi, gambar, tanggal)
                 VALUES (?, ?, ?, NOW())"
            );
            mysqli_stmt_bind_param($stmt, "sss", $judul, $isi, $gambar);

            if (mysqli_stmt_execute($stmt)) {
                header("Location: index.php");
                exit;
            } else {
                $error = "Gagal menyimpan berita!";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Berita - Admin Desa</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            padding: 20px;
            color: #333;
        }

        .container {
            max-width: 800px;
            margin: 40px auto;
            background: white;
            border-radius: 16px;
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.12);
            overflow: hidden;
        }

        .header {
            background: linear-gradient(to right, #2e8b57, #3cb371);
            color: white;
            padding: 30px;
            position: relative;
        }

        .header h1 {
            font-size: 28px;
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 8px;
        }

        .header h1 i {
            background: rgba(255, 255, 255, 0.2);
            padding: 12px;
            border-radius: 10px;
            font-size: 22px;
        }

        .header p {
            opacity: 0.9;
            font-size: 15px;
            margin-left: 57px;
        }

        .back-link {
            position: absolute;
            right: 30px;
            top: 35px;
            color: white;
            text-decoration: none;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 8px;
            background: rgba(255, 255, 255, 0.15);
            padding: 10px 18px;
            border-radius: 30px;
            transition: all 0.3s;
        }

        .back-link:hover {
            background: rgba(255, 255, 255, 0.25);
            transform: translateX(-5px);
        }

        .content {
            padding: 40px;
        }

        .error-box {
            background: #ffeaea;
            border-left: 4px solid #ff5252;
            color: #d32f2f;
            padding: 16px 20px;
            margin-bottom: 30px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: fadeIn 0.3s ease;
        }

        .error-box i {
            font-size: 18px;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            margin-bottom: 10px;
            font-weight: 600;
            color: #444;
            font-size: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .form-group label i {
            color: #2e8b57;
            width: 20px;
        }

        .form-group input[type="text"],
        .form-group textarea {
            width: 100%;
            padding: 16px 18px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 15px;
            transition: all 0.3s;
            background: #fafafa;
        }

        .form-group input[type="text"]:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #2e8b57;
            background: white;
            box-shadow: 0 0 0 4px rgba(46, 139, 87, 0.1);
        }

        .form-group textarea {
            resize: vertical;
            min-height: 250px;
            line-height: 1.6;
        }

        .file-upload {
            position: relative;
            margin-top: 10px;
        }

        .file-upload input[type="file"] {
            position: absolute;
            width: 100%;
            height: 100%;
            opacity: 0;
            cursor: pointer;
            z-index: 2;
        }

        .file-upload-label {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            padding: 18px;
            border: 2px dashed #ddd;
            border-radius: 10px;
            background: #f9f9f9;
            color: #666;
            font-weight: 500;
            transition: all 0.3s;
            cursor: pointer;
        }

        .file-upload-label:hover {
            border-color: #2e8b57;
            background: #f0f9f4;
            color: #2e8b57;
        }

        .file-upload-label i {
            font-size: 20px;
        }

        .file-info {
            font-size: 13px;
            color: #777;
            margin-top: 8px;
            margin-left: 5px;
        }

        .char-count {
            text-align: right;
            font-size: 13px;
            color: #777;
            margin-top: 8px;
        }

        .preview-box {
            margin-top: 15px;
            text-align: center;
            display: none;
        }

        .preview-img {
            max-width: 200px;
            max-height: 150px;
            border-radius: 8px;
            border: 2px solid #eee;
            margin-bottom: 10px;
        }

        .button-group {
            display: flex;
            gap: 15px;
            margin-top: 35px;
            padding-top: 25px;
            border-top: 1px solid #eee;
        }

        .btn {
            padding: 16px 30px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            border: none;
            text-decoration: none;
            flex: 1;
        }

        .btn-primary {
            background: linear-gradient(to right, #2e8b57, #3cb371);
            color: white;
            box-shadow: 0 4px 15px rgba(46, 139, 87, 0.3);
        }

        .btn-primary:hover {
            background: linear-gradient(to right, #26734d, #2e8b57);
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(46, 139, 87, 0.4);
        }

        .btn-secondary {
            background: #f5f5f5;
            color: #666;
            border: 1px solid #ddd;
        }

        .btn-secondary:hover {
            background: #e9e9e9;
            transform: translateY(-3px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 768px) {
            .container {
                margin: 20px auto;
                border-radius: 12px;
            }
            
            .content {
                padding: 25px;
            }
            
            .header {
                padding: 25px 20px;
            }
            
            .header h1 {
                font-size: 24px;
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
            
            .header p {
                margin-left: 0;
                margin-top: 5px;
            }
            
            .back-link {
                position: relative;
                right: auto;
                top: auto;
                display: inline-flex;
                margin-top: 15px;
                width: 100%;
                justify-content: center;
            }
            
            .button-group {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <h1>
            <i class="fas fa-plus-circle"></i>
            Tambah Berita Baru
        </h1>
        <p>Isi formulir di bawah untuk menambahkan berita desa</p>
        <a href="index.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Kembali ke Daftar Berita
        </a>
    </div>
    
    <div class="content">
        <?php if ($error): ?>
            <div class="error-box">
                <i class="fas fa-exclamation-circle"></i>
                <span><?= htmlspecialchars($error) ?></span>
            </div>
        <?php endif; ?>

        <form method="post" enctype="multipart/form-data" id="beritaForm">
            <div class="form-group">
                <label for="judul">
                    <i class="fas fa-heading"></i>
                    Judul Berita
                </label>
                <input type="text" id="judul" name="judul" 
                       placeholder="Masukkan judul berita yang menarik"
                       maxlength="150"
                       required>
                <div class="char-count" id="judulCount">0/150 karakter</div>
            </div>
            
            <div class="form-group">
                <label for="isi">
                    <i class="fas fa-align-left"></i>
                    Isi Berita
                </label>
                <textarea id="isi" name="isi" 
                          placeholder="Tulis isi berita secara lengkap di sini..."
                          required></textarea>
                <div class="char-count" id="isiCount">0 karakter</div>
            </div>
            
            <div class="form-group">
                <label for="gambar">
                    <i class="fas fa-image"></i>
                    Gambar Berita (Opsional)
                </label>
                <div class="file-upload">
                    <input type="file" id="gambar" name="gambar" 
                           accept=".jpg,.jpeg,.png"
                           onchange="previewImage(this)">
                    <div class="file-upload-label">
                        <i class="fas fa-cloud-upload-alt"></i>
                        <span>Klik untuk memilih gambar</span>
                    </div>
                </div>
                <div class="file-info">
                    <i class="fas fa-info-circle"></i>
                    Format: JPG, PNG | Maksimal: 2MB
                </div>
                <div class="preview-box" id="previewBox">
                    <img id="previewImg" class="preview-img" src="" alt="Preview">
                    <div style="font-size: 14px; color: #666;">Preview Gambar</div>
                </div>
            </div>
            
            <div class="button-group">
                <button type="submit" name="simpan" class="btn btn-primary">
                    <i class="fas fa-save"></i>
                    Simpan Berita
                </button>
                <a href="index.php" class="btn btn-secondary">
                    <i class="fas fa-times"></i>
                    Batal
                </a>
            </div>
        </form>
    </div>
</div>

<script>
    // Fungsi untuk menghitung karakter
    function updateCharCount(element, counterId, maxLength = null) {
        const count = element.value.length;
        const counter = document.getElementById(counterId);
        
        if (maxLength) {
            counter.textContent = `${count}/${maxLength} karakter`;
            if (count > maxLength * 0.9) {
                counter.style.color = '#ff5252';
                counter.innerHTML += ' <i class="fas fa-exclamation-triangle"></i>';
            } else if (count > maxLength * 0.7) {
                counter.style.color = '#ff9800';
            } else {
                counter.style.color = '#777';
            }
        } else {
            counter.textContent = `${count} karakter`;
        }
    }
    
    // Fungsi preview gambar
    function previewImage(input) {
        const previewBox = document.getElementById('previewBox');
        const previewImg = document.getElementById('previewImg');
        
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            
            reader.onload = function(e) {
                previewImg.src = e.target.result;
                previewBox.style.display = 'block';
            }
            
            reader.readAsDataURL(input.files[0]);
            
            // Update label
            const fileName = input.files[0].name;
            document.querySelector('.file-upload-label span').innerHTML = 
                `<i class="fas fa-check-circle" style="color:#2e8b57"></i> ${fileName}`;
        } else {
            previewBox.style.display = 'none';
            document.querySelector('.file-upload-label span').innerHTML = 
                '<i class="fas fa-cloud-upload-alt"></i> Klik untuk memilih gambar';
        }
    }
    
    // Inisialisasi event listeners
    document.addEventListener('DOMContentLoaded', function() {
        const judulInput = document.getElementById('judul');
        const isiTextarea = document.getElementById('isi');
        
        judulInput.addEventListener('input', function() {
            updateCharCount(this, 'judulCount', 150);
        });
        
        isiTextarea.addEventListener('input', function() {
            updateCharCount(this, 'isiCount');
        });
        
        // Set nilai awal
        updateCharCount(judulInput, 'judulCount', 150);
        updateCharCount(isiTextarea, 'isiCount');
        
        // Validasi form
        document.getElementById('beritaForm').addEventListener('submit', function(e) {
            const judul = judulInput.value.trim();
            const isi = isiTextarea.value.trim();
            
            if (judul === '' || isi === '') {
                e.preventDefault();
                alert('Judul dan isi berita harus diisi!');
                return false;
            }
            
            if (judul.length > 150) {
                e.preventDefault();
                alert('Judul tidak boleh lebih dari 150 karakter!');
                return false;
            }
            
            // Validasi ukuran file jika ada
            const fileInput = document.getElementById('gambar');
            if (fileInput.files.length > 0) {
                const fileSize = fileInput.files[0].size / 1024 / 1024; // MB
                if (fileSize > 2) {
                    e.preventDefault();
                    alert('Ukuran gambar maksimal 2MB!');
                    return false;
                }
            }
        });
    });
</script>

</body>
</html>