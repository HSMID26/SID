<?php
session_start();
include '../../koneksi.php';

/* ===============================
   CEK LOGIN ADMIN (WAJIB)
================================ */
if (!isset($_SESSION['admin'])) {
    header("Location: ../../login.php");
    exit;
}

/* ===============================
   VALIDASI ID
================================ */
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$id = intval($_GET['id']);

/* ===============================
   HAPUS DATA BERITA
================================ */
$stmt = mysqli_prepare($conn, "DELETE FROM berita WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);

if (mysqli_stmt_execute($stmt)) {
    // BERHASIL
    header("Location: index.php?hapus=berhasil");
    exit;
} else {
    // GAGAL
    header("Location: index.php?hapus=gagal");
    exit;
}
