<?php
session_start();
include 'koneksi.php';

/* ===============================
   CEK LOGIN MASYARAKAT
================================ */
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'masyarakat') {
    header("Location: login-masyarakat.php");
    exit;
}

$user = $_SESSION['user'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Pengaduan Berhasil Dikirim</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(135deg, #f5f7fa, #e4efe9);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
}
.container {
    max-width: 700px;
    width: 100%;
    background: white;
    border-radius: 20px;
    box-shadow: 0 15px 35px rgba(11, 77, 58, 0.15);
    overflow: hidden;
    text-align: center;
}
.header {
    background: linear-gradient(135deg, #0b8f5a, #0b4d3a);
    color: white;
    padding: 40px 30px;
}
.header i {
    font-size: 80px;
    margin-bottom: 20px;
    opacity: 0.9;
}
.header h1 {
    font-size: 36px;
    margin-bottom: 10px;
    font-weight: 700;
}
.header p {
    font-size: 18px;
    opacity: 0.9;
    max-width: 500px;
    margin: 0 auto;
    line-height: 1.5;
}
.content {
    padding: 50px 40px;
}
.success-message {
    background: #e8f6ef;
    border-radius: 12px;
    padding: 25px;
    margin-bottom: 30px;
    border-left: 5px solid #0b8f5a;
}
.success-message h2 {
    color: #0b4d3a;
    margin-bottom: 15px;
    font-size: 24px;
}
.success-message p {
    color: #333;
    font-size: 16px;
    line-height: 1.6;
    margin-bottom: 10px;
}
.user-info {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 15px;
    margin-bottom: 30px;
    padding: 20px;
    background: #f8f9fa;
    border-radius: 12px;
}
.avatar {
    width: 60px;
    height: 60px;
    background: linear-gradient(135deg, #0b8f5a, #0da768);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: bold;
    font-size: 22px;
}
.user-details {
    text-align: left;
}
.user-details h3 {
    color: #2c3e50;
    margin-bottom: 5px;
}
.user-details p {
    color: #7f8c8d;
    font-size: 14px;
}
.action-buttons {
    display: flex;
    gap: 15px;
    justify-content: center;
    margin-top: 30px;
    flex-wrap: wrap;
}
.btn {
    padding: 16px 35px;
    border-radius: 10px;
    text-decoration: none;
    font-weight: 600;
    font-size: 16px;
    transition: all 0.3s;
    display: inline-flex;
    align-items: center;
    gap: 10px;
}
.btn-primary {
    background: linear-gradient(135deg, #0b8f5a, #0da768);
    color: white;
    border: none;
    cursor: pointer;
}
.btn-primary:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 20px rgba(11, 143, 90, 0.3);
}
.btn-secondary {
    background: #3498db;
    color: white;
}
.btn-secondary:hover {
    background: #2980b9;
    transform: translateY(-3px);
}
.btn-light {
    background: #f8f9fa;
    color: #333;
    border: 1px solid #ddd;
}
.btn-light:hover {
    background: #e9ecef;
    transform: translateY(-3px);
}
.info-box {
    background: #e8f4fc;
    border-radius: 12px;
    padding: 20px;
    margin-top: 30px;
    text-align: left;
    border-left: 4px solid #3498db;
}
.info-box h3 {
    color: #2c3e50;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    gap: 10px;
}
.info-box ul {
    list-style: none;
    padding-left: 5px;
}
.info-box li {
    margin-bottom: 8px;
    padding-left: 25px;
    position: relative;
    color: #34495e;
}
.info-box li:before {
    content: "✓";
    position: absolute;
    left: 0;
    color: #0b8f5a;
    font-weight: bold;
}
@media (max-width: 768px) {
    .header {
        padding: 30px 20px;
    }
    .header h1 {
        font-size: 28px;
    }
    .content {
        padding: 30px 20px;
    }
    .action-buttons {
        flex-direction: column;
    }
    .btn {
        width: 100%;
        justify-content: center;
    }
}
</style>
</head>
<body>
    <div class="container">
        <div class="header">
            <i class="fas fa-check-circle"></i>
            <h1>Pengaduan Berhasil Dikirim!</h1>
            <p>Terima kasih telah melaporkan pengaduan kepada pemerintah desa</p>
        </div>
        
        <div class="content">
            <div class="success-message">
                <h2><i class="fas fa-thumbs-up"></i> Pengaduan Anda Telah Direkam</h2>
                <p>Pengaduan Anda telah berhasil dikirim dan akan segera diproses oleh tim pemerintah desa.</p>
                <p>Nomor ID pengaduan Anda: <strong>P<?= date('Ymd') . rand(1000, 9999) ?></strong></p>
            </div>
            
            <div class="user-info">
                <div class="avatar">
                    <?= strtoupper(substr($user['nama_lengkap'], 0, 2)) ?>
                </div>
                <div class="user-details">
                    <h3><?= htmlspecialchars($user['nama_lengkap']) ?></h3>
                    <p><i class="fas fa-user"></i> <?= htmlspecialchars($user['username']) ?> • <i class="fas fa-calendar"></i> <?= date('d/m/Y H:i') ?></p>
                </div>
            </div>
            
            <div class="info-box">
                <h3><i class="fas fa-info-circle"></i> Informasi Penting</h3>
                <ul>
                    <li>Pengaduan Anda sedang dalam status <strong>"Menunggu"</strong></li>
                    <li>Tim akan meninjau pengaduan Anda dalam 1-3 hari kerja</li>
                    <li>Anda dapat melacak status pengaduan di halaman dashboard</li>
                    <li>Notifikasi akan dikirim ketika status pengaduan berubah</li>
                    <li>Pastikan nomor handphone aktif untuk komunikasi lanjutan</li>
                </ul>
            </div>
            
            <div class="action-buttons">
                <a href="index.php" class="btn btn-primary">
                    <i class="fas fa-home"></i> Kembali ke Beranda
                </a>
                <a href="pengaduan-saya.php" class="btn btn-secondary">
                    <i class="fas fa-list"></i> Lihat Pengaduan Saya
                </a>
                <a href="pengaduan-baru.php" class="btn btn-light">
                    <i class="fas fa-plus"></i> Buat Pengaduan Baru
                </a>
            </div>
        </div>
    </div>
</body>
</html>