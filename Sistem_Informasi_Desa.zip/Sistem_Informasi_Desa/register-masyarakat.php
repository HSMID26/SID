<?php
session_start();
include 'koneksi.php';

$error  = "";
$sukses = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nama_lengkap = trim($_POST['nama_lengkap']);
    $no_hp        = trim($_POST['no_hp']);
    $alamat_ktp   = trim($_POST['alamat_ktp']);
    $username     = trim($_POST['username']);
    $password     = $_POST['password'];
    $confirm      = $_POST['confirm'];

    /* ===============================
       VALIDASI
    ================================ */
    if ($nama_lengkap == "" || $no_hp == "" || $alamat_ktp == "" || $username == "" || $password == "") {
        $error = "Semua field wajib diisi!";
    } elseif ($password !== $confirm) {
        $error = "Password dan konfirmasi tidak cocok!";
    } elseif (strlen($password) < 6) {
        $error = "Password minimal 6 karakter!";
    } else {

        /* ===============================
           CEK USERNAME SUDAH ADA?
        ================================ */
        $cek = mysqli_prepare($conn, "
            SELECT id FROM users WHERE username = ?
        ");
        mysqli_stmt_bind_param($cek, "s", $username);
        mysqli_stmt_execute($cek);
        mysqli_stmt_store_result($cek);

        if (mysqli_stmt_num_rows($cek) > 0) {
            $error = "Username sudah digunakan!";
        } else {

            /* ===============================
               SIMPAN USER
            ================================ */
            $password_hash = password_hash($password, PASSWORD_DEFAULT);

            $stmt = mysqli_prepare($conn, "
                INSERT INTO users 
                (nama_lengkap, no_hp, alamat_ktp, username, password)
                VALUES (?, ?, ?, ?, ?)
            ");
            mysqli_stmt_bind_param(
                $stmt,
                "sssss",
                $nama_lengkap,
                $no_hp,
                $alamat_ktp,
                $username,
                $password_hash
            );

            if (mysqli_stmt_execute($stmt)) {
                $sukses = "Registrasi berhasil! Silakan login.";
            } else {
                $error = "Gagal menyimpan data!";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Registrasi Masyarakat</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

body {
    background: linear-gradient(135deg, #0d5038 0%, #0e9e6a 100%);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
}

.container {
    display: flex;
    max-width: 1000px;
    width: 100%;
    box-shadow: 0 15px 40px rgba(0, 0, 0, 0.25);
    border-radius: 20px;
    overflow: hidden;
    background: white;
}

/* Bagian Kiri - Informasi */
.info-section {
    flex: 1;
    background: linear-gradient(to bottom right, #0d5038, #0e9e6a);
    color: white;
    padding: 40px 30px;
    display: flex;
    flex-direction: column;
    justify-content: center;
}

.info-section h1 {
    font-size: 28px;
    margin-bottom: 15px;
    font-weight: 700;
}

.info-section p {
    font-size: 16px;
    line-height: 1.6;
    margin-bottom: 25px;
    opacity: 0.9;
}

.feature-list {
    list-style: none;
    margin-top: 20px;
}

.feature-list li {
    margin-bottom: 15px;
    display: flex;
    align-items: center;
}

.feature-list i {
    background: rgba(255, 255, 255, 0.2);
    width: 32px;
    height: 32px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 12px;
    font-size: 14px;
}

/* Bagian Kanan - Form */
.form-section {
    flex: 1.2;
    padding: 40px 50px;
    background: #fff;
}

.header {
    text-align: center;
    margin-bottom: 30px;
}

.header h2 {
    color: #0d5038;
    font-size: 28px;
    margin-bottom: 8px;
    font-weight: 700;
}

.header p {
    color: #666;
    font-size: 15px;
}

/* Notifikasi */
.notification {
    padding: 14px 18px;
    border-radius: 10px;
    margin-bottom: 25px;
    font-size: 15px;
    text-align: center;
    font-weight: 500;
}

.error {
    background-color: #ffeaea;
    color: #d32f2f;
    border-left: 4px solid #d32f2f;
}

.success {
    background-color: #e8f5e9;
    color: #2e7d32;
    border-left: 4px solid #2e7d32;
}

/* Form */
.form-group {
    margin-bottom: 20px;
    position: relative;
}

.form-group label {
    display: block;
    margin-bottom: 8px;
    color: #333;
    font-weight: 600;
    font-size: 15px;
}

.form-group i {
    position: absolute;
    left: 15px;
    top: 40px;
    color: #0d5038;
    font-size: 16px;
}

.form-control {
    width: 100%;
    padding: 14px 14px 14px 45px;
    border: 2px solid #e0e0e0;
    border-radius: 10px;
    font-size: 15px;
    transition: all 0.3s;
    background-color: #fafafa;
}

.form-control:focus {
    border-color: #0e9e6a;
    background-color: #fff;
    outline: none;
    box-shadow: 0 0 0 3px rgba(14, 158, 106, 0.1);
}

textarea.form-control {
    min-height: 90px;
    resize: vertical;
    padding-left: 45px;
}

.btn-submit {
    width: 100%;
    padding: 16px;
    background: linear-gradient(to right, #0d5038, #0e9e6a);
    color: white;
    border: none;
    border-radius: 10px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
    margin-top: 10px;
    letter-spacing: 0.5px;
}

.btn-submit:hover {
    background: linear-gradient(to right, #0c4531, #0c8c5e);
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(14, 158, 106, 0.3);
}

.login-link {
    text-align: center;
    margin-top: 25px;
    color: #666;
    font-size: 15px;
}

.login-link a {
    color: #0e9e6a;
    font-weight: 600;
    text-decoration: none;
    transition: color 0.3s;
}

.login-link a:hover {
    color: #0d5038;
    text-decoration: underline;
}

/* Responsif */
@media (max-width: 900px) {
    .container {
        flex-direction: column;
        max-width: 600px;
    }
    
    .info-section {
        padding: 30px;
    }
    
    .form-section {
        padding: 30px;
    }
}

@media (max-width: 480px) {
    .info-section, .form-section {
        padding: 25px 20px;
    }
    
    .header h2 {
        font-size: 24px;
    }
    
    .form-control {
        padding: 12px 12px 12px 40px;
    }
    
    .btn-submit {
        padding: 14px;
    }
}
</style>
</head>
<body>

<div class="container">
    <!-- Bagian Kiri: Informasi -->
    <div class="info-section">
        <h1>Bergabung dengan Masyarakat Digital</h1>
        <p>Daftarkan diri Anda untuk mendapatkan akses ke layanan masyarakat digital yang terintegrasi dan mudah digunakan.</p>
        
        <ul class="feature-list">
            <li><i class="fas fa-shield-alt"></i> Keamanan data terjamin</li>
            <li><i class="fas fa-bolt"></i> Proses cepat dan mudah</li>
            <li><i class="fas fa-headset"></i> Dukungan pelanggan 24/7</li>
            <li><i class="fas fa-mobile-alt"></i> Akses dari berbagai perangkat</li>
        </ul>
    </div>
    
    <!-- Bagian Kanan: Form Registrasi -->
    <div class="form-section">
        <div class="header">
            <h2>Daftar Akun Baru</h2>
            <p>Isi data diri Anda dengan benar</p>
        </div>

        <?php if ($error): ?>
            <div class="notification error">
                <i class="fas fa-exclamation-circle"></i> <?= $error ?>
            </div>
        <?php endif; ?>

        <?php if ($sukses): ?>
            <div class="notification success">
                <i class="fas fa-check-circle"></i> <?= $sukses ?>
            </div>
        <?php endif; ?>

        <form method="post">
            <div class="form-group">
                <label for="nama_lengkap">Nama Lengkap</label>
                <i class="fas fa-user"></i>
                <input type="text" id="nama_lengkap" name="nama_lengkap" class="form-control" placeholder="Masukkan nama lengkap" required>
            </div>

            <div class="form-group">
                <label for="no_hp">No Handphone</label>
                <i class="fas fa-phone"></i>
                <input type="text" id="no_hp" name="no_hp" class="form-control" placeholder="Contoh: 081234567890" required>
            </div>

            <div class="form-group">
                <label for="alamat_ktp">Alamat (Sesuai KTP)</label>
                <i class="fas fa-home"></i>
                <textarea id="alamat_ktp" name="alamat_ktp" class="form-control" placeholder="Masukkan alamat sesuai KTP" required></textarea>
            </div>

            <div class="form-group">
                <label for="username">Username</label>
                <i class="fas fa-user-circle"></i>
                <input type="text" id="username" name="username" class="form-control" placeholder="Pilih username unik" autocomplete="off" required>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <i class="fas fa-lock"></i>
                <input type="password" id="password" name="password" class="form-control" placeholder="Minimal 6 karakter" required>
            </div>

            <div class="form-group">
                <label for="confirm">Konfirmasi Password</label>
                <i class="fas fa-lock"></i>
                <input type="password" id="confirm" name="confirm" class="form-control" placeholder="Ulangi password Anda" required>
            </div>

            <button type="submit" class="btn-submit">
                <i class="fas fa-user-plus"></i> Daftar Sekarang
            </button>
        </form>

        <div class="login-link">
            Sudah punya akun? <a href="login-masyarakat.php">Login di sini</a>
        </div>
    </div>
</div>

<script>
// Tambahkan interaksi visual untuk form
document.addEventListener('DOMContentLoaded', function() {
    const formControls = document.querySelectorAll('.form-control');
    
    formControls.forEach(control => {
        // Tambahkan efek fokus
        control.addEventListener('focus', function() {
            this.parentElement.classList.add('focused');
        });
        
        control.addEventListener('blur', function() {
            if (this.value === '') {
                this.parentElement.classList.remove('focused');
            }
        });
        
        // Validasi password real-time
        if (control.id === 'confirm') {
            control.addEventListener('input', function() {
                const password = document.getElementById('password').value;
                const confirm = this.value;
                
                if (confirm.length > 0 && password !== confirm) {
                    this.style.borderColor = '#d32f2f';
                } else if (confirm.length > 0) {
                    this.style.borderColor = '#2e7d32';
                } else {
                    this.style.borderColor = '#e0e0e0';
                }
            });
        }
    });
});
</script>

</body>
</html>