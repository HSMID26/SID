<?php
session_start();
include 'koneksi.php';

$error = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $id_karyawan  = trim($_POST['id_karyawan']);
    $nama         = trim($_POST['nama_lengkap']);
    $jabatan      = trim($_POST['jabatan']);
    $username     = trim($_POST['username']);
    $email        = trim($_POST['email']);
    $password     = $_POST['password'];

    /* VALIDASI */
    if (empty($id_karyawan) || !ctype_digit($id_karyawan)) {
        $error = "ID Karyawan harus berupa angka!";
    } elseif (empty($jabatan)) {
        $error = "Jabatan wajib diisi!";
    } else {

        /* CEK DUPLIKAT */
        $cek = mysqli_prepare($conn, "
            SELECT id FROM users 
            WHERE id_karyawan = ? OR username = ? OR email = ?
        ");
        mysqli_stmt_bind_param($cek, "sss", $id_karyawan, $username, $email);
        mysqli_stmt_execute($cek);
        $cekRes = mysqli_stmt_get_result($cek);

        if (mysqli_num_rows($cekRes) > 0) {
            $error = "ID Karyawan / Username / Email sudah terdaftar!";
        } else {

            $password_hash = password_hash($password, PASSWORD_DEFAULT);

            $stmt = mysqli_prepare($conn, "
                INSERT INTO users 
                (id_karyawan, nama_lengkap, jabatan, username, email, password, role)
                VALUES (?, ?, ?, ?, ?, ?, 'admin')
            ");
            mysqli_stmt_bind_param(
                $stmt,
                "ssssss",
                $id_karyawan,
                $nama,
                $jabatan,
                $username,
                $email,
                $password_hash
            );

            mysqli_stmt_execute($stmt);

            $success = "Akun admin berhasil dibuat!";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrasi Admin - Sistem Masyarakat</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #0c3f2d 0%, #0a7a4f 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            position: relative;
            overflow-x: hidden;
        }

        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: 
                radial-gradient(circle at 10% 90%, rgba(255, 255, 255, 0.08) 0%, transparent 40%),
                radial-gradient(circle at 90% 10%, rgba(255, 255, 255, 0.08) 0%, transparent 40%);
            z-index: 0;
        }

        .register-container {
            display: flex;
            max-width: 1100px;
            width: 100%;
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 25px 60px rgba(0, 0, 0, 0.3);
            position: relative;
            z-index: 1;
        }

        /* Panel Kiri - Informasi */
        .info-panel {
            flex: 1;
            background: linear-gradient(to bottom right, #0c3f2d, #0a7a4f);
            color: white;
            padding: 50px 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }

        .info-panel::before {
            content: '';
            position: absolute;
            top: -30%;
            right: -20%;
            width: 250px;
            height: 250px;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 50%;
        }

        .info-panel::after {
            content: '';
            position: absolute;
            bottom: -20%;
            left: -10%;
            width: 180px;
            height: 180px;
            background: rgba(255, 255, 255, 0.03);
            border-radius: 50%;
        }

        .panel-header {
            position: relative;
            z-index: 2;
            margin-bottom: 40px;
        }

        .panel-header .icon {
            width: 70px;
            height: 70px;
            background: rgba(255, 255, 255, 0.15);
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 25px;
            font-size: 28px;
        }

        .panel-header h1 {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 10px;
            line-height: 1.3;
        }

        .panel-header p {
            font-size: 16px;
            opacity: 0.9;
            line-height: 1.6;
        }

        .requirements {
            position: relative;
            z-index: 2;
            margin-top: 30px;
        }

        .requirements h3 {
            font-size: 18px;
            margin-bottom: 15px;
            font-weight: 600;
            display: flex;
            align-items: center;
        }

        .requirements h3 i {
            margin-right: 10px;
            font-size: 16px;
        }

        .requirements-list {
            list-style: none;
        }

        .requirements-list li {
            display: flex;
            align-items: center;
            margin-bottom: 12px;
            font-size: 15px;
            padding: 8px 0;
        }

        .requirements-list i {
            width: 22px;
            height: 22px;
            background: rgba(255, 255, 255, 0.15);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 12px;
            font-size: 11px;
        }

        /* Panel Kanan - Form Registrasi */
        .form-panel {
            flex: 1.2;
            padding: 50px 50px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .form-header {
            margin-bottom: 40px;
            text-align: center;
        }

        .form-header h2 {
            color: #0c3f2d;
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 8px;
        }

        .form-header p {
            color: #666;
            font-size: 16px;
        }

        /* Notifikasi */
        .notification {
            padding: 18px 20px;
            border-radius: 12px;
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            animation: fadeIn 0.5s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .error-notification {
            background: linear-gradient(to right, #ffeaea, #ffdbdb);
            border-left: 5px solid #d32f2f;
            color: #d32f2f;
        }

        .success-notification {
            background: linear-gradient(to right, #e8f8f5, #d8f0e8);
            border-left: 5px solid #2e7d32;
            color: #2e7d32;
        }

        .notification i {
            margin-right: 15px;
            font-size: 20px;
        }

        /* Form Styles */
        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 25px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group.full-width {
            grid-column: span 2;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
            font-size: 15px;
            display: flex;
            align-items: center;
        }

        .form-label i {
            margin-right: 8px;
            color: #0a7a4f;
            font-size: 16px;
        }

        .form-label .required {
            color: #d32f2f;
            margin-left: 4px;
        }

        .input-group {
            position: relative;
        }

        .input-group i {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: #0a7a4f;
            font-size: 18px;
            z-index: 2;
        }

        .form-control {
            width: 100%;
            padding: 16px 20px 16px 55px;
            border: 2px solid #e8e8e8;
            border-radius: 12px;
            font-size: 16px;
            transition: all 0.3s;
            background-color: #fafafa;
            color: #333;
        }

        .form-control:focus {
            border-color: #0a7a4f;
            background-color: #fff;
            outline: none;
            box-shadow: 0 0 0 4px rgba(10, 122, 79, 0.15);
        }

        .form-control::placeholder {
            color: #999;
            font-size: 15px;
        }

        .password-strength {
            margin-top: 8px;
            font-size: 13px;
            display: flex;
            align-items: center;
        }

        .password-strength i {
            margin-right: 6px;
            font-size: 14px;
        }

        .strength-weak { color: #d32f2f; }
        .strength-medium { color: #f57c00; }
        .strength-strong { color: #2e7d32; }

        /* Submit Button */
        .btn-register {
            width: 100%;
            padding: 18px;
            background: linear-gradient(to right, #0c3f2d, #0a7a4f);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 17px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            letter-spacing: 0.5px;
            box-shadow: 0 5px 15px rgba(10, 122, 79, 0.2);
        }

        .btn-register:hover {
            background: linear-gradient(to right, #0a3526, #096946);
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(10, 122, 79, 0.3);
        }

        .btn-register:active {
            transform: translateY(-1px);
        }

        .btn-register i {
            margin-right: 12px;
            font-size: 18px;
        }

        /* Back Link */
        .back-link {
            text-align: center;
            margin-top: 30px;
            padding-top: 25px;
            border-top: 1px solid #eee;
            color: #666;
            font-size: 15px;
        }

        .back-link a {
            color: #0a7a4f;
            font-weight: 600;
            text-decoration: none;
            transition: color 0.3s;
            display: inline-flex;
            align-items: center;
        }

        .back-link a:hover {
            color: #0c3f2d;
            text-decoration: underline;
        }

        .back-link i {
            margin-right: 8px;
            font-size: 15px;
        }

        /* Responsive */
        @media (max-width: 900px) {
            .register-container {
                flex-direction: column;
                max-width: 600px;
            }
            
            .info-panel, .form-panel {
                padding: 40px 30px;
            }
            
            .form-grid {
                grid-template-columns: 1fr;
                gap: 15px;
            }
            
            .form-group.full-width {
                grid-column: span 1;
            }
        }

        @media (max-width: 480px) {
            .register-container {
                border-radius: 15px;
            }
            
            .info-panel, .form-panel {
                padding: 35px 25px;
            }
            
            .panel-header h1, .form-header h2 {
                font-size: 26px;
            }
            
            .form-control {
                padding: 14px 20px 14px 50px;
            }
            
            .btn-register {
                padding: 16px;
            }
        }

        /* Loading Animation */
        .loading {
            display: none;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: white;
            animation: spin 1s ease-in-out infinite;
            margin-right: 10px;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* Tooltip */
        .tooltip {
            position: relative;
            display: inline-block;
            margin-left: 8px;
            color: #666;
            cursor: help;
        }

        .tooltip .tooltiptext {
            visibility: hidden;
            width: 200px;
            background-color: #333;
            color: #fff;
            text-align: center;
            border-radius: 6px;
            padding: 10px;
            position: absolute;
            z-index: 100;
            bottom: 125%;
            left: 50%;
            transform: translateX(-50%);
            opacity: 0;
            transition: opacity 0.3s;
            font-size: 13px;
            font-weight: normal;
        }

        .tooltip .tooltiptext::after {
            content: "";
            position: absolute;
            top: 100%;
            left: 50%;
            margin-left: -5px;
            border-width: 5px;
            border-style: solid;
            border-color: #333 transparent transparent transparent;
        }

        .tooltip:hover .tooltiptext {
            visibility: visible;
            opacity: 1;
        }
    </style>
</head>
<body>

<div class="register-container">
    <!-- Panel Kiri: Informasi -->
    <div class="info-panel">
        <div class="panel-header">
            <div class="icon">
                <i class="fas fa-user-shield"></i>
            </div>
            <h1>Registrasi Administrator</h1>
            <p>Buat akun admin baru untuk mengakses dashboard dan mengelola sistem masyarakat dengan hak akses penuh.</p>
        </div>

        <div class="requirements">
            <h3><i class="fas fa-clipboard-check"></i> Persyaratan Registrasi</h3>
            <ul class="requirements-list">
                <li><i class="fas fa-check"></i> ID Karyawan harus berupa angka unik</li>
                <li><i class="fas fa-check"></i> Jabatan sesuai dengan posisi resmi</li>
                <li><i class="fas fa-check"></i> Username minimal 4 karakter</li>
                <li><i class="fas fa-check"></i> Email yang valid dan aktif</li>
                <li><i class="fas fa-check"></i> Password minimal 8 karakter</li>
                <li><i class="fas fa-check"></i> Data harus asli dan dapat diverifikasi</li>
            </ul>
        </div>
    </div>

    <!-- Panel Kanan: Form Registrasi -->
    <div class="form-panel">
        <div class="form-header">
            <h2>Form Registrasi</h2>
            <p>Isi data dengan lengkap dan benar</p>
        </div>

        <?php if($error): ?>
        <div class="notification error-notification">
            <i class="fas fa-exclamation-triangle"></i>
            <span><?= htmlspecialchars($error) ?></span>
        </div>
        <?php endif; ?>

        <?php if($success): ?>
        <div class="notification success-notification">
            <i class="fas fa-check-circle"></i>
            <span><?= htmlspecialchars($success) ?></span>
        </div>
        <?php endif; ?>

        <form method="post" id="registerForm">
            <div class="form-grid">
                <div class="form-group">
                    <label class="form-label" for="id_karyawan">
                        <i class="fas fa-id-badge"></i> ID Karyawan
                        <span class="required">*</span>
                        <div class="tooltip">
                            <i class="fas fa-info-circle"></i>
                            <span class="tooltiptext">ID Karyawan harus berupa angka dan bersifat unik</span>
                        </div>
                    </label>
                    <div class="input-group">
                        <i class="fas fa-hashtag"></i>
                        <input type="text" id="id_karyawan" name="id_karyawan" class="form-control" 
                               placeholder="Contoh: 12345" required pattern="\d+" 
                               title="Hanya angka yang diperbolehkan">
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="nama_lengkap">
                        <i class="fas fa-user"></i> Nama Lengkap
                        <span class="required">*</span>
                    </label>
                    <div class="input-group">
                        <i class="fas fa-signature"></i>
                        <input type="text" id="nama_lengkap" name="nama_lengkap" class="form-control" 
                               placeholder="Masukkan nama lengkap" required>
                    </div>
                </div>

                <div class="form-group full-width">
                    <label class="form-label" for="jabatan">
                        <i class="fas fa-briefcase"></i> Jabatan
                        <span class="required">*</span>
                    </label>
                    <div class="input-group">
                        <i class="fas fa-user-tie"></i>
                        <input type="text" id="jabatan" name="jabatan" class="form-control" 
                               placeholder="Contoh: Kepala Desa, Sekretaris, Bendahara" required>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="username">
                        <i class="fas fa-user-circle"></i> Username
                        <span class="required">*</span>
                    </label>
                    <div class="input-group">
                        <i class="fas fa-at"></i>
                        <input type="text" id="username" name="username" class="form-control" 
                               placeholder="Pilih username" required minlength="4">
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="email">
                        <i class="fas fa-envelope"></i> Email
                        <span class="required">*</span>
                    </label>
                    <div class="input-group">
                        <i class="fas fa-mail-bulk"></i>
                        <input type="email" id="email" name="email" class="form-control" 
                               placeholder="email@contoh.com" required>
                    </div>
                </div>

                <div class="form-group full-width">
                    <label class="form-label" for="password">
                        <i class="fas fa-lock"></i> Password
                        <span class="required">*</span>
                    </label>
                    <div class="input-group">
                        <i class="fas fa-key"></i>
                        <input type="password" id="password" name="password" class="form-control" 
                               placeholder="Minimal 8 karakter" required minlength="8">
                        <button type="button" class="password-toggle" id="togglePassword" style="
                            position: absolute;
                            right: 18px;
                            top: 50%;
                            transform: translateY(-50%);
                            background: none;
                            border: none;
                            color: #777;
                            cursor: pointer;
                            font-size: 18px;
                            z-index: 3;
                        ">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                    <div class="password-strength" id="passwordStrength">
                        <i class="fas fa-info-circle"></i>
                        <span id="strengthText">Kekuatan password</span>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn-register" id="registerButton">
                <div class="loading" id="loadingSpinner"></div>
                <i class="fas fa-user-plus"></i>
                <span id="buttonText">Buat Akun Admin</span>
            </button>
        </form>

        <div class="back-link">
            <a href="login.php">
                <i class="fas fa-arrow-left"></i> Kembali ke Halaman Login
            </a>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Toggle visibility password
        const togglePassword = document.getElementById('togglePassword');
        const passwordInput = document.getElementById('password');
        const eyeIcon = togglePassword.querySelector('i');
        
        togglePassword.addEventListener('click', function() {
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            eyeIcon.classList.toggle('fa-eye');
            eyeIcon.classList.toggle('fa-eye-slash');
        });

        // Password strength indicator
        const passwordStrength = document.getElementById('passwordStrength');
        const strengthText = document.getElementById('strengthText');
        const strengthIcon = passwordStrength.querySelector('i');
        
        passwordInput.addEventListener('input', function() {
            const password = this.value;
            let strength = 0;
            let text = 'Kekuatan password';
            let colorClass = '';
            
            if (password.length >= 8) strength++;
            if (/[A-Z]/.test(password)) strength++;
            if (/[0-9]/.test(password)) strength++;
            if (/[^A-Za-z0-9]/.test(password)) strength++;
            
            switch(strength) {
                case 0:
                    text = 'Password kosong';
                    colorClass = 'strength-weak';
                    strengthIcon.className = 'fas fa-times-circle';
                    break;
                case 1:
                    text = 'Password lemah';
                    colorClass = 'strength-weak';
                    strengthIcon.className = 'fas fa-exclamation-circle';
                    break;
                case 2:
                    text = 'Password cukup';
                    colorClass = 'strength-medium';
                    strengthIcon.className = 'fas fa-check-circle';
                    break;
                case 3:
                    text = 'Password kuat';
                    colorClass = 'strength-strong';
                    strengthIcon.className = 'fas fa-shield-alt';
                    break;
                case 4:
                    text = 'Password sangat kuat';
                    colorClass = 'strength-strong';
                    strengthIcon.className = 'fas fa-award';
                    break;
            }
            
            strengthText.textContent = text;
            strengthText.className = colorClass;
            strengthIcon.className += ' ' + colorClass;
        });

        // Form submission animation
        const registerForm = document.getElementById('registerForm');
        const registerButton = document.getElementById('registerButton');
        const buttonText = document.getElementById('buttonText');
        const loadingSpinner = document.getElementById('loadingSpinner');
        
        registerForm.addEventListener('submit', function(e) {
            // Validasi ID Karyawan harus angka
            const idKaryawan = document.getElementById('id_karyawan').value;
            if (!/^\d+$/.test(idKaryawan)) {
                e.preventDefault();
                document.getElementById('id_karyawan').focus();
                return;
            }
            
            // Show loading animation
            loadingSpinner.style.display = 'block';
            buttonText.textContent = 'Membuat akun...';
            registerButton.disabled = true;
            
            // Prevent double submission
            setTimeout(() => {
                registerButton.disabled = false;
            }, 3000);
        });

        // Auto-focus pada input username jika ada error
        <?php if($error): ?>
            document.getElementById('id_karyawan').focus();
        <?php endif; ?>

        // Add animation to form inputs on focus
        const inputs = document.querySelectorAll('.form-control');
        inputs.forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.parentElement.classList.add('focused');
            });
            
            input.addEventListener('blur', function() {
                if (this.value === '') {
                    this.parentElement.parentElement.classList.remove('focused');
                }
            });
        });

        // Real-time validation for ID Karyawan
        const idKaryawanInput = document.getElementById('id_karyawan');
        idKaryawanInput.addEventListener('input', function() {
            const value = this.value;
            if (!/^\d*$/.test(value)) {
                this.value = value.replace(/\D/g, '');
            }
        });
    });
</script>

</body>
</html>