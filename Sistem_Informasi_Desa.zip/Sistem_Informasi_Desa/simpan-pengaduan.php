<?php
session_start();
include 'koneksi.php';

/* ===============================
   CEK LOGIN MASYARAKAT
================================ */
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'masyarakat') {
    header("Location: login-masyarakat.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: pengaduan-baru.php");
    exit;
}

// Ambil data dari form
$user_id = $_POST['user_id'];
$kategori = mysqli_real_escape_string($conn, $_POST['kategori']);
$pesan = mysqli_real_escape_string($conn, $_POST['pesan']);
$lokasi = mysqli_real_escape_string($conn, $_POST['lokasi']);

// Status default sesuai struktur database Anda
$status = 'terkirim';

// Tanggal dan waktu sekarang
$tanggal = date('Y-m-d H:i:s');

// Handle upload file bukti
$bukti_file = '';

if (!empty($_FILES['bukti']['name'])) {
    $file_name = $_FILES['bukti']['name'];
    $file_tmp = $_FILES['bukti']['tmp_name'];
    $file_size = $_FILES['bukti']['size'];
    
    $allowed_extensions = ['jpg', 'jpeg', 'png', 'pdf', 'doc', 'docx'];
    $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
    
    if (in_array($file_ext, $allowed_extensions) && $file_size <= 5 * 1024 * 1024) {
        $bukti_file = uniqid('bukti_', true) . '.' . $file_ext;
        $upload_dir = 'uploads/pengaduan/';
        
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        if (move_uploaded_file($file_tmp, $upload_dir . $bukti_file)) {
            // File berhasil diupload
        } else {
            $bukti_file = '';
        }
    }
}

// SIMPAN KE DATABASE sesuai struktur tabel pengaduan Anda
$query = "INSERT INTO pengaduan 
          (user_id, kategori, pesan, lokasi, bukti, status, tanggal) 
          VALUES ('$user_id', '$kategori', '$pesan', '$lokasi', '$bukti_file', '$status', '$tanggal')";

if (mysqli_query($conn, $query)) {
    header("Location: pengaduan-baru.php?success=1");
    exit;
} else {
    // Untuk debugging
    error_log("MySQL Error: " . mysqli_error($conn));
    header("Location: pengaduan-baru.php?error=1");
    exit;
}
?>