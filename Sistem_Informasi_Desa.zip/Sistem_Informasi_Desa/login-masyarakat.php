<?php
session_start();
include 'koneksi.php';

/* ===============================
   JIKA SUDAH LOGIN
================================ */
if (isset($_SESSION['user'])) {
    header("Location: pengaduan-baru.php");
    exit;
}

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    if ($username === '' || $password === '') {
        $error = "Username dan password wajib diisi!";
    } else {
        $stmt = mysqli_prepare($conn, "
            SELECT id, nama_lengkap, username, password, role, no_hp, alamat_ktp
            FROM users
            WHERE username = ?
            LIMIT 1
        ");
        mysqli_stmt_bind_param($stmt, "s", $username);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) === 1) {
            $user = mysqli_fetch_assoc($result);

            /* CEK ROLE */
            if ($user['role'] !== 'masyarakat') {
                $error = "Akun ini bukan akun masyarakat!";
            }
            /* CEK PASSWORD */
            elseif (password_verify($password, $user['password'])) {
                // Simpan semua data user ke session
                $_SESSION['user'] = [
                    'id'           => $user['id'],
                    'nama_lengkap' => $user['nama_lengkap'],
                    'username'     => $user['username'],
                    'role'         => $user['role'],
                    'no_hp'        => $user['no_hp'],
                    'alamat_ktp'   => $user['alamat_ktp']
                ];

                // SELALU REDIRECT KE PENGADUAN-BARU.PHP SETELAH LOGIN BERHASIL
                header("Location: pengaduan-baru.php");
                exit;

            } else {
                $error = "Password salah!";
            }
        } else {
            $error = "Username tidak ditemukan!";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Masyarakat - Layanan Pengaduan</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #0b4d3a 0%, #0a7c4f 50%, #0b8f5a 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .login-container {
            display: flex;
            width: 100%;
            max-width: 900px;
            min-height: 550px;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.25);
        }

        .login-left {
            flex: 1;
            background: linear-gradient(rgba(11, 77, 58, 0.85), rgba(11, 77, 58, 0.9)), 
                        url('https://images.unsplash.com/photo-1551836026-d5c2c0b4d6b9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80') center/cover;
            color: white;
            padding: 50px 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .login-left h1 {
            font-size: 2.5rem;
            margin-bottom: 15px;
            font-weight: 700;
        }

        .login-left p {
            font-size: 1.1rem;
            line-height: 1.6;
            opacity: 0.9;
            margin-bottom: 30px;
        }

        .features {
            list-style: none;
            margin-top: 30px;
        }

        .features li {
            margin-bottom: 15px;
            display: flex;
            align-items: center;
        }

        .features i {
            color: #0b8f5a;
            background: white;
            width: 24px;
            height: 24px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 12px;
            font-size: 0.8rem;
        }

        .login-right {
            flex: 1;
            background: #fff;
            padding: 60px 50px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .login-header {
            text-align: center;
            margin-bottom: 40px;
        }

        .login-header h2 {
            color: #0b4d3a;
            font-size: 2rem;
            margin-bottom: 8px;
        }

        .login-header p {
            color: #666;
            font-size: 1rem;
        }

        .logo {
            width: 60px;
            height: 60px;
            background: #0b8f5a;
            border-radius: 12px;
            margin: 0 auto 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.8rem;
        }

        .form-group {
            position: relative;
            margin-bottom: 25px;
        }

        .form-group i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #0b8f5a;
            font-size: 1.1rem;
        }

        .form-control {
            width: 100%;
            padding: 15px 15px 15px 45px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 1rem;
            transition: all 0.3s;
        }

        .form-control:focus {
            border-color: #0b8f5a;
            outline: none;
            box-shadow: 0 0 0 3px rgba(11, 143, 90, 0.1);
        }

        .btn-login {
            width: 100%;
            padding: 15px;
            background: #0b8f5a;
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 10px;
        }

        .btn-login:hover {
            background: #0a7c4f;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(11, 143, 90, 0.3);
        }

        .btn-login:active {
            transform: translateY(0);
        }

        .alert-error {
            background: #ffebee;
            color: #c62828;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 25px;
            border-left: 5px solid #c62828;
            display: flex;
            align-items: center;
            animation: fadeIn 0.5s;
        }

        .alert-error i {
            margin-right: 10px;
            font-size: 1.2rem;
        }

        .register-link {
            text-align: center;
            margin-top: 30px;
            color: #666;
            font-size: 0.95rem;
        }

        .register-link a {
            color: #0b8f5a;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s;
        }

        .register-link a:hover {
            text-decoration: underline;
            color: #0a7c4f;
        }

        .footer-text {
            text-align: center;
            margin-top: 30px;
            font-size: 0.8rem;
            color: #999;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .login-container {
                flex-direction: column;
                max-width: 500px;
            }
            
            .login-left {
                padding: 40px 30px;
            }
            
            .login-left h1 {
                font-size: 2rem;
            }
            
            .login-right {
                padding: 40px 30px;
            }
        }
        
        @media (max-width: 480px) {
            .login-container {
                border-radius: 15px;
            }
            
            .login-left, .login-right {
                padding: 30px 25px;
            }
            
            .login-header h2 {
                font-size: 1.7rem;
            }
        }
    </style>
</head>
<body>

<div class="login-container">
    <!-- Left Panel - Welcome & Info -->
    <div class="login-left">
        <h1>Layanan Pengaduan Masyarakat</h1>
        <p>Sampaikan pengaduan Anda dengan mudah dan cepat. Sistem kami akan memproses laporan Anda secara transparan dan efisien.</p>
        
        <ul class="features">
            <li><i class="fas fa-check"></i> Proses pengaduan yang cepat</li>
            <li><i class="fas fa-check"></i> Status pengaduan dapat dipantau</li>
            <li><i class="fas fa-check"></i> Perlindungan data pribadi</li>
            <li><i class="fas fa-check"></i> Respons cepat dari petugas</li>
        </ul>
    </div>
    
    <!-- Right Panel - Login Form -->
    <div class="login-right">
        <div class="logo">
            <i class="fas fa-comments"></i>
        </div>
        
        <div class="login-header">
            <h2>Login Masyarakat</h2>
            <p>Masuk untuk mengajukan pengaduan baru</p>
        </div>

        <?php if ($error): ?>
        <div class="alert-error">
            <i class="fas fa-exclamation-circle"></i>
            <?= htmlspecialchars($error) ?>
        </div>
        <?php endif; ?>

        <form method="post" id="loginForm">
            <div class="form-group">
                <i class="fas fa-user"></i>
                <input type="text" name="username" class="form-control" placeholder="Username" required>
            </div>
            
            <div class="form-group">
                <i class="fas fa-lock"></i>
                <input type="password" name="password" class="form-control" placeholder="Password" required>
            </div>
            
            <button type="submit" class="btn-login">
                <i class="fas fa-sign-in-alt"></i> Masuk ke Akun
            </button>
        </form>

        <p class="register-link">
            Belum punya akun? <a href="register-masyarakat.php">Daftar Sekarang</a>
        </p>
        
        <div class="footer-text">
            &copy; <?php echo date('Y'); ?> Layanan Pengaduan Masyarakat. Hak Cipta Dilindungi.
        </div>
    </div>
</div>

<script>
    // Menambahkan efek interaktif pada form
    document.addEventListener('DOMContentLoaded', function() {
        const formControls = document.querySelectorAll('.form-control');
        
        formControls.forEach(control => {
            // Efek fokus
            control.addEventListener('focus', function() {
                this.parentElement.style.transform = 'scale(1.02)';
            });
            
            control.addEventListener('blur', function() {
                this.parentElement.style.transform = 'scale(1)';
            });
        });
        
        // Validasi form sebelum submit
        const loginForm = document.getElementById('loginForm');
        loginForm.addEventListener('submit', function(e) {
            const username = document.querySelector('input[name="username"]').value.trim();
            const password = document.querySelector('input[name="password"]').value;
            
            if (username === '' || password === '') {
                e.preventDefault();
                alert('Username dan password wajib diisi!');
                return false;
            }
            
            // Menampilkan loading state
            const submitBtn = document.querySelector('.btn-login');
            const originalText = submitBtn.innerHTML;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Memproses...';
            submitBtn.disabled = true;
            
            // Reset button setelah 3 detik (jika halaman tidak redirect)
            setTimeout(() => {
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            }, 3000);
        });
    });
</script>

</body>
</html>